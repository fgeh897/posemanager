import os
import json
from enum import IntEnum

# ==========================================
# 1. 枚举定义 (Enum) - 让状态变成人类可读的标签
# ==========================================
class ViewMode(IntEnum):
    NORMAL = 0
    FAV = 1
    TRACE = 2

class FavPackMode(IntEnum):
    FAVS = 0
    MANAGE = 1
    DELETE = 2
    CREATOR_PACKS = 3
    GROUP_PLAY = 4
    GROUP_MANAGE = 5
    GROUP_EDIT = 6

class CreatorMode(IntEnum):
    FAVS = 0
    ALL = 1
    PACKS = 2
    DELETE = 3

class FavPoseMode(IntEnum):
    PLAY = 0
    GROUP_PLAY = 1
    GROUP_MANAGE = 2
    GROUP_EDIT = 3

class GroupMode(IntEnum):
    LIST = 0
    DELETE_PACK = 1
    PACK_HOME = 2
    PACK_MANAGE = 3
    EDIT_GROUP = 4
    PLAY_GROUP = 5
    CREATOR_PACKS = 6
    FAV_GROUP_PLAY = 7
    FAV_GROUP_MANAGE = 8
    FAV_GROUP_EDIT = 9
    ASSIGN_MACRO_GROUPS = 10 

class GlobalSettingsMode(IntEnum):
    MAIN = 0
    HISTORY = 1
    HISTORY_LIMIT = 2

# ==========================================
# 2. 全局状态管理器 (单例模式)
# ==========================================
class FgehStateManager:
    def __init__(self):
        # --- UI 导航状态 ---
        self.current_mode = ViewMode.NORMAL
        self.came_from_l1_favs = False
        self.came_from_creator = False
        self.came_from_grouped = False
        self.is_in_normal_pack_manage_mode = False
        self.return_to_fav_on_close = False
        self.filter_blank_poses = True
        self.restore_last_view_on_open = False
        self.auto_destroy_linked_objects = True
        self.replace_linked_objects_on_replay = True
        self.auto_apply_linked_requirements = True
        self.restore_linked_requirements_when_pose_chain_finished = False
        self.last_ui_selection = None
        self.last_ui_snapshot = None
        self.suppress_next_history_restore = False
        self.global_settings_from_root = False
        self.pose_pack_cache_reset_done = False
        
        self.global_fav_pack_ref = None
        self.global_traced_pack_ref = None
        
        # --- 视图模式 ---
        self.p_view_mode = FavPackMode.FAVS
        self.c_view_mode = CreatorMode.FAVS
        self.s_view_mode = FavPoseMode.PLAY
        self.g_view_mode = GroupMode.LIST
        self.gs_view_mode = GlobalSettingsMode.MAIN
        
        # --- 选择记忆 ---
        self.selected_fav_creator = None
        self.selected_fav_group = None
        self.selected_creator = None
        self.selected_fav_pose_group = None
        self.selected_group = None
        self.selected_group_creator = None
        self.selected_linked_action_category = None
        self.selected_linked_group_type = None
        self.selected_linked_group_name = None
        self.selected_linked_pack_id = None
        self.linked_manage_mode = False
        self.linked_group_manage_mode = False
        self.linked_object_style_mode = False
        self.selected_linked_style_pose_name = None
        self.selected_linked_assign_pack_id = None
        
        # --- 视图开关 (Toggle) ---
        self.fav_packs_view_toggle = 0
        self.grouped_view_toggle = 0
        self.fav_poses_view_toggle = 0
        
        # --- 核心业务数据 (列表和字典) ---
        self.favorite_poses = []
        self.favorite_creators = []
        self.favorite_packs = []
        self.grouped_packs = {}
        self.user_fav_groups = {}
        self.user_fav_pose_groups = {}
        self.user_grouped_packs_groups = {}
        self.linked_groups = {}
        self.linked_object_variant_choices = {}
        self.linked_object_enabled_choices = {}
        self.linked_object_spawn_disabled = {}
        self.linked_cas_enabled_choices = {}
        self.linked_cas_apply_disabled = {}
        self.browse_history_packs = []
        self.browse_history_limit = 30
        self.custom_names = {}# 格式: {"作者名或包ID": "用户自定义的新名字"}
        
        # --- 缓存系统 ---
        self.cache_built = False
        self.all_poses_cache = {}
        self.all_creators_cache = {}
        self.all_packs_cache = {}

# 创建一个全局唯一的实例
state = FgehStateManager()

from event_testing.results import TestResult
from interactions.base.immediate_interaction import ImmediateSuperInteraction
import services
import sims4.resources
from sims4.tuning.tunable import TunableReference

from fgeh_cas_accessory_outfit_utils import (
    apply_fixed_cas_accessory_to_sim,
    debug_log,
    dump_current_outfit_parts,
    get_sim_info_from_target,
    restore_original_outfit,
)
from fgeh_cas_accessory_snippets import (
    get_accessory_cas_part_id_from_metadata_snippet,
)


class FgehDebugCasAccessoryInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result
        if get_sim_info_from_target(target) is None:
            return TestResult(False, "FGEH CAS accessory debug only supports Sim targets.")
        return TestResult.TRUE


class FgehApplyFixedCasAccessoryInteraction(FgehDebugCasAccessoryInteraction):
    INSTANCE_TUNABLES = {
        "pose_metadata_snippet": TunableReference(
            description="FGEH pose metadata snippet resource. Its accessory_cas_part_id supplies the CASP instance id.",
            manager=services.get_instance_manager(sims4.resources.Types.SNIPPET),
            class_restrictions=("FGEHPoseMetadataSnippet",),
            allow_none=True,
        ),
    }

    @classmethod
    def _get_tuned_cas_part_id(cls):
        snippet = getattr(cls, "pose_metadata_snippet", None)
        if snippet is None:
            debug_log("Apply interaction has no pose_metadata_snippet tuned.")
            return None
        cas_part_id = get_accessory_cas_part_id_from_metadata_snippet(snippet)
        debug_log(
            "Apply interaction snippet read: snippet={} pack_id={} pack_name={} accessory_cas_part_id={}",
            snippet,
            getattr(snippet, "pack_id", None),
            getattr(snippet, "pack_name", None),
            cas_part_id,
        )
        return cas_part_id

    def _run_interaction_gen(self, timeline):
        apply_fixed_cas_accessory_to_sim(
            get_sim_info_from_target(self.target),
            cas_part_id=self._get_tuned_cas_part_id(),
        )
        return True
        if False:
            yield None


class FgehRestoreOriginalOutfitInteraction(FgehDebugCasAccessoryInteraction):
    def _run_interaction_gen(self, timeline):
        sim_info = get_sim_info_from_target(self.target)
        debug_log(
            "RestoreOriginalOutfitInteraction run target={} sim_info={} sim_id={}",
            self.target,
            sim_info,
            getattr(sim_info, "sim_id", None),
        )
        result = restore_original_outfit(sim_info)
        debug_log("RestoreOriginalOutfitInteraction result={}", result)
        return True
        if False:
            yield None


class FgehDumpCurrentOutfitPartsInteraction(FgehDebugCasAccessoryInteraction):
    def _run_interaction_gen(self, timeline):
        dump_current_outfit_parts(get_sim_info_from_target(self.target))
        return True
        if False:
            yield None

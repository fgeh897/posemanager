import json
import os
import time


OBJECT_BINDINGS_FILENAME = "fgeh_linked_object_bindings.json"
OBJECT_BINDINGS_TMP_FILENAME = "fgeh_linked_object_bindings_tmp"
OBJECT_BINDINGS_BAK_FILENAME = "fgeh_linked_object_bindings_backup"
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))


def _sims4_roots():
    return (
        "E:\\文档\\Electronic Arts\\The Sims 4",
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    )


def _candidate_dirs():
    dirs = []
    for root in _sims4_roots():
        mods_dir = os.path.join(root, "Mods")
        if mods_dir not in dirs:
            dirs.append(mods_dir)
    if MODULE_DIR not in dirs:
        dirs.append(MODULE_DIR)
    return dirs


def _primary_dir():
    for folder in _candidate_dirs():
        try:
            if os.path.isdir(folder):
                return folder
        except Exception:
            pass
    return MODULE_DIR


def _path_in(folder, filename):
    return os.path.join(folder, filename)


def _primary_path(filename):
    return _path_in(_primary_dir(), filename)


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _now_text():
    try:
        return time.strftime("%Y-%m-%dT%H:%M:%S")
    except Exception:
        return ""


def _load_data():
    merged = []
    merged_assets = []
    seen = set()
    seen_assets = set()
    schema_version = 1
    for folder in _candidate_dirs():
        try:
            path = _path_in(folder, OBJECT_BINDINGS_FILENAME)
            if not os.path.exists(path):
                continue
            with open(path, "r", encoding="utf-8") as stream:
                data = json.load(stream)
            if not isinstance(data, dict):
                continue
            try:
                schema_version = max(schema_version, int(data.get("schema_version", 1) or 1))
            except Exception:
                pass
            assets = data.get("object_assets", [])
            if isinstance(assets, list):
                for asset in assets:
                    if not isinstance(asset, dict):
                        continue
                    key = (
                        str(asset.get("pack_id") or ""),
                        _safe_int(asset.get("definition_id")),
                    )
                    if not key[0] or not key[1] or key in seen_assets:
                        continue
                    seen_assets.add(key)
                    merged_assets.append(asset)
            bindings = data.get("object_bindings", [])
            if not isinstance(bindings, list):
                continue
            for binding in bindings:
                if not isinstance(binding, dict):
                    continue
                key = (
                    str(binding.get("pack_id") or ""),
                    str(binding.get("pose_name") or ""),
                    _safe_int(binding.get("definition_id")),
                )
                if not key[0] or not key[1] or not key[2] or key in seen:
                    continue
                seen.add(key)
                merged.append(binding)
        except Exception:
            continue
    return {
        "schema_version": max(schema_version, 2 if merged_assets else schema_version),
        "object_assets": merged_assets,
        "object_bindings": merged,
    }


def _save_data(data):
    try:
        target_dir = _primary_dir()
        target_path = _path_in(target_dir, OBJECT_BINDINGS_FILENAME)
        tmp_path = _path_in(target_dir, OBJECT_BINDINGS_TMP_FILENAME)
        bak_path = _path_in(target_dir, OBJECT_BINDINGS_BAK_FILENAME)
        with open(tmp_path, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False)
        if os.path.exists(target_path):
            if os.path.exists(bak_path):
                os.remove(bak_path)
            os.rename(target_path, bak_path)
        os.rename(tmp_path, target_path)
        return True
    except Exception:
        return False


def iter_saved_object_bindings():
    data = _load_data()
    for binding in data.get("object_bindings", []) or []:
        if isinstance(binding, dict):
            yield binding


def iter_saved_object_assets():
    data = _load_data()
    seen = set()

    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            continue
        pack_id = str(asset.get("pack_id") or "").strip()
        definition_id = _safe_int(asset.get("definition_id"))
        key = (pack_id, definition_id)
        if not pack_id or not definition_id or key in seen:
            continue
        seen.add(key)
        yield asset

    for binding in data.get("object_bindings", []) or []:
        if not isinstance(binding, dict):
            continue
        pack_id = str(binding.get("pack_id") or "").strip()
        definition_id = _safe_int(binding.get("definition_id"))
        key = (pack_id, definition_id)
        if not pack_id or not definition_id or key in seen:
            continue
        seen.add(key)
        yield {
            "asset_kind": "object",
            "source_type": binding.get("source_type") or "unknown",
            "user_group": binding.get("user_group") or "in_game_binding",
            "pack_id": pack_id,
            "definition_id": definition_id,
            "display_name": binding.get("display_name") or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": binding.get("created_at") or "",
            "updated_at": binding.get("updated_at") or "",
        }


def has_saved_object_binding(pack_id, pose_name, definition_id):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    definition_id = _safe_int(definition_id)
    if not pack_id or not pose_name or not definition_id:
        return False
    for binding in iter_saved_object_bindings():
        if (
            str(binding.get("pack_id") or "").strip() == pack_id
            and str(binding.get("pose_name") or "").strip() == pose_name
            and _safe_int(binding.get("definition_id")) == definition_id
        ):
            return True
    return False


def is_saved_object_asset(pack_id, definition_id):
    pack_id = str(pack_id or "").strip()
    definition_id = _safe_int(definition_id)
    if not pack_id or not definition_id:
        return False
    for asset in iter_saved_object_assets():
        if (
            str(asset.get("pack_id") or "").strip() == pack_id
            and _safe_int(asset.get("definition_id")) == definition_id
        ):
            return True
    return False


def get_saved_object_ids_for_pose(pack_id, pose_name):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    asset_ids = set()
    binding_ids = set()
    if not pack_id:
        return asset_ids, binding_ids

    data = _load_data()
    for asset in data.get("object_assets", []) or []:
        if not isinstance(asset, dict):
            continue
        definition_id = _safe_int(asset.get("definition_id"))
        if str(asset.get("pack_id") or "").strip() == pack_id and definition_id:
            asset_ids.add(definition_id)

    for binding in data.get("object_bindings", []) or []:
        if not isinstance(binding, dict):
            continue
        definition_id = _safe_int(binding.get("definition_id"))
        if str(binding.get("pack_id") or "").strip() != pack_id or not definition_id:
            continue
        asset_ids.add(definition_id)
        if pose_name and str(binding.get("pose_name") or "").strip() == pose_name:
            binding_ids.add(definition_id)

    return asset_ids, binding_ids


def save_object_binding(pack_id, pose_name, definition_id, display_name=None, source_type="unknown"):
    pack_id = str(pack_id or "").strip()
    pose_name = str(pose_name or "").strip()
    definition_id = _safe_int(definition_id)
    display_name = str(display_name or "").strip()
    source_type = str(source_type or "unknown").strip().lower() or "unknown"
    if source_type not in ("game", "cc", "unknown"):
        source_type = "unknown"
    if not pack_id or not pose_name or not definition_id:
        return False

    data = _load_data()
    data["schema_version"] = max(_safe_int(data.get("schema_version")) or 1, 2)
    assets = data.setdefault("object_assets", [])
    bindings = data.setdefault("object_bindings", [])
    now = _now_text()

    asset_updated = False
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        if (
            str(asset.get("pack_id") or "") == pack_id
            and _safe_int(asset.get("definition_id")) == definition_id
        ):
            asset["display_name"] = display_name or asset.get("display_name") or "Object {}".format(definition_id)
            asset["source_type"] = source_type
            asset["updated_at"] = now
            asset_updated = True
            break
    if not asset_updated:
        assets.append({
            "asset_kind": "object",
            "source_type": source_type,
            "user_group": "in_game_binding",
            "pack_id": pack_id,
            "definition_id": definition_id,
            "display_name": display_name or "Object {}".format(definition_id),
            "created_in_game": True,
            "created_at": now,
            "updated_at": now,
        })

    for binding in bindings:
        if not isinstance(binding, dict):
            continue
        if (
            str(binding.get("pack_id") or "") == pack_id
            and str(binding.get("pose_name") or "") == pose_name
            and _safe_int(binding.get("definition_id")) == definition_id
        ):
            binding["display_name"] = display_name or binding.get("display_name") or "Object {}".format(definition_id)
            binding["source_type"] = source_type
            binding["updated_at"] = now
            return _save_data(data)

    bindings.append({
        "asset_kind": "object",
        "source_type": source_type,
        "user_group": "in_game_binding",
        "pack_id": pack_id,
        "pose_name": pose_name,
        "definition_id": definition_id,
        "display_name": display_name or "Object {}".format(definition_id),
        "created_in_game": True,
        "created_at": now,
        "updated_at": now,
    })
    return _save_data(data)

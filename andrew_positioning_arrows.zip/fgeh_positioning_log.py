import datetime
import os
import traceback


ENABLE_POSITIONING_DEBUG_LOG = True


def _get_log_paths():
    filename = "fgeh_positioning_debug.log"
    roots = (
        "E:\\文档\\Electronic Arts\\The Sims 4",
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    )
    paths = []
    for root in roots:
        if not root:
            continue
        paths.append(os.path.join(root, filename))
        paths.append(os.path.join(root, "Mods", filename))
    return paths


def _write_line(line):
    if not ENABLE_POSITIONING_DEBUG_LOG:
        return
    for path in _get_log_paths():
        try:
            parent = os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                continue
            with open(path, "a", encoding="utf-8") as log_file:
                log_file.write(line + "\n")
            return
        except Exception:
            pass


def positioning_log(message, *args):
    if not ENABLE_POSITIONING_DEBUG_LOG:
        return
    try:
        text = message.format(*args) if args else str(message)
    except Exception:
        text = "{} args={}".format(message, args)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _write_line("[{}] [FGEH_Positioning] {}".format(timestamp, text))


def positioning_log_exception(label):
    positioning_log("{}\n{}", label, traceback.format_exc())

import traceback
import os
import time

import sims4.log
import services

import fgeh_cas_accessory_settings as settings

try:
    from cas.cas import get_caspart_bodytype
except Exception:
    get_caspart_bodytype = None

try:
    from sims.outfits.outfit_enums import OutfitCategory
except Exception:
    OutfitCategory = None


logger = sims4.log.Logger("FGEH_CAS_Accessory", default_owner="fgeh")

_original_outfit_by_sim_id = {}


def _get_debug_log_paths():
    paths = []
    filename = "fgeh_cas_accessory_debug.log"
    try:
        mod_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        if mod_dir:
            paths.append(os.path.join(mod_dir, filename))
    except Exception:
        pass
    for sims_dir in (
        "E:\\\u6587\u6863\\Electronic Arts\\The Sims 4",
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    ):
        try:
            if sims_dir and os.path.isdir(sims_dir):
                paths.append(os.path.join(sims_dir, filename))
                mods_dir = os.path.join(sims_dir, "Mods")
                if os.path.isdir(mods_dir):
                    paths.append(os.path.join(mods_dir, filename))
        except Exception:
            pass
    try:
        paths.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), filename))
    except Exception:
        pass
    return paths


def _write_debug_log(line):
    for path in _get_debug_log_paths():
        try:
            with open(path, "a", encoding="utf-8") as log_file:
                log_file.write(line + "\n")
        except Exception:
            pass


def _log(message, *args):
    try:
        line = message.format(*args)
    except Exception:
        line = str(message)
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    _write_debug_log("[{}] [FGEH_CAS_Accessory] {}".format(timestamp, line))
    try:
        logger.warn(message, *args)
    except Exception:
        try:
            logger.error(message, *args)
        except Exception:
            pass


def _log_exception(label):
    _log("{}\n{}", label, traceback.format_exc())


def debug_log(message, *args):
    _log(message, *args)


def _safe_list(value):
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def get_sim_info_from_target(target):
    if target is None:
        _log("get_sim_info_from_target: target is None")
        return None
    try:
        sim_info = getattr(target, "sim_info", None)
        if sim_info is not None:
            return sim_info
    except Exception:
        _log_exception("get_sim_info_from_target failed")
    _log("get_sim_info_from_target: no sim_info on target {}", target)
    return None


def dump_current_outfit_parts(sim_info):
    if sim_info is None:
        _log("dump_current_outfit_parts: sim_info is None")
        return False

    try:
        current_outfit = sim_info.get_current_outfit()
        _log("Dump outfit parts for sim_id={} current_outfit={}", getattr(sim_info, "sim_id", None), current_outfit)
        outfits_msg = sim_info.save_outfits()
        outfits = _safe_list(getattr(outfits_msg, "outfits", None))
        _log("save_outfits returned {} outfit proto rows", len(outfits))

        for proto_index, outfit_data in enumerate(outfits):
            parts = getattr(getattr(outfit_data, "parts", None), "ids", None)
            body_types = getattr(getattr(outfit_data, "body_types_list", None), "body_types", None)
            color_shifts = getattr(getattr(outfit_data, "part_shifts", None), "color_shift", None)
            object_ids = getattr(getattr(outfit_data, "object_ids", None), "object_id", None)
            _log(
                "Outfit proto_index={} category={} outfit_id={} parts={} body_types={} color_shifts={} object_ids={}",
                proto_index,
                getattr(outfit_data, "category", None),
                getattr(outfit_data, "outfit_id", None),
                _safe_list(parts),
                _safe_list(body_types),
                _safe_list(color_shifts),
                _safe_list(object_ids),
            )
        return True
    except Exception:
        _log_exception("dump_current_outfit_parts failed")
        return False


def find_outfit_data(outfits_msg, outfit_key):
    try:
        category, outfit_index = outfit_key
        category_int = int(category)
        matching = []
        for proto_index, outfit_data in enumerate(_safe_list(getattr(outfits_msg, "outfits", None))):
            if int(getattr(outfit_data, "category", -1)) == category_int:
                matching.append((proto_index, outfit_data))

        _log(
            "find_outfit_data key={} category_matches={} outfit_ids={}",
            outfit_key,
            len(matching),
            [getattr(item[1], "outfit_id", None) for item in matching],
        )

        if 0 <= int(outfit_index) < len(matching):
            return matching[int(outfit_index)][1]
    except Exception:
        _log_exception("find_outfit_data failed")
    return None


def _get_parallel_field(outfit_data, path):
    value = outfit_data
    for name in path:
        value = getattr(value, name, None)
        if value is None:
            return None
    return value


def replace_cas_part_in_outfit_data(outfit_data, new_part_id):
    if outfit_data is None:
        _log("replace_cas_part_in_outfit_data: outfit_data is None")
        return False
    if not new_part_id:
        _log("replace_cas_part_in_outfit_data: TEST_CAS_PART_ID is 0; set a real CASP instance id first")
        return False
    if get_caspart_bodytype is None:
        _log("replace_cas_part_in_outfit_data: cas.cas.get_caspart_bodytype is unavailable")
        return False

    try:
        new_body_type = get_caspart_bodytype(int(new_part_id))
        if new_body_type is None:
            _log("CAS part {} returned body type None", new_part_id)
            return False

        parts = _get_parallel_field(outfit_data, ("parts", "ids"))
        body_types = _get_parallel_field(outfit_data, ("body_types_list", "body_types"))
        color_shifts = _get_parallel_field(outfit_data, ("part_shifts", "color_shift"))
        object_ids = _get_parallel_field(outfit_data, ("object_ids", "object_id"))
        if parts is None or body_types is None:
            _log("OutfitData has missing parts/body_types fields: parts={} body_types={}", parts, body_types)
            return False

        before_parts = _safe_list(parts)
        before_body_types = _safe_list(body_types)
        _log("Before replace: parts={} body_types={} new_part={} new_body_type={}", before_parts, before_body_types, new_part_id, new_body_type)

        replace_index = None
        for index, body_type in enumerate(before_body_types):
            if int(body_type) == int(new_body_type):
                replace_index = index
                break

        if replace_index is not None and replace_index < len(parts):
            parts[replace_index] = int(new_part_id)
            _log("Replaced CAS part at index={} body_type={}", replace_index, new_body_type)
        else:
            parts.append(int(new_part_id))
            body_types.append(int(new_body_type))
            if color_shifts is not None:
                color_shifts.append(int(settings.DEFAULT_COLOR_SHIFT))
            if object_ids is not None:
                object_ids.append(0)
            _log("Appended CAS part body_type={}", new_body_type)

        _log(
            "After replace: parts={} body_types={} color_shifts={} object_ids={}",
            _safe_list(parts),
            _safe_list(body_types),
            _safe_list(color_shifts),
            _safe_list(object_ids),
        )
        return True
    except Exception:
        _log_exception("replace_cas_part_in_outfit_data failed")
        return False


def _get_special_outfit_key():
    if OutfitCategory is None:
        return None
    return (OutfitCategory.SPECIAL, settings.USE_SPECIAL_OUTFIT_INDEX)


def _normalize_outfit_key(outfit_key):
    try:
        category, outfit_index = outfit_key
        return (int(category), int(outfit_index))
    except Exception:
        return outfit_key


def _is_linked_temp_outfit(outfit_key):
    temp_outfit = _get_special_outfit_key()
    if temp_outfit is None or outfit_key is None:
        return False
    return _normalize_outfit_key(outfit_key) == _normalize_outfit_key(temp_outfit)


def _get_everyday_fallback_outfit():
    if OutfitCategory is None:
        return None
    try:
        return (OutfitCategory.EVERYDAY, 0)
    except Exception:
        return None


def _get_safe_original_outfit(sim_info):
    try:
        current_outfit = sim_info.get_current_outfit()
    except Exception:
        _log_exception("_get_safe_original_outfit get_current_outfit failed")
        current_outfit = None

    if not _is_linked_temp_outfit(current_outfit):
        return current_outfit

    existing_backup = _original_outfit_by_sim_id.get(getattr(sim_info, "sim_id", None))
    if existing_backup is not None and not _is_linked_temp_outfit(existing_backup):
        _log("Current outfit is linked temp; reusing existing safe backup {}", existing_backup)
        return existing_backup

    fallback = _get_everyday_fallback_outfit()
    _log("Current outfit is linked temp and no safe backup exists; using fallback original {}", fallback)
    return fallback if fallback is not None else current_outfit


def _get_source_outfit_for_apply(sim_id, current_outfit, original_outfit):
    existing_backup = _original_outfit_by_sim_id.get(sim_id)
    if _is_linked_temp_outfit(current_outfit) and existing_backup is not None and not _is_linked_temp_outfit(existing_backup):
        return current_outfit
    return original_outfit


def _refresh_current_outfit(sim_info, outfit_key, label):
    before = None
    try:
        before = sim_info.get_current_outfit()
    except Exception:
        pass
    _log("{} refresh begin outfit_key={} current_before={}", label, outfit_key, before)
    try:
        sim_info.load_outfits(sim_info.save_outfits())
    except Exception:
        _log_exception("{} load_outfits/save_outfits refresh failed".format(label))
    try:
        sim_info.resend_outfits()
    except Exception:
        _log_exception("{} resend_outfits failed".format(label))
    try:
        sim_info.resend_current_outfit()
    except Exception:
        _log_exception("{} resend_current_outfit failed".format(label))
    after = None
    try:
        after = sim_info.get_current_outfit()
    except Exception:
        pass
    _log("{} refresh end outfit_key={} current_after={}", label, outfit_key, after)


def apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=None):
    if sim_info is None:
        _log("apply_fixed_cas_accessory_to_sim: sim_info is None")
        return False

    if cas_part_id is None:
        _log("No snippet CASP id supplied; using settings.TEST_CAS_PART_ID={}", settings.TEST_CAS_PART_ID)
        cas_part_id = settings.TEST_CAS_PART_ID
    else:
        _log("Using CASP id supplied by snippet/argument: {}", cas_part_id)
    if not cas_part_id:
        _log("apply_fixed_cas_accessory_to_sim: TEST_CAS_PART_ID is still 0")
        return False

    temp_outfit = _get_special_outfit_key()
    if temp_outfit is None:
        _log("apply_fixed_cas_accessory_to_sim: OutfitCategory.SPECIAL unavailable")
        return False

    try:
        sim_id = getattr(sim_info, "sim_id", None)
        current_outfit = sim_info.get_current_outfit()
        original_outfit = _get_safe_original_outfit(sim_info)
        existing_backup = _original_outfit_by_sim_id.get(sim_id)
        if existing_backup is None:
            _original_outfit_by_sim_id[sim_id] = original_outfit
        elif _is_linked_temp_outfit(existing_backup) and not _is_linked_temp_outfit(original_outfit):
            _original_outfit_by_sim_id[sim_id] = original_outfit
            _log("Replaced contaminated original outfit backup sim_id={} old={} new={}", sim_id, existing_backup, original_outfit)
        source_outfit = _get_source_outfit_for_apply(sim_id, current_outfit, original_outfit)
        _log(
            "Applying fixed CAS accessory sim_id={} current={} current_is_temp={} original={} existing_backup={} source={} temp={} cas_part={} backup_keys={}",
            sim_id,
            current_outfit,
            _is_linked_temp_outfit(current_outfit),
            original_outfit,
            existing_backup,
            source_outfit,
            temp_outfit,
            cas_part_id,
            list(_original_outfit_by_sim_id.keys()),
        )

        sim_info.generate_merged_outfit(sim_info, temp_outfit, source_outfit, source_outfit)
        outfits_msg = sim_info.save_outfits()
        temp_outfit_data = find_outfit_data(outfits_msg, temp_outfit)
        if temp_outfit_data is None:
            _log("Could not find temp SPECIAL outfit data after generate_merged_outfit")
            return False

        if not replace_cas_part_in_outfit_data(temp_outfit_data, cas_part_id):
            return False

        sim_info.load_outfits(outfits_msg)
        try:
            sim_info.set_outfit_dirty(temp_outfit[0])
        except Exception:
            _log_exception("set_outfit_dirty failed")
        sim_info.set_current_outfit(temp_outfit)
        _refresh_current_outfit(sim_info, temp_outfit, "apply")

        _log("Applied fixed CAS accessory successfully sim_id={} temp={}", sim_id, temp_outfit)
        return True
    except Exception:
        _log_exception("apply_fixed_cas_accessory_to_sim failed")
        return False


def restore_original_outfit(sim_info):
    if sim_info is None:
        _log("restore_original_outfit: sim_info is None")
        return False

    try:
        sim_id = getattr(sim_info, "sim_id", None)
        current_before = sim_info.get_current_outfit()
        original_outfit = _original_outfit_by_sim_id.get(sim_id)
        _log(
            "restore_original_outfit begin sim_id={} current={} current_is_temp={} backup={} backup_keys={}",
            sim_id,
            current_before,
            _is_linked_temp_outfit(current_before),
            original_outfit,
            list(_original_outfit_by_sim_id.keys()),
        )
        if original_outfit is None:
            current_outfit = current_before
            if not _is_linked_temp_outfit(current_outfit):
                _log("No original outfit backup for sim_id={} current={} is not linked temp", sim_id, current_outfit)
                return False
            original_outfit = _get_everyday_fallback_outfit()
            if original_outfit is None:
                _log("No original outfit backup and no fallback outfit for sim_id={}", sim_id)
                return False
            _log("No original outfit backup for sim_id={}; current is linked temp {}, fallback restore to {}", sim_id, current_outfit, original_outfit)

        _log("Restoring original outfit sim_id={} outfit={}", sim_id, original_outfit)
        restored = sim_info.set_current_outfit(original_outfit)
        _log("restore set_current_outfit result sim_id={} result={} now={}", sim_id, restored, sim_info.get_current_outfit())
        if not restored:
            return False
        _refresh_current_outfit(sim_info, original_outfit, "restore")
        try:
            if sim_id in _original_outfit_by_sim_id:
                del _original_outfit_by_sim_id[sim_id]
        except Exception:
            pass
        _log("restore_original_outfit end sim_id={} current={} backup_removed={}", sim_id, sim_info.get_current_outfit(), sim_id not in _original_outfit_by_sim_id)
        return True
    except Exception:
        _log_exception("restore_original_outfit failed")
        return False


def _iter_instanced_sim_infos():
    try:
        sim_info_manager = services.sim_info_manager()
    except Exception:
        sim_info_manager = None
    if sim_info_manager is None:
        return
    try:
        for candidate in sim_info_manager.instanced_sims_gen():
            sim_info = getattr(candidate, "sim_info", None) or candidate
            if sim_info is not None:
                yield sim_info
    except Exception:
        _log_exception("_iter_instanced_sim_infos failed")


def _find_instanced_sim_info(sim_id):
    try:
        sim_info_manager = services.sim_info_manager()
    except Exception:
        sim_info_manager = None
    if sim_info_manager is not None:
        try:
            sim_info = sim_info_manager.get(sim_id)
            if sim_info is not None:
                return sim_info
        except Exception:
            pass
    try:
        for sim_info in _iter_instanced_sim_infos():
            if getattr(sim_info, "sim_id", None) == sim_id:
                return sim_info
    except Exception:
        pass
    return None


def restore_all_original_outfits():
    restored_count = 0
    try:
        backup_ids = list(_original_outfit_by_sim_id.keys())
    except Exception:
        backup_ids = []

    restored_sim_ids = set()
    for sim_id in backup_ids:
        sim_info = _find_instanced_sim_info(sim_id)
        if sim_info is None:
            _log("restore_all_original_outfits: sim_info not found for sim_id={}", sim_id)
            continue
        if restore_original_outfit(sim_info):
            restored_count += 1
            restored_sim_ids.add(sim_id)

    try:
        for sim_info in _iter_instanced_sim_infos():
            sim_id = getattr(sim_info, "sim_id", None)
            if sim_id in restored_sim_ids:
                continue
            try:
                current_outfit = sim_info.get_current_outfit()
            except Exception:
                continue
            if not _is_linked_temp_outfit(current_outfit):
                continue
            _log("restore_all_original_outfits: found linked temp outfit without active backup sim_id={} current={}", sim_id, current_outfit)
            if restore_original_outfit(sim_info):
                restored_count += 1
                restored_sim_ids.add(sim_id)
    except Exception:
        _log_exception("restore_all_original_outfits linked temp scan failed")

    _log("restore_all_original_outfits backup_count={} restored_count={}", len(backup_ids), restored_count)
    return restored_count

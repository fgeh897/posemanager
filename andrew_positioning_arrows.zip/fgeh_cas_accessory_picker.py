import traceback

import services
import sims4.resources

from interactions import ParticipantType
from interactions.base.immediate_interaction import ImmediateSuperInteraction
from interactions.base.picker_interaction import PickerSuperInteraction
from interactions.context import QueueInsertStrategy
from interactions.utils.tunable import TunableContinuation
from sims4.localization import LocalizationHelperTuning
from sims4.tuning.tunable import OptionalTunable, Tunable
from sims4.tuning.tunable_base import GroupNames
from sims4.utils import flexmethod
from ui.ui_dialog_picker import ObjectPickerRow

import fgeh_cas_accessory_settings as settings
from fgeh_cas_accessory_outfit_utils import (
    apply_fixed_cas_accessory_to_sim,
    debug_log,
    dump_current_outfit_parts,
    get_sim_info_from_target,
    restore_original_outfit,
)


ACCESSORY_TAG_PREFIX = "FGEH_ACC::"
VARIANT_TAG_PREFIX = "FGEH_ACC_VARIANT::"
RESTORE_TAG = "FGEH_ACC_RESTORE"
LOG_TAG = "FGEH_ACC_LOG"
BACK_TAG = "FGEH_ACC_BACK"
PACK_UNKNOWN = "Unknown"
ALL_ACCESSORIES_TAG = "FGEH_ACC_ALL"

DEFAULT_CATEGORY = "uncategorized"


class _FgehLinkedRequirementView:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)


def raw_text(text):
    try:
        return LocalizationHelperTuning.get_raw_text(str(text))
    except Exception:
        return str(text)


def _debug_exception(label):
    debug_log("{}\n{}", label, traceback.format_exc())


def _safe_list(value):
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def _make_row(name, icon=None, tag=None, description=None, count=0):
    kwargs = {
        "name": raw_text(name),
        "tag": tag,
    }
    if icon is not None:
        kwargs["icon"] = icon
    if description:
        kwargs["row_description"] = raw_text(description)
    if count:
        kwargs["count"] = count
    return ObjectPickerRow(**kwargs)


def _snippet_id(snippet):
    for attr_name in ("guid64", "guid", "instance_id", "tuning_id"):
        value = getattr(snippet, attr_name, None)
        if value:
            return str(value)
    return str(getattr(snippet, "__name__", snippet))


def _get_pose_pack_manager():
    try:
        return services.get_instance_manager(sims4.resources.Types.SNIPPET)
    except Exception:
        return None


def _is_pose_pack(snippet):
    try:
        return str(getattr(snippet, "s4s_mod_type", "")).upper() == "POSE_PACK"
    except Exception:
        return False


def _iter_pose_packs():
    manager = _get_pose_pack_manager()
    if manager is None:
        return
    for snippet in _safe_list(getattr(manager, "_tuned_classes", {}).values()):
        if _is_pose_pack(snippet):
            yield snippet


def _find_pose_pack_for_pose_name(pose_name):
    if not pose_name:
        return None
    pose_name = str(pose_name)
    for pack in _iter_pose_packs():
        for pose_item in _safe_list(getattr(pack, "pose_list", None)):
            if str(getattr(pose_item, "pose_name", "")) == pose_name:
                return pack
    return None


def _get_pose_name_from_positioning_session(sim):
    if sim is None:
        return None

    session_getter = None
    try:
        from andrew_positioning_session import get_target_sessions_for_sim
        session_getter = get_target_sessions_for_sim
    except Exception:
        try:
            from object_positioning_session import get_target_sessions_for_sim
            session_getter = get_target_sessions_for_sim
        except Exception:
            return None

    try:
        sessions = list(session_getter(sim))
    except Exception:
        _debug_exception("Failed to read positioning sessions for active pose")
        return None

    for session in reversed(sessions):
        try:
            if getattr(session, "is_canceled", False):
                continue
            pose_name = session.get_pose_name()
            if pose_name:
                debug_log(
                    "Current pose name resolved from positioning session={} pose_name={}",
                    getattr(session, "get_identifier", lambda: None)(),
                    pose_name,
                )
                return pose_name
        except Exception:
            continue

    return None


def _iter_interactions_for_sim(sim):
    if sim is None:
        return
    try:
        for interaction in getattr(sim, "si_state", ()):
            yield interaction
    except Exception:
        pass
    for attr_name in ("queue", "si_state"):
        owner = getattr(sim, attr_name, None)
        if owner is None:
            continue
        for method_name in ("running", "queued_interactions_gen", "all_interactions_gen"):
            method = getattr(owner, method_name, None)
            if not callable(method):
                continue
            try:
                for interaction in method():
                    yield interaction
            except Exception:
                pass
    for attr_name in ("interaction_refs", "_interaction_refs"):
        for interaction in _safe_list(getattr(sim, attr_name, None)):
            yield interaction


def get_current_pose_pack_for_sim(sim):
    for interaction in _iter_interactions_for_sim(sim):
        pose_name = getattr(interaction, "pose_name", None)
        if not pose_name:
            interaction_parameters = getattr(interaction, "interaction_parameters", None)
            if isinstance(interaction_parameters, dict):
                pose_name = interaction_parameters.get("pose_name")
            else:
                pose_name = getattr(interaction_parameters, "pose_name", None)
        pack = _find_pose_pack_for_pose_name(pose_name)
        if pack is not None:
            debug_log("Current pose pack resolved from pose_name={} pack_id={}", pose_name, getattr(pack, "__name__", None))
            return pack

    pose_name = _get_pose_name_from_positioning_session(sim)
    pack = _find_pose_pack_for_pose_name(pose_name)
    if pack is not None:
        debug_log(
            "Current pose pack resolved from positioning session pose_name={} pack_id={}",
            pose_name,
            getattr(pack, "__name__", None),
        )

        return pack

    debug_log("Current pose pack not found from active pose interactions.")
    return None


def _is_fgeh_pose_metadata(snippet):
    class_name = snippet.__class__.__name__
    if class_name == "FGEHPoseMetadataSnippet":
        return True
    return hasattr(snippet, "accessory_cas_part_id") or hasattr(snippet, "accessories")


def iter_accessory_metadata_snippets():
    manager = _get_pose_pack_manager()
    if manager is None:
        return
    for snippet in _safe_list(getattr(manager, "_tuned_classes", {}).values()):
        if _is_fgeh_pose_metadata(snippet):
            yield snippet


def _get_pack_key(pack):
    if pack is None:
        return ""
    return str(getattr(pack, "__name__", "") or getattr(pack, "pack_id", "") or "")


def get_accessory_snippets_for_pose_pack(pack):
    pack_id = _get_pack_key(pack)
    matches = []
    for snippet in iter_accessory_metadata_snippets():
        if getattr(snippet, "disabled", False):
            debug_log(
                "Skipped disabled accessory metadata snippet name={} binding={}",
                getattr(snippet, "__name__", None),
                getattr(snippet, "binding_display_name", None),
            )
            continue

        snippet_pack_id = str(getattr(snippet, "pack_id", "") or "")
        snippet_source_pack_name = str(getattr(snippet, "source_pose_pack_name", "") or "")
        if pack_id and (snippet_pack_id == pack_id or snippet_source_pack_name == pack_id):
            matches.append(snippet)
    debug_log("Accessory snippets for pack_id={} count={}", pack_id, len(matches))
    return matches


def _entry_variants(entry):
    variants = _safe_list(getattr(entry, "variants", None))
    legacy_cas_part_id = getattr(entry, "cas_part_id", None)
    if not variants and legacy_cas_part_id:
        return [entry]
    return variants


def _entry_label(entry, fallback):
    return (
        getattr(entry, "label", None)
        or getattr(entry, "display_name", None)
        or fallback
    )


def _entry_description(entry):
    return getattr(entry, "description_text", None) or getattr(entry, "description", None) or ""


def _import_icon_info_data():
    try:
        from distributor.shared_messages import IconInfoData
        return IconInfoData
    except Exception:
        pass

    try:
        from interactions.utils.tunable_icon import IconInfoData
        return IconInfoData
    except Exception:
        pass

    return None


def _make_resource_key(type_id, group, instance):
    # Proven TS4 helper order: instance, type, group.
    try:
        get_resource_key = getattr(sims4.resources, "get_resource_key", None)
        if callable(get_resource_key):
            return get_resource_key(instance, type_id, group)
    except Exception as exc:
        debug_log(
            "get_resource_key failed type={:08X} group={:08X} instance={:016X}: {}",
            type_id,
            group,
            instance,
            exc,
        )

    # Project-owned icons use Key(type, instance, group).
    try:
        key_class = getattr(sims4.resources, "Key", None)
        if key_class is not None:
            return key_class(type_id, instance, group)
    except Exception as exc:
        debug_log(
            "Key constructor failed type={:08X} group={:08X} instance={:016X}: {}",
            type_id,
            group,
            instance,
            exc,
        )

    return None


def _parse_thumbnail_key(thumbnail_text):
    if not thumbnail_text:
        return None

    text = str(thumbnail_text).strip().replace("-", ":")
    parts = [part.strip() for part in text.split(":") if part.strip()]
    if len(parts) != 3:
        debug_log("Invalid thumbnail key format: {}", thumbnail_text)
        return None

    try:
        type_id = int(parts[0], 16)
        group = int(parts[1], 16)
        instance = int(parts[2], 16)
    except Exception as exc:
        debug_log("Failed to parse thumbnail key {}: {}", thumbnail_text, exc)
        return None

    key = _make_resource_key(type_id, group, instance)
    if key is None:
        debug_log("Failed to create resource key for thumbnail {}", thumbnail_text)
    else:
        debug_log(
            "Thumbnail key parsed text={} type={:08X} group={:08X} instance={:016X} key={}",
            thumbnail_text,
            type_id,
            group,
            instance,
            key,
        )
    return key


def _thumbnail_icon_from_text(thumbnail_text):
    key = _parse_thumbnail_key(thumbnail_text)
    if key is None:
        return None

    # ObjectPickerRow(icon=...) expects a ResourceKey-like object with .type/.group/.instance.
    # Do NOT wrap this in IconInfoData here; ui_dialog_picker will try to access icon.type.
    return key


def _thumbnail_icon_from_entry(entry):
    thumbnail = getattr(entry, "thumbnail", "") or ""
    icon = _thumbnail_icon_from_text(thumbnail)
    debug_log(
        "Thumbnail lookup entry_label={} thumbnail={} resolved_icon={}",
        _entry_label(entry, ""),
        thumbnail,
        icon,
    )
    return icon


def _entry_icon(entry, fallback=None):
    explicit_icon = getattr(entry, "icon", None)
    if explicit_icon is not None:
        debug_log(
            "Icon selected source=explicit entry_label={} icon={}",
            _entry_label(entry, ""),
            explicit_icon,
        )
        return explicit_icon

    thumbnail_icon = _thumbnail_icon_from_entry(entry)
    if thumbnail_icon is not None:
        debug_log(
            "Icon selected source=entry_thumbnail entry_label={} icon={}",
            _entry_label(entry, ""),
            thumbnail_icon,
        )
        return thumbnail_icon

    for variant in _safe_list(getattr(entry, "variants", None)):
        thumbnail_icon = _thumbnail_icon_from_entry(variant)
        if thumbnail_icon is not None:
            debug_log(
                "Icon selected source=first_variant_thumbnail entry_label={} variant_label={} icon={}",
                _entry_label(entry, ""),
                _entry_label(variant, ""),
                thumbnail_icon,
            )
            return thumbnail_icon

    debug_log(
        "Icon selected source=fallback entry_label={} icon={}",
        _entry_label(entry, ""),
        fallback,
    )
    return fallback


def _entry_cas_part_id(entry):
    value = getattr(entry, "cas_part_id", None)
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _entry_object_definition_id(entry):
    for attr_name in ("object_definition_id", "definition_id"):
        value = getattr(entry, attr_name, None)
        try:
            value = int(value) if value else 0
        except Exception:
            value = 0
        if value:
            return value
    return 0


def _entry_object_tuning_id(entry):
    value = getattr(entry, "object_tuning_id", None)
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _normalize_category(value):
    text = str(value or "").strip().lower()
    return text or DEFAULT_CATEGORY


def _entry_category(entry):
    return _normalize_category(
        getattr(entry, "category", None)
        or getattr(entry, "category_id", None)
        or getattr(entry, "asset_kind", None)
        or getattr(entry, "resource_type", None)
    )


def _category_matches(entry, category_filter):
    if not category_filter:
        return True
    category_filter = _normalize_category(category_filter)
    return _entry_category(entry) == category_filter


def _filter_entries_by_category(entries, category_filter):
    if not category_filter:
        return entries
    category_filter = _normalize_category(category_filter)
    filtered = [
        entry_info for entry_info in entries
        if _category_matches(entry_info.get("entry"), category_filter)
    ]
    debug_log(
        "Filtered accessory entries category_filter={} before={} after={}",
        category_filter,
        len(entries),
        len(filtered),
    )
    return filtered


def _entry_pose_names(entry):
    raw_pose_names = getattr(entry, "pose_names", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "poses", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "pose_name", None)

    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    try:
        iterator = list(raw_pose_names)
    except Exception:
        iterator = []

    for pose_name in iterator:
        pose_name = str(pose_name or "").strip()
        if pose_name:
            result.append(pose_name)

    return result


def _entry_matches_pose_name(entry, pose_name):
    pose_name = str(pose_name or "").strip()
    entry_pose_names = _entry_pose_names(entry)
    if not entry_pose_names:
        return True
    return pose_name in entry_pose_names


def _filter_entries_by_pose_name(entries, pose_name):
    if not pose_name:
        return entries
    filtered = [
        entry_info for entry_info in entries
        if _entry_matches_pose_name(entry_info.get("entry"), pose_name)
    ]
    debug_log(
        "Filtered accessory entries pose_name={} before={} after={}",
        pose_name,
        len(entries),
        len(filtered),
    )
    return filtered


def _variant_signature(variant):
    return (
        str(_entry_label(variant, "")),
        str(_entry_description(variant)),
        int(_entry_cas_part_id(variant) or 0),
        int(_entry_object_definition_id(variant) or 0),
        int(_entry_object_tuning_id(variant) or 0),
    )


def _dedupe_variants(variants):
    result = []
    seen = set()

    for variant in variants:
        signature = _variant_signature(variant)
        if signature in seen:
            debug_log(
                "Skipped duplicate accessory variant: label={} cas_part_id={}",
                _entry_label(variant, ""),
                _entry_cas_part_id(variant),
            )
            continue

        seen.add(signature)
        result.append(variant)

    return result


def _entry_signature(label, description, variants):
    cas_part_ids = []
    object_definition_ids = []
    object_tuning_ids = []
    variant_labels = []

    for variant in variants:
        cas_part_id = _entry_cas_part_id(variant)
        if cas_part_id:
            cas_part_ids.append(int(cas_part_id))
        object_definition_id = _entry_object_definition_id(variant)
        if object_definition_id:
            object_definition_ids.append(int(object_definition_id))
        object_tuning_id = _entry_object_tuning_id(variant)
        if object_tuning_id:
            object_tuning_ids.append(int(object_tuning_id))
        variant_labels.append(str(_entry_label(variant, "")))

    return (
        str(label or ""),
        str(description or ""),
        tuple(sorted(set(cas_part_ids))),
        tuple(sorted(set(object_definition_ids))),
        tuple(sorted(set(object_tuning_ids))),
        tuple(sorted(set(variant_labels))),
    )


def _asset_id(asset):
    return str(getattr(asset, "asset_id", "") or "").strip()


def _link_asset_id(link):
    return str(getattr(link, "asset_id", "") or "").strip()


def _get_v3_pose_names(snippet, link):
    target_type = str(getattr(link, "target_type", "") or "").strip().lower()
    target_id = str(getattr(link, "target_id", "") or "").strip()
    pose_name = str(getattr(link, "pose_name", "") or "").strip()
    snippet_pack_ids = set((
        str(getattr(snippet, "pack_id", "") or "").strip(),
        str(getattr(snippet, "source_pose_pack_name", "") or "").strip(),
    ))

    if target_type == "pose":
        return [target_id or pose_name] if (target_id or pose_name) else []
    if target_type == "pack":
        return []
    if pose_name and pose_name not in snippet_pack_ids:
        return [pose_name]
    return []


def _build_v3_accessory_entries(snippet, seen_entries):
    assets = _safe_list(getattr(snippet, "assets", None))
    links = _safe_list(getattr(snippet, "action_links", None))
    if not assets or not links:
        return []

    assets_by_id = {}
    for asset in assets:
        asset_id = _asset_id(asset)
        if asset_id:
            assets_by_id[asset_id] = asset

    result = []
    for link in links:
        asset_id = _link_asset_id(link)
        asset = assets_by_id.get(asset_id)
        if asset is None:
            debug_log(
                "Skipped v3 action link without matching asset: link_id={} asset_id={}",
                getattr(link, "link_id", None),
                asset_id,
            )
            continue

        variants = _dedupe_variants(_safe_list(getattr(asset, "variants", None)))
        if not variants:
            debug_log(
                "Skipped v3 asset without variants: asset_id={} label={}",
                asset_id,
                getattr(asset, "label", None),
            )
            continue

        category = (
            getattr(link, "category_id", None)
            or getattr(asset, "category_id", None)
            or getattr(link, "asset_kind", None)
            or getattr(asset, "asset_kind", None)
            or "cas"
        )
        resource_type = (
            getattr(link, "asset_kind", None)
            or getattr(asset, "asset_kind", None)
            or category
            or "cas"
        )
        label = _entry_label(asset, asset_id or "Linked Asset")
        description = (
            _entry_description(asset)
            or getattr(link, "ui_group", None)
            or getattr(snippet, "binding_display_name", None)
            or ""
        )
        pose_names = _get_v3_pose_names(snippet, link)
        link_id = str(getattr(link, "link_id", "") or "")
        unique_signature = (
            "v3",
            asset_id,
            link_id,
            tuple(pose_names),
            _entry_signature(label, description, variants),
        )
        if unique_signature in seen_entries:
            debug_log(
                "Skipped duplicate v3 linked asset: asset_id={} link_id={}",
                asset_id,
                link_id,
            )
            continue

        seen_entries.add(unique_signature)
        entry = _FgehLinkedRequirementView(
            label=label,
            display_name=label,
            description_text=description,
            category=category,
            category_id=category,
            resource_type=resource_type,
            asset_kind=resource_type,
            asset_id=asset_id,
            link_id=link_id,
            requirement=getattr(link, "requirement", "") or "recommended",
            role=getattr(link, "role", "") or "",
            pose_names=pose_names,
            variants=variants,
        )
        result.append({
            "snippet": snippet,
            "entry": entry,
            "variants": variants,
            "label": label,
            "description": description,
            "category": _normalize_category(category),
            "resource_type": str(resource_type or "").strip().lower(),
            "asset_id": asset_id,
            "link_id": link_id,
            "icon": _entry_icon(asset, getattr(snippet, "icon", None)),
        })

    if result:
        debug_log(
            "Built v3 linked entries snippet={} count={}",
            getattr(snippet, "__name__", None),
            len(result),
        )
    return result


def build_accessory_entries(snippets):
    entries = []
    seen_entries = set()

    for snippet in snippets:
        v3_entries = _build_v3_accessory_entries(snippet, seen_entries)
        if v3_entries:
            entries.extend(v3_entries)
            continue

        snippet_entries = _safe_list(getattr(snippet, "accessories", None))

        if not snippet_entries:
            legacy_cas_part_id = getattr(snippet, "accessory_cas_part_id", None)
            if legacy_cas_part_id:
                variants = [snippet]
                label = getattr(snippet, "pack_name", None) or "Accessory"
                description = getattr(snippet, "pack_id", None) or ""

                signature = _entry_signature(label, description, variants)
                if signature in seen_entries:
                    debug_log(
                        "Skipped duplicate legacy accessory entry: label={} cas_part_id={}",
                        label,
                        legacy_cas_part_id,
                    )
                    continue

                seen_entries.add(signature)

                entries.append({
                    "snippet": snippet,
                    "entry": snippet,
                    "variants": variants,
                    "label": label,
                    "description": description,
                    "category": "accessory",
                    "icon": getattr(snippet, "icon", None),
                })

            continue

        for index, entry in enumerate(snippet_entries):
            variants = _dedupe_variants(_entry_variants(entry))
            if not variants:
                continue

            label = _entry_label(entry, "Accessory {}".format(index + 1))
            description = _entry_description(entry)
            icon = _entry_icon(entry, getattr(snippet, "icon", None))

            signature = _entry_signature(label, description, variants)
            if signature in seen_entries:
                debug_log(
                    "Skipped duplicate accessory entry: label={} description={} variant_count={}",
                    label,
                    description,
                    len(variants),
                )
                continue

            seen_entries.add(signature)

            entries.append({
                "snippet": snippet,
                "entry": entry,
                "variants": variants,
                "label": label,
                "description": description,
                "category": _entry_category(entry),
                "icon": icon,
            })

    debug_log("build_accessory_entries deduped result count={}", len(entries))
    return entries


def get_picker_entries_for_interaction(interaction):
    target = getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target)
    if sim_info is None:
        return None, []

    active_pack = get_current_pose_pack_for_sim(target)
    snippets = get_accessory_snippets_for_pose_pack(active_pack)

    if not snippets:
        debug_log("No active pack metadata matched; linked entries count=0")
        return active_pack, []

    entries = build_accessory_entries(snippets)
    entries = _filter_entries_by_category(entries, getattr(interaction, "category_filter", ""))
    return active_pack, entries


def get_all_accessory_entries():
    snippets = list(iter_accessory_metadata_snippets())
    debug_log("All accessory snippets count={}", len(snippets))
    return build_accessory_entries(snippets)


def get_entries_for_source_mode(interaction, source_mode):
    if source_mode == "all":
        return _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(interaction, "category_filter", ""),
        )

    active_pack, entries = get_picker_entries_for_interaction(interaction)
    return entries


def dump_picker_debug_info(interaction):
    target = getattr(interaction, "target", None)
    sim_info = get_sim_info_from_target(target)

    debug_log("========== FGEH ACCESSORY PICKER DEBUG START ==========")
    debug_log("Picker debug target={} sim_info={} sim_id={}", target, sim_info, getattr(sim_info, "sim_id", None))

    active_pack = get_current_pose_pack_for_sim(target)
    debug_log(
        "Picker debug active_pack={} pack_name={} sort_name={}",
        getattr(active_pack, "__name__", None),
        getattr(active_pack, "display_name", None),
        getattr(active_pack, "sort_name", None),
    )

    snippets = get_accessory_snippets_for_pose_pack(active_pack)
    debug_log("Picker debug matched metadata snippets count={}", len(snippets))

    if not snippets:
        fallback_snippets = list(iter_accessory_metadata_snippets())
        debug_log("Picker debug fallback metadata snippets count={}", len(fallback_snippets))
        snippets = fallback_snippets

    for snippet_index, snippet in enumerate(snippets):
        debug_log(
            "Metadata snippet[{}]: name={} binding_display_name={} pack_id={} pack_name={} accessory_cas_part_id={}",
            snippet_index,
            getattr(snippet, "__name__", None),
            getattr(snippet, "binding_display_name", None),
            getattr(snippet, "pack_id", None),
            getattr(snippet, "pack_name", None),
            getattr(snippet, "accessory_cas_part_id", None),
        )

    entries = build_accessory_entries(snippets)
    debug_log("Picker debug accessory entries count={}", len(entries))

    for entry_index, entry_info in enumerate(entries):
        debug_log(
            "Entry[{}]: label={} description={} variant_count={}",
            entry_index,
            entry_info.get("label"),
            entry_info.get("description"),
            len(entry_info.get("variants", ())),
        )

        for variant_index, variant in enumerate(entry_info.get("variants", ())):
            debug_log(
                "Entry[{}] Variant[{}]: label={} description={} cas_part_id={} thumbnail={}",
                entry_index,
                variant_index,
                _entry_label(variant, "Variant {}".format(variant_index + 1)),
                _entry_description(variant),
                _entry_cas_part_id(variant),
                getattr(variant, "thumbnail", None),
            )

    dump_current_outfit_parts(sim_info)

    debug_log("========== FGEH ACCESSORY PICKER DEBUG END ==========")

class FgehPosePackAccessoryPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "category_filter": Tunable(
            description="Optional requirement category filter for this menu entry. Examples: accessory, hat, other.",
            tunable_type=str,
            default="",
        ),
        "variant_continuation": OptionalTunable(
            description="Continuation pushed after choosing one linked accessory group.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
        "all_accessories_continuation": OptionalTunable(
            description="Continuation pushed to show all available accessories.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
    }

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        debug_log(
            "Opening linked accessory picker interaction={} target={} sim={}",
            self,
            self.target,
            self.sim,
        )
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return

        active_pack, entries = get_picker_entries_for_interaction(inst)
        debug_log(
            "Linked picker rows active_pack={} entry_count={}",
            getattr(active_pack, "__name__", None),
            len(entries),
        )

        yield _make_row("恢复原始服装", tag=RESTORE_TAG, description="把当前小人切回应用联动配饰前的服装。")
        yield _make_row("View all matching items", tag=ALL_ACCESSORIES_TAG, description="Show all available items in this category.")
        yield _make_row("Write debug log", tag=LOG_TAG, description="Write current pose pack, linked items, and outfit parts to the debug log.")

        if not entries:
            yield _make_row("No linked items found for this pose pack", tag=BACK_TAG)
            return

        for index, entry_info in enumerate(entries):
            tag = ACCESSORY_TAG_PREFIX + str(index)
            debug_log(
                "Linked picker row image entry_index={} label={} icon={} tag={}",
                index,
                entry_info["label"],
                entry_info["icon"],
                tag,
            )
            yield _make_row(
                entry_info["label"],
                icon=entry_info["icon"],
                tag=tag,
                description=entry_info["description"],
                count=len(entry_info["variants"]),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        debug_log(
            "Linked picker choice received tag={} type={} kwargs={}",
            choice_tag,
            type(choice_tag),
            kwargs,
        )
        sim_info = get_sim_info_from_target(self.target)
        if sim_info is None:
            debug_log("Linked picker choice aborted: target has no sim_info.")
            return

        if choice_tag is None:
            debug_log("Linked picker choice ignored because tag is None target={} sim_id={}", self.target, getattr(sim_info, "sim_id", None))
            return

        if choice_tag == RESTORE_TAG:
            debug_log(
                "Accessory picker restore selected target={} sim_info={} sim_id={}",
                self.target,
                sim_info,
                getattr(sim_info, "sim_id", None),
            )
            result = restore_original_outfit(sim_info)
            debug_log("Accessory picker restore result={}", result)
            return

        if choice_tag == LOG_TAG:
            dump_picker_debug_info(self)
            return

        if choice_tag == ALL_ACCESSORIES_TAG:
            if self.all_accessories_continuation is None:
                debug_log("Accessory picker has no all_accessories_continuation tuned.")
                return

            self.push_tunable_continuation(
                self.all_accessories_continuation,
                category_filter=getattr(self, "category_filter", ""),
                insert_strategy=QueueInsertStrategy.LAST,
                actor=self.target,
            )
            return

        if not isinstance(choice_tag, str) or not choice_tag.startswith(ACCESSORY_TAG_PREFIX):
            return

        try:
            index = int(choice_tag[len(ACCESSORY_TAG_PREFIX):])
        except Exception:
            _debug_exception("Failed to parse linked accessory entry index")
            return

        active_pack, entries = get_picker_entries_for_interaction(self)
        debug_log(
            "Linked picker resolved choice index={} active_pack={} entry_count={}",
            index,
            getattr(active_pack, "__name__", None),
            len(entries),
        )

        if 0 <= index < len(entries):
            if self.variant_continuation is None:
                debug_log("Accessory picker has no variant_continuation tuned.")
                return

            try:
                debug_log(
                    "Pushing variant continuation={} entry_index={} source_mode=linked actor={}",
                    self.variant_continuation,
                    index,
                    self.target,
                )
                result = self.push_tunable_continuation(
                    self.variant_continuation,
                    accessory_entry_index=index,
                    accessory_source_mode="linked",
                    category_filter=getattr(self, "category_filter", ""),
                    insert_strategy=QueueInsertStrategy.LAST,
                    actor=self.target,
                )
                debug_log("Variant continuation push returned {}", result)
            except Exception:
                _debug_exception("Variant continuation push failed")
        else:
            debug_log("Linked picker choice index out of range: index={} count={}", index, len(entries))


class FgehAllAccessoryPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "category_filter": Tunable(
            description="Optional requirement category filter for this all-items menu.",
            tunable_type=str,
            default="",
        ),
        "variant_continuation": OptionalTunable(
            description="Continuation pushed after choosing one accessory group from all accessories.",
            tunable=TunableContinuation(locked_args={"actor": ParticipantType.Actor}),
            tuning_group=GroupNames.PICKERTUNING,
        ),
    }

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return

        entries = _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(inst, "category_filter", ""),
        )

        if not entries:
            yield _make_row("No linked items found for this pose pack", tag=BACK_TAG)
            return

        for index, entry_info in enumerate(entries):
            tag = ACCESSORY_TAG_PREFIX + str(index)
            debug_log(
                "All-accessories picker row image entry_index={} label={} icon={} tag={}",
                index,
                entry_info["label"],
                entry_info["icon"],
                tag,
            )
            yield _make_row(
                entry_info["label"],
                icon=entry_info["icon"],
                tag=tag,
                description=entry_info["description"],
                count=len(entry_info["variants"]),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        if not isinstance(choice_tag, str) or not choice_tag.startswith(ACCESSORY_TAG_PREFIX):
            return

        try:
            index = int(choice_tag[len(ACCESSORY_TAG_PREFIX):])
        except Exception:
            return

        entries = _filter_entries_by_category(
            get_all_accessory_entries(),
            getattr(self, "category_filter", ""),
        )

        if 0 <= index < len(entries):
            if self.variant_continuation is None:
                debug_log("All accessory picker has no variant_continuation tuned.")
                return

            self.push_tunable_continuation(
                self.variant_continuation,
                accessory_entry_index=index,
                accessory_source_mode="all",
                category_filter=getattr(self, "category_filter", ""),
                insert_strategy=QueueInsertStrategy.LAST,
                actor=self.target,
            )


class FgehPosePackAccessoryVariantPickerInteraction(PickerSuperInteraction):
    INSTANCE_TUNABLES = {
        "accessory_entry_index": Tunable(
            description="Selected first-page accessory index.",
            tunable_type=int,
            default=0,
        ),
        "accessory_source_mode": Tunable(
            description="Accessory source mode: linked or all.",
            tunable_type=str,
            default="linked",
        ),
        "category_filter": Tunable(
            description="Optional requirement category filter carried from the first page.",
            tunable_type=str,
            default="",
        ),
    }

    def __init__(self, *args, accessory_entry_index=0, accessory_source_mode="linked", category_filter="", **kwargs):
        super().__init__(*args, **kwargs)
        self.accessory_entry_index = accessory_entry_index
        self.accessory_source_mode = accessory_source_mode
        self.category_filter = category_filter
        debug_log(
            "Variant picker initialized entry_index={} source_mode={} category_filter={} target={} sim={}",
            accessory_entry_index,
            accessory_source_mode,
            category_filter,
            getattr(self, "target", None),
            getattr(self, "sim", None),
        )

    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    def _run_interaction_gen(self, timeline):
        debug_log(
            "Opening variant picker entry_index={} source_mode={} target={}",
            self.accessory_entry_index,
            self.accessory_source_mode,
            self.target,
        )
        self._show_picker_dialog(self.sim, target_sim=self.target)
        return True
        if False:
            yield None

    def _get_entry_info(self):
        entries = get_entries_for_source_mode(
            self,
            getattr(self, "accessory_source_mode", "linked"),
        )

        try:
            index = int(self.accessory_entry_index)
        except Exception:
            index = 0

        if 0 <= index < len(entries):
            return entries[index]

        return None

    @flexmethod
    def picker_rows_gen(cls, inst, target, context, **kwargs):
        if inst is None:
            return
        entry_info = inst._get_entry_info()
        if entry_info is None:
            debug_log(
                "Variant picker rows found no entry entry_index={} source_mode={}",
                getattr(inst, "accessory_entry_index", None),
                getattr(inst, "accessory_source_mode", None),
            )
            yield _make_row("No linked items found for this pose pack", tag=BACK_TAG)
            return
        variants = entry_info["variants"]
        debug_log(
            "Variant picker rows accessory={} variant_count={} source_mode={}",
            entry_info.get("label"),
            len(variants),
            getattr(inst, "accessory_source_mode", None),
        )
        for index, variant in enumerate(variants):
            cas_part_id = _entry_cas_part_id(variant)
            label = _entry_label(variant, "Variant {}".format(index + 1))
            tag = VARIANT_TAG_PREFIX + str(index)
            icon = _entry_icon(variant, entry_info["icon"])
            debug_log(
                "Variant picker row image variant_index={} label={} thumbnail={} icon={} tag={}",
                index,
                label,
                getattr(variant, "thumbnail", None),
                icon,
                tag,
            )
            yield _make_row(
                label,
                icon=icon,
                tag=tag,
                description=_entry_description(variant) or str(cas_part_id),
            )

    def on_multi_choice_selected(self, picked_choice, **kwargs):
        pass

    def on_choice_selected(self, choice_tag, **kwargs):
        debug_log(
            "Variant picker choice received tag={} type={} kwargs={}",
            choice_tag,
            type(choice_tag),
            kwargs,
        )
        if not isinstance(choice_tag, str) or not choice_tag.startswith(VARIANT_TAG_PREFIX):
            debug_log("Variant picker ignored unexpected tag={}", choice_tag)
            return
        try:
            index = int(choice_tag[len(VARIANT_TAG_PREFIX):])
        except Exception:
            _debug_exception("Failed to parse variant index")
            return
        entry_info = self._get_entry_info()
        if entry_info is None:
            debug_log("Variant picker choice has no entry info.")
            return
        variants = entry_info["variants"]
        if 0 <= index < len(variants):
            cas_part_id = _entry_cas_part_id(variants[index])
            debug_log(
                "Applying picker variant accessory={} variant_index={} cas_part_id={} thumbnail={}",
                entry_info["label"],
                index,
                cas_part_id,
                getattr(variants[index], "thumbnail", None),
            )
            try:
                result = apply_fixed_cas_accessory_to_sim(
                    get_sim_info_from_target(self.target),
                    cas_part_id=cas_part_id,
                )
                debug_log(
                    "Accessory apply returned {} accessory={} variant_index={} cas_part_id={}",
                    result,
                    entry_info["label"],
                    index,
                    cas_part_id,
                )
            except Exception:
                _debug_exception("Accessory apply raised an exception")
        else:
            debug_log("Variant picker choice index out of range: index={} count={}", index, len(variants))


def is_auto_apply_matching_accessories_enabled():
    return bool(getattr(settings, "AUTO_APPLY_MATCHING_ACCESSORIES", False))


def set_auto_apply_matching_accessories_enabled(enabled):
    settings.AUTO_APPLY_MATCHING_ACCESSORIES = bool(enabled)
    debug_log("Auto matching accessory switch set to {}", settings.AUTO_APPLY_MATCHING_ACCESSORIES)
    return settings.AUTO_APPLY_MATCHING_ACCESSORIES


def toggle_auto_apply_matching_accessories():
    return set_auto_apply_matching_accessories_enabled(
        not is_auto_apply_matching_accessories_enabled()
    )


def _first_applyable_variant(entries):
    for entry_info in entries:
        for variant in entry_info.get("variants", ()):
            cas_part_id = _entry_cas_part_id(variant)
            if cas_part_id:
                return entry_info, variant, cas_part_id
    return None, None, 0


def iter_matching_cas_variant_options(pose_name=None, pose_pack=None, category_filter=""):
    pack = pose_pack or _find_pose_pack_for_pose_name(pose_name)
    if pack is None:
        return

    snippets = get_accessory_snippets_for_pose_pack(pack)
    entries = _filter_entries_by_category(build_accessory_entries(snippets), category_filter)
    entries = _filter_entries_by_pose_name(entries, pose_name)
    seen = set()
    for entry_info in entries:
        entry_label = entry_info.get("label") or "CAS"
        entry_icon = entry_info.get("icon")
        for variant in entry_info.get("variants", ()):
            cas_part_id = _entry_cas_part_id(variant)
            if not cas_part_id or cas_part_id in seen:
                continue
            seen.add(cas_part_id)
            variant_label = _entry_label(variant, "")
            variant_icon = _entry_icon(variant, entry_icon)
            label = entry_label
            if variant_label:
                label = "{} - {}".format(entry_label, variant_label)
            yield {
                "cas_part_id": cas_part_id,
                "label": label,
                "entry_label": entry_label,
                "variant_label": variant_label,
                "entry_icon": entry_icon,
                "icon": variant_icon,
            }


def try_auto_apply_matching_accessory(target_sim, pose_name=None, pose_pack=None, category_filter="", selected_cas_part_ids=None):
    if selected_cas_part_ids == []:
        debug_log("Auto matching accessory skipped: per-pose selection is empty.")
        return False

    if selected_cas_part_ids is None and not is_auto_apply_matching_accessories_enabled():
        debug_log("Auto matching accessory skipped: switch is disabled.")
        return False

    sim_info = get_sim_info_from_target(target_sim)
    if sim_info is None:
        debug_log("Auto matching accessory skipped: no sim_info target={}", target_sim)
        return False

    pack = pose_pack or _find_pose_pack_for_pose_name(pose_name)
    if pack is None:
        debug_log("Auto matching accessory skipped: no pose pack pose_name={}", pose_name)
        return False

    snippets = get_accessory_snippets_for_pose_pack(pack)
    entries = _filter_entries_by_category(build_accessory_entries(snippets), category_filter)
    entries = _filter_entries_by_pose_name(entries, pose_name)
    if selected_cas_part_ids is not None:
        selected_ids = set()
        for value in selected_cas_part_ids or []:
            try:
                value = int(value or 0)
            except Exception:
                value = 0
            if value:
                selected_ids.add(value)

        applied_any = False
        for entry_info in entries:
            for variant in entry_info.get("variants", ()):
                cas_part_id = _entry_cas_part_id(variant)
                if not cas_part_id or cas_part_id not in selected_ids:
                    continue
                try:
                    if apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=cas_part_id):
                        applied_any = True
                except Exception:
                    _debug_exception("Auto matching selected accessory apply failed")
        return applied_any

    entry_info, variant, cas_part_id = _first_applyable_variant(entries)
    if not cas_part_id:
        debug_log(
            "Auto matching accessory found no CASP pack={} pose_name={} category_filter={}",
            getattr(pack, "__name__", None),
            pose_name,
            category_filter,
        )
        return False

    debug_log(
        "Auto applying matching accessory pack={} pose_name={} accessory={} variant={} cas_part_id={}",
        getattr(pack, "__name__", None),
        pose_name,
        entry_info.get("label"),
        _entry_label(variant, ""),
        cas_part_id,
    )
    try:
        return apply_fixed_cas_accessory_to_sim(sim_info, cas_part_id=cas_part_id)
    except Exception:
        _debug_exception("Auto matching accessory apply failed")
        return False


class FgehToggleAutoAccessoryInteraction(ImmediateSuperInteraction):
    @classmethod
    def has_valid_choice(cls, target, context, **kwargs):
        return True

    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        return super()._test(target, context, **interaction_parameters)

    @classmethod
    def _get_name(cls, *args, **kwargs):
        if is_auto_apply_matching_accessories_enabled():
            return raw_text("Disable automatic matching items")
        return raw_text("Enable automatic matching items")

    def _run_interaction_gen(self, timeline):
        enabled = toggle_auto_apply_matching_accessories()
        debug_log("Toggle auto matching accessory interaction enabled={}", enabled)
        return True
        if False:
            yield None


def show_pose_pack_accessory_picker(interaction):
    try:
        interaction._show_picker_dialog(interaction.sim, target_sim=interaction.target)
        return True
    except Exception as exc:
        debug_log("Failed to show posepack accessory picker: {}", exc)
        return False

from objects.persistence_groups import PersistenceGroups
from objects.system import create_object


_spawned_objects_by_sim = {}


def _safe_int(value):
    try:
        return int(value) if value else 0
    except Exception:
        return 0


def _get_sim_key(sim):
    if sim is None:
        return None
    return _safe_int(getattr(sim, "sim_id", None) or getattr(sim, "id", None))


def _safe_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        return list(value)
    except Exception:
        return []


def _get_variant_definition_id(variant):
    for attr_name in ("object_definition_id", "definition_id"):
        definition_id = _safe_int(getattr(variant, attr_name, None))
        if definition_id:
            return definition_id
    return 0


def _get_variant_label(variant, fallback):
    for attr_name in ("label", "display_name", "name"):
        value = str(getattr(variant, attr_name, "") or "").strip()
        if value:
            return value
    return fallback


def _entry_pose_names(entry):
    raw_pose_names = getattr(entry, "pose_names", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "poses", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "pose_name", None)
    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    for pose_name in _safe_list(raw_pose_names):
        pose_name = str(pose_name or "").strip()
        if pose_name:
            result.append(pose_name)
    return result


def _entry_matches_pose(entry_info, pose_name):
    entry = (entry_info or {}).get("entry")
    pose_names = _entry_pose_names(entry)
    if not pose_names:
        return True
    return str(pose_name or "") in pose_names


def iter_linked_object_variant_options(pack_cache, pack_id, pose_name):
    try:
        from fgeh_pose_requirement_registry import OBJECT_GROUP_TYPE, iter_requirement_sources_for_pack
    except Exception:
        return

    seen = set()
    for source in iter_requirement_sources_for_pack(pack_cache, pack_id, group_type=OBJECT_GROUP_TYPE):
        entry_info = source.get("entry_info") or {}
        if not _entry_matches_pose(entry_info, pose_name):
            continue

        source_origin = "local" if entry_info.get("snippet") is None else "external"
        source_label = "游戏内绑定" if source_origin == "local" else "外部联动包"
        source_type = str(entry_info.get("source_type") or "unknown")
        entry = entry_info.get("entry")
        entry_label = _get_variant_label(entry, "") if entry is not None else ""
        for variant in _safe_list(entry_info.get("variants")):
            definition_id = _get_variant_definition_id(variant)
            if not definition_id or definition_id in seen:
                continue
            seen.add(definition_id)
            yield {
                "definition_id": definition_id,
                "label": _get_variant_label(variant, "Object {}".format(len(seen))),
                "entry_label": entry_label or _get_variant_label(variant, "Object {}".format(len(seen))),
                "source_origin": source_origin,
                "source_label": source_label,
                "source_type": source_type,
            }


def _iter_object_definition_ids(pack_cache, pack_id, pose_name, selected_definition_id=0, selected_definition_ids=None):
    selected_definition_id = _safe_int(selected_definition_id)
    options = list(iter_linked_object_variant_options(pack_cache, pack_id, pose_name))
    if selected_definition_ids is not None:
        selected_ids = set()
        for value in selected_definition_ids or []:
            definition_id = _safe_int(value)
            if definition_id:
                selected_ids.add(definition_id)
        for option in options:
            definition_id = _safe_int(option.get("definition_id"))
            if definition_id in selected_ids:
                yield definition_id
        return

    if selected_definition_id:
        for option in options:
            definition_id = _safe_int(option.get("definition_id"))
            if definition_id == selected_definition_id:
                yield definition_id
                return

    for option in options:
        definition_id = _safe_int(option.get("definition_id"))
        if definition_id:
            yield definition_id


def _create_linked_object(definition_id, location):
    if not definition_id or location is None:
        return None

    def initialize_object(obj):
        try:
            obj.persistence_group = PersistenceGroups.NONE
        except Exception:
            pass

    try:
        obj = create_object(definition_id, init=initialize_object)
    except Exception:
        return None
    if obj is None:
        return None

    try:
        obj.location = location
    except Exception:
        destroy_linked_object(obj)
        return None

    try:
        obj.opacity = 1.0
    except Exception:
        pass

    return obj


def destroy_linked_object(obj, duration=0.2):
    if obj is None:
        return
    try:
        obj.destroy(
            source=obj,
            cause="FGEH linked pose object cleanup",
            fade_duration=float(duration),
        )
        return
    except Exception:
        pass
    try:
        obj.schedule_destroy_asap(
            source=obj,
            cause="FGEH linked pose object cleanup",
        )
    except Exception:
        pass


def spawn_matching_linked_objects(target_sim, pose_name=None, pose_pack=None, pack_cache=None, selected_definition_id=0, selected_definition_ids=None):
    if target_sim is None or pose_pack is None:
        return []

    pack_id = str(getattr(pose_pack, "__name__", "") or getattr(pose_pack, "pack_id", "") or "")
    if not pack_id:
        return []

    location = getattr(target_sim, "location", None)
    if location is None:
        return []

    sim_key = _get_sim_key(target_sim)
    spawned = []
    for definition_id in _iter_object_definition_ids(pack_cache or {}, pack_id, pose_name, selected_definition_id=selected_definition_id, selected_definition_ids=selected_definition_ids):
        obj = _create_linked_object(definition_id, location)
        if obj is not None:
            spawned.append(obj)

    if spawned and sim_key is not None:
        _spawned_objects_by_sim.setdefault(sim_key, []).extend(spawned)

    return spawned


def destroy_linked_objects_for_sim(sim):
    sim_key = _get_sim_key(sim)
    if sim_key is None:
        return 0

    objects = _spawned_objects_by_sim.pop(sim_key, [])
    destroyed = 0
    for obj in list(objects):
        destroy_linked_object(obj)
        destroyed += 1
    return destroyed


def destroy_all_linked_objects():
    destroyed = 0
    for sim_key in list(_spawned_objects_by_sim.keys()):
        objects = _spawned_objects_by_sim.pop(sim_key, [])
        for obj in list(objects):
            destroy_linked_object(obj)
            destroyed += 1
    return destroyed

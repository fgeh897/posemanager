import sims4.math

from objects.persistence_groups import PersistenceGroups
from objects.system import create_object


def get_world_location(owner):
    if owner is None:
        return None
    return getattr(owner, "location", None)


def get_world_transform(location):
    if location is None:
        return None
    return getattr(location, "world_transform", None) or getattr(location, "transform", None)


def get_world_routing_surface(location):
    if location is None:
        return None
    return (
        getattr(location, "world_routing_surface", None)
        or getattr(location, "routing_surface", None)
    )


def get_yaw_radians(location):
    transform = get_world_transform(location)
    if transform is None:
        return 0.0
    forward = transform.orientation.transform_vector(sims4.math.Vector3.Z_AXIS())
    if abs(forward.x) < sims4.math.EPSILON and abs(forward.z) < sims4.math.EPSILON:
        right = transform.orientation.transform_vector(sims4.math.Vector3.X_AXIS())
        return sims4.math.vector3_angle(right) - sims4.math.PI / 2.0
    return sims4.math.vector3_angle(forward)


def get_yaw_degrees(location):
    return sims4.math.rad_to_deg(get_yaw_radians(location))


def get_local_direction(location, x=0.0, y=0.0, z=0.0):
    transform = get_world_transform(location)
    local_vector = sims4.math.Vector3(float(x), float(y), float(z))
    if transform is None:
        return local_vector
    return transform.orientation.transform_vector(local_vector)


def get_local_offset(location, x=0.0, y=0.0, z=0.0, distance=1.0):
    return get_local_direction(location, x=x, y=y, z=z) * float(distance)


def get_horizontal_local_offset(
    location,
    x=0.0,
    z=0.0,
    distance=1.0,
    yaw_degrees=None,
):
    if yaw_degrees is None:
        yaw_radians = get_yaw_radians(location)
    else:
        yaw_radians = sims4.math.deg_to_rad(float(yaw_degrees))
    yaw_orientation = sims4.math.angle_to_yaw_quaternion(yaw_radians)
    local_vector = sims4.math.Vector3(float(x), 0.0, float(z))
    return yaw_orientation.transform_vector(local_vector) * float(distance)


def get_axis_vector(axis):
    if axis == "x":
        return sims4.math.Vector3.X_AXIS()
    if axis == "y":
        return sims4.math.Vector3.Y_AXIS()
    if axis == "z":
        return sims4.math.Vector3.Z_AXIS()
    return sims4.math.Vector3(
        float(axis[0]),
        float(axis[1]),
        float(axis[2]),
    )


def build_axis_rotation(axis, degrees):
    return sims4.math.Quaternion.from_axis_angle(
        sims4.math.deg_to_rad(float(degrees)),
        axis,
    )


def build_location(
    base_location,
    position_offset=None,
    pitch_offset_degrees=0.0,
    yaw_offset_degrees=0.0,
    roll_offset_degrees=0.0,
    absolute_yaw_degrees=None,
):
    transform = get_world_transform(base_location)
    routing_surface = get_world_routing_surface(base_location)
    if transform is None or routing_surface is None:
        return None

    offset = position_offset or (0.0, 0.0, 0.0)
    position = sims4.math.Vector3(
        transform.translation.x + float(offset[0]),
        transform.translation.y + float(offset[1]),
        transform.translation.z + float(offset[2]),
    )
    if absolute_yaw_degrees is None:
        yaw = get_yaw_radians(base_location)
    else:
        yaw = sims4.math.deg_to_rad(float(absolute_yaw_degrees))
    yaw += sims4.math.deg_to_rad(float(yaw_offset_degrees))
    orientation = sims4.math.angle_to_yaw_quaternion(yaw)
    for degrees, axis in (
        (pitch_offset_degrees, sims4.math.Vector3.X_AXIS()),
        (roll_offset_degrees, sims4.math.Vector3.Z_AXIS()),
    ):
        if not degrees:
            continue
        axis_orientation = sims4.math.Quaternion.from_axis_angle(
            sims4.math.deg_to_rad(float(degrees)),
            axis,
        )
        orientation = sims4.math.Quaternion.concatenate(
            orientation,
            axis_orientation,
        )
    return sims4.math.Location(
        sims4.math.Transform(position, orientation),
        routing_surface,
    )


def build_rotated_location(
    base_location,
    position_offset=None,
    pitch_offset_degrees=0.0,
    yaw_offset_degrees=0.0,
    roll_offset_degrees=0.0,
    rotation_steps=None,
):
    transform = get_world_transform(base_location)
    routing_surface = get_world_routing_surface(base_location)
    if transform is None or routing_surface is None:
        return None

    offset = position_offset or (0.0, 0.0, 0.0)
    position = sims4.math.Vector3(
        transform.translation.x + float(offset[0]),
        transform.translation.y + float(offset[1]),
        transform.translation.z + float(offset[2]),
    )

    orientation = transform.orientation
    if rotation_steps is None:
        axis_rotations = (
            (pitch_offset_degrees, sims4.math.Vector3.X_AXIS()),
            (yaw_offset_degrees, sims4.math.Vector3.Y_AXIS()),
            (roll_offset_degrees, sims4.math.Vector3.Z_AXIS()),
        )
    else:
        axis_rotations = []
        for rotation in rotation_steps:
            if len(rotation) == 2:
                axis, degrees = rotation
                axis_rotations.append((degrees, get_axis_vector(axis), True))
            else:
                axis, degrees, axis_space = rotation
                axis_rotations.append(
                    (
                        degrees,
                        get_axis_vector(axis),
                        axis_space != "world",
                    )
                )

    for rotation in axis_rotations:
        if len(rotation) == 2:
            degrees, axis = rotation
            use_local_axis = False
        else:
            degrees, axis, use_local_axis = rotation
        if not degrees or axis is None:
            continue
        if use_local_axis:
            axis = orientation.transform_vector(axis)
        axis_orientation = build_axis_rotation(axis, degrees)
        orientation = sims4.math.Quaternion.concatenate(
            axis_orientation,
            orientation,
        )

    return sims4.math.Location(
        sims4.math.Transform(position, orientation),
        routing_surface,
    )


def set_world_location(owner, location):
    if owner is None or location is None:
        return False
    try:
        owner.location = location
        return True
    except Exception:
        return False


def create_world_object(definition_id, location, opacity=0.0):
    if not definition_id or location is None:
        return None

    obj = create_object(definition_id)
    if obj is None:
        return None

    try:
        obj.location = location
        obj.persistence_group = PersistenceGroups.NONE
        obj.opacity = float(opacity)
    except Exception:
        destroy_world_object(obj)
        return None
    return obj


def fade_in_world_object(obj, duration=0.3):
    if obj is None:
        return
    try:
        obj.fade_in(fade_duration=float(duration))
    except Exception:
        try:
            obj.opacity = 1.0
        except Exception:
            pass


def destroy_world_object(obj, duration=0.3):
    if obj is None:
        return
    try:
        obj.destroy(
            source=obj,
            cause="FGEH positioning helper cleanup",
            fade_duration=float(duration),
        )
        return
    except Exception:
        pass
    try:
        obj.schedule_destroy_asap(
            source=obj,
            cause="FGEH positioning helper cleanup",
        )
    except Exception:
        pass

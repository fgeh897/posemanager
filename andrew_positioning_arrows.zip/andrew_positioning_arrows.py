import collections
import math
import traceback

from objects.game_object import GameObject

from fgeh_config import (
    POSITIONING_CORE_DEFINITION_ID,
    POSITIONING_DOWN_ARROW_DEFINITION_ID,
    POSITIONING_HORIZONTAL_ARROW_DEFINITION_ID,
    POSITIONING_ROTATE_CLOCKWISE_DEFINITION_ID,
    POSITIONING_ROTATE_COUNTERCLOCKWISE_DEFINITION_ID,
    POSITIONING_ROTATION_AXIS_X_DEFINITION_ID,
    POSITIONING_ROTATION_AXIS_Y_DEFINITION_ID,
    POSITIONING_ROTATION_AXIS_Z_DEFINITION_ID,
    POSITIONING_UP_ARROW_DEFINITION_ID,
)
from andrew_positioning_native import (
    build_location,
    create_world_object,
    destroy_world_object,
    fade_in_world_object,
    get_horizontal_local_offset,
    set_world_location,
)
from andrew_positioning_session import (
    AndrewPositioningState,
    PositioningObjectType,
    RotationAxisType,
    get_andrew_positioning_session,
)

"""
These helpers are ordinary world objects, not UI images. Each definition in
the package must use AndrewClickableArrowObject as its script class.
"""


ARROW_OBJECT_DEFINITION_IDS = {
    PositioningObjectType.CORE: POSITIONING_CORE_DEFINITION_ID,
    PositioningObjectType.POSITIONING_NORTH: POSITIONING_HORIZONTAL_ARROW_DEFINITION_ID,
    PositioningObjectType.POSITIONING_SOUTH: POSITIONING_HORIZONTAL_ARROW_DEFINITION_ID,
    PositioningObjectType.POSITIONING_EAST: POSITIONING_HORIZONTAL_ARROW_DEFINITION_ID,
    PositioningObjectType.POSITIONING_WEST: POSITIONING_HORIZONTAL_ARROW_DEFINITION_ID,
    PositioningObjectType.POSITIONING_UP: POSITIONING_UP_ARROW_DEFINITION_ID,
    PositioningObjectType.POSITIONING_DOWN: POSITIONING_DOWN_ARROW_DEFINITION_ID,
    PositioningObjectType.ROTATION_CLOCKWISE: POSITIONING_ROTATE_CLOCKWISE_DEFINITION_ID,
    PositioningObjectType.ROTATION_COUNTERCLOCKWISE: POSITIONING_ROTATE_COUNTERCLOCKWISE_DEFINITION_ID,
    PositioningObjectType.ROTATION_AXIS_X: POSITIONING_ROTATION_AXIS_X_DEFINITION_ID,
    PositioningObjectType.ROTATION_AXIS_Y: POSITIONING_ROTATION_AXIS_Y_DEFINITION_ID,
    PositioningObjectType.ROTATION_AXIS_Z: POSITIONING_ROTATION_AXIS_Z_DEFINITION_ID,
}


ARROW_LAYOUT_OFFSETS = {
    PositioningObjectType.CORE: (2.0, 0.0, 0.0, 0.0),
    PositioningObjectType.POSITIONING_NORTH: (1.8, 0.0, 0.0, 1.2),
    PositioningObjectType.POSITIONING_SOUTH: (1.8, 180.0, 0.0, 1.2),
    PositioningObjectType.POSITIONING_EAST: (1.8, 90.0, 0.0, 1.2),
    PositioningObjectType.POSITIONING_WEST: (1.8, 270.0, 0.0, 1.2),
    PositioningObjectType.POSITIONING_UP: (2.15, 135.0, 0.0, 1.2),
    PositioningObjectType.POSITIONING_DOWN: (1.45, 135.0, 0.0, 1.2),
    PositioningObjectType.ROTATION_CLOCKWISE: (2.15, 315.0, 0.0, 1.2),
    PositioningObjectType.ROTATION_COUNTERCLOCKWISE: (1.45, 315.0, 0.0, 1.2),
    PositioningObjectType.ROTATION_AXIS_X: (2.35, 270.0, 0.0, 0.78),
    PositioningObjectType.ROTATION_AXIS_Y: (2.35, 0.0, 0.0, 0.78),
    PositioningObjectType.ROTATION_AXIS_Z: (2.35, 90.0, 0.0, 0.78),
}

ARROW_MODEL_ROLL_OFFSETS = {
    PositioningObjectType.POSITIONING_DOWN: 180.0,
    PositioningObjectType.ROTATION_COUNTERCLOCKWISE: 180.0,
}

ARROW_OBJECT_SCALES = {
    PositioningObjectType.CORE: 1.0,
    PositioningObjectType.POSITIONING_NORTH: 1.0,
    PositioningObjectType.POSITIONING_SOUTH: 1.0,
    PositioningObjectType.POSITIONING_EAST: 1.0,
    PositioningObjectType.POSITIONING_WEST: 1.0,
    PositioningObjectType.POSITIONING_UP: 1.0,
    PositioningObjectType.POSITIONING_DOWN: 1.0,
    PositioningObjectType.ROTATION_CLOCKWISE: 1.0,
    PositioningObjectType.ROTATION_COUNTERCLOCKWISE: 1.0,
    PositioningObjectType.ROTATION_AXIS_X: 1.0,
    PositioningObjectType.ROTATION_AXIS_Y: 1.0,
    PositioningObjectType.ROTATION_AXIS_Z: 1.0,
}


_ACTIVE_ARROW_OBJECTS = collections.defaultdict(list)


POSE_ALIGNMENT_OBJECT_AFFORDANCE_IDS = frozenset((
    17920356921228535595,  # Move
    11640776509772919537,  # Rotate
    14533107135713564075,  # Align
    17960990659796020809,  # Affect other posed Sims
    16761197984873072642,  # Auto snapping
))


def _is_pose_alignment_affordance(aop):
    affordance = getattr(aop, "affordance", None)
    if affordance is None:
        affordance = getattr(aop, "interaction_factory", None)
    if affordance is None:
        return False

    affordance_id = getattr(affordance, "guid64", None)
    if affordance_id in POSE_ALIGNMENT_OBJECT_AFFORDANCE_IDS:
        return True

    module_name = getattr(affordance, "__module__", "")
    return module_name.startswith("pose_alignment_interactions.")


class AndrewClickableArrowObject(GameObject):
    CHOICES_VERIFY_FUNC = "has_choices"
    CHOICES_RETURN_FUNC = "generate_choices"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._session_id = None
        self._object_type = None

    def attach_arrow_data(self, session_id, object_type):
        self._session_id = session_id
        self._object_type = object_type

    def get_attached_session_id(self):
        return self._session_id

    def get_attached_object_type(self):
        return self._object_type

    def get_attached_session(self):
        return get_andrew_positioning_session(self._session_id)

    def potential_interactions(self, context, *args, **kwargs):
        if self._object_type == PositioningObjectType.CORE:
            for aop in super().potential_interactions(context, *args, **kwargs):
                if not _is_pose_alignment_affordance(aop):
                    yield aop
            return

        for frame in traceback.walk_stack(None):
            frame_name = frame[0].f_code.co_name
            if frame_name == self.CHOICES_RETURN_FUNC:
                self.on_clicked()
                return
            if frame_name == self.CHOICES_VERIFY_FUNC:
                yield from super().potential_interactions(context, *args, **kwargs)
                return
        return

    def on_clicked(self):
        if (
            self._session_id is None
            or self._object_type is None
            or self._object_type == PositioningObjectType.CORE
        ):
            return

        session = get_andrew_positioning_session(self._session_id)
        if session is None or session.is_canceled:
            return

        session.on_positioning_arrow_click(self._object_type)
        update_arrow_layout(session)


def is_arrow_system_available():
    return all(
        definition_id for definition_id in ARROW_OBJECT_DEFINITION_IDS.values()
    )


def get_positioning_session_id_from_target(interaction_target):
    if interaction_target is None:
        return None

    session_id = getattr(interaction_target, "_session_id", None)
    if session_id:
        return session_id

    getter = getattr(interaction_target, "get_attached_session_id", None)
    if callable(getter):
        try:
            session_id = getter()
        except Exception:
            session_id = None
        if session_id:
            return session_id

    return None


def get_positioning_object_type_from_target(interaction_target):
    if interaction_target is None:
        return None

    object_type = getattr(interaction_target, "_object_type", None)
    if object_type is not None:
        return object_type

    getter = getattr(interaction_target, "get_attached_object_type", None)
    if callable(getter):
        try:
            object_type = getter()
        except Exception:
            object_type = None
        if object_type is not None:
            return object_type

    return None


def get_positioning_session_from_target(interaction_target):
    return get_andrew_positioning_session(
        get_positioning_session_id_from_target(interaction_target)
    )


def get_arrow_location(object_type, origin_location, heading_degrees=None):
    if origin_location is None:
        return None

    height_offset, rotation, rotation_offset, distance = ARROW_LAYOUT_OFFSETS[object_type]
    angle = math.radians(rotation)
    horizontal_offset = get_horizontal_local_offset(
        origin_location,
        x=math.sin(angle),
        z=math.cos(angle),
        distance=distance,
        yaw_degrees=heading_degrees,
    )
    return build_location(
        origin_location,
        position_offset=(
            horizontal_offset.x,
            height_offset,
            horizontal_offset.z,
        ),
        yaw_offset_degrees=rotation + rotation_offset - 90.0,
        roll_offset_degrees=ARROW_MODEL_ROLL_OFFSETS.get(object_type, 0.0),
        absolute_yaw_degrees=heading_degrees,
    )


def _rotation_axis_for_object_type(object_type):
    if object_type == PositioningObjectType.ROTATION_AXIS_X:
        return RotationAxisType.PITCH
    if object_type == PositioningObjectType.ROTATION_AXIS_Y:
        return RotationAxisType.YAW
    if object_type == PositioningObjectType.ROTATION_AXIS_Z:
        return RotationAxisType.ROLL
    return None


def _update_axis_selector_appearance(session, object_instance, object_type):
    selector_axis = _rotation_axis_for_object_type(object_type)
    if selector_axis is None:
        return

    selected = selector_axis == session.get_positioning_rotation_axis_type()
    try:
        object_instance.opacity = 1.0 if selected else 0.35
    except Exception:
        pass


def _update_control_scale(object_instance, object_type):
    try:
        object_instance.scale = ARROW_OBJECT_SCALES.get(object_type, 1.0)
    except Exception:
        pass


def spawn_arrow_layout(session):
    if not is_arrow_system_available() or session is None or session.is_canceled:
        return False

    origin_location = session.get_location()
    if origin_location is None:
        return False
    heading_degrees = session.get_positioning_heading_degrees()

    session_id = session.get_identifier()
    existing_core = None
    for object_instance in _ACTIVE_ARROW_OBJECTS.get(session_id, ()):
        if (
            get_positioning_object_type_from_target(object_instance)
            == PositioningObjectType.CORE
        ):
            existing_core = object_instance
            break

    remove_arrow_layout(session, keep_core=True)

    for object_type in PositioningObjectType:
        if object_type == PositioningObjectType.CORE and existing_core is not None:
            continue

        definition_id = ARROW_OBJECT_DEFINITION_IDS.get(object_type)
        if not definition_id:
            continue

        location = get_arrow_location(
            object_type,
            origin_location,
            heading_degrees=heading_degrees,
        )
        if location is None:
            continue

        object_instance = create_world_object(
            definition_id,
            location,
            opacity=0.0,
        )
        if object_instance is None:
            continue

        if hasattr(object_instance, "attach_arrow_data"):
            object_instance.attach_arrow_data(session_id, object_type)
        elif hasattr(object_instance, "attach_positioning_data"):
            object_instance.attach_positioning_data(session, object_type)
        else:
            object_instance._session_id = session_id
            object_instance._object_type = object_type

        fade_in_world_object(object_instance)
        _update_control_scale(object_instance, object_type)
        _update_axis_selector_appearance(session, object_instance, object_type)
        _ACTIVE_ARROW_OBJECTS[session_id].append(object_instance)

    session.set_state(AndrewPositioningState.POSITIONING_MODE, True)
    return True


def update_arrow_layout(session):
    if not is_arrow_system_available() or session is None or session.is_canceled:
        return

    session_id = session.get_identifier()
    origin_location = session.get_location()
    if origin_location is None:
        return
    heading_degrees = session.get_positioning_heading_degrees()

    for object_instance in _ACTIVE_ARROW_OBJECTS.get(session_id, ()):
        if object_instance is None:
            continue

        object_type = get_positioning_object_type_from_target(object_instance)
        if object_type is None:
            continue

        location = get_arrow_location(
            object_type,
            origin_location,
            heading_degrees=heading_degrees,
        )
        if location is None:
            continue

        set_world_location(object_instance, location)
        _update_axis_selector_appearance(session, object_instance, object_type)


def remove_arrow_layout(session_or_identifier, keep_core=False):
    if hasattr(session_or_identifier, "get_identifier"):
        session_identifier = session_or_identifier.get_identifier()
        try:
            session_or_identifier.set_state(AndrewPositioningState.POSITIONING_MODE, False)
        except Exception:
            pass
    else:
        session_identifier = session_or_identifier

    if not session_identifier:
        return

    kept_objects = []
    for object_instance in _ACTIVE_ARROW_OBJECTS.get(session_identifier, ()):
        if (
            keep_core
            and get_positioning_object_type_from_target(object_instance)
            == PositioningObjectType.CORE
        ):
            kept_objects.append(object_instance)
            continue
        destroy_world_object(object_instance)

    if kept_objects:
        _ACTIVE_ARROW_OBJECTS[session_identifier] = kept_objects
    else:
        _ACTIVE_ARROW_OBJECTS.pop(session_identifier, None)

from andrew_positioning_native import (
    build_rotated_location,
    get_world_location,
    set_world_location,
)


def is_runtime_available():
    return True


def capture_base_location(node):
    if node is None or getattr(node, "_fgeh_base_location", None) is not None:
        return getattr(node, "_fgeh_base_location", None)

    owner = getattr(node, "owner", None)
    if owner is None:
        return None

    node._fgeh_base_location = get_world_location(owner)
    return node._fgeh_base_location


def reset_base_location(node):
    if node is None:
        return
    node._fgeh_base_location = None


def build_target_location(node):
    if node is None:
        return None

    base_location = capture_base_location(node)
    if base_location is None:
        return None

    return build_rotated_location(
        base_location,
        position_offset=node.position_offset,
        pitch_offset_degrees=node.pitch_rotation_offset,
        yaw_offset_degrees=node.rotation_offset,
        roll_offset_degrees=node.roll_rotation_offset,
        rotation_steps=getattr(node, "rotation_steps", None),
    )


def apply_node_location(node):
    if node is None:
        return False

    location = build_target_location(node)
    if location is None:
        return False

    return set_world_location(getattr(node, "owner", None), location)


def apply_session_location(session, node):
    return apply_node_location(node)

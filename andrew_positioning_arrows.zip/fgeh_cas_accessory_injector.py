import services
import sims4.resources

import injector2
import fgeh_cas_accessory_settings as settings
try:
    from fgeh_cas_accessory_outfit_utils import debug_log
except Exception:
    def debug_log(*args, **kwargs):
        return None

from sims4.resources import Types
from sims4.tuning.instance_manager import InstanceManager


def _get_affordance(interaction_id):
    try:
        key = sims4.resources.get_resource_key(interaction_id, Types.INTERACTION)
        affordance = services.affordance_manager().get(key)
        debug_log("Accessory affordance lookup id={} key={} found={}", interaction_id, key, affordance is not None)
        return affordance
    except Exception as exc:
        debug_log("Accessory affordance lookup failed id={} exc={}", interaction_id, exc)
        return None


def _is_probably_sim_tuning(object_tuning):
    name = getattr(object_tuning, "__name__", "")
    qualname = getattr(object_tuning, "__qualname__", "")
    lower_name = name.lower()
    lower_qualname = qualname.lower()
    if lower_name == "sim" or lower_qualname == "sim":
        return True
    if lower_name.endswith(".sim") or lower_qualname.endswith(".sim"):
        return True
    return getattr(object_tuning, "is_sim", False)


@injector2.inject(InstanceManager, "load_data_into_class_instances")
def _inject_fgeh_test_cas_accessory_affordances(original, self, *args, **kwargs):
    result = original(self, *args, **kwargs)
    if self.TYPE != Types.OBJECT:
        return result

    debug_log(
        "Accessory injector running for OBJECT manager tuned_count={}",
        len(getattr(self, "_tuned_classes", {})),
    )
    affordances_to_add = []
    for interaction_id in (
        settings.OPEN_POSEPACK_ACCESSORY_PICKER_INTERACTION_ID,
    ):
        affordance = _get_affordance(interaction_id)
        if affordance is not None:
            affordances_to_add.append(affordance)

    if not affordances_to_add:
        debug_log("Accessory injector found no affordances; check tuning package import")
        return result

    injected_count = 0
    for object_tuning in self._tuned_classes.values():
        if not hasattr(object_tuning, "_super_affordances"):
            continue
        if not _is_probably_sim_tuning(object_tuning):
            continue
        affordances = tuple(getattr(object_tuning, "_super_affordances", ()))
        missing_affordances = tuple(
            affordance for affordance in affordances_to_add if affordance not in affordances
        )
        if missing_affordances:
            object_tuning._super_affordances = affordances + missing_affordances
            injected_count += 1
    debug_log(
        "Accessory injector complete affordance_count={} injected_tunings={}",
        len(affordances_to_add),
        injected_count,
    )
    return result

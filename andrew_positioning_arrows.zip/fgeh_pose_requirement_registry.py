CAS_GROUP_TYPE = "cas"
OBJECT_GROUP_TYPE = "object"

CAS_RESOURCE_TYPES = frozenset((
    "cas",
    "cas_part",
    "caspart",
    "accessory",
    "accessories",
    "outfit",
    "clothing",
    "clothes",
))

OBJECT_RESOURCE_TYPES = frozenset((
    "object",
    "object_definition",
    "object_tuning",
    "furniture",
    "prop",
))

SOURCE_TYPES = frozenset((
    "game",
    "cc",
    "unknown",
))

_CACHE_KEY = None
_CACHE_SOURCES = None
_CACHE_SOURCES_BY_PACK = None


class _RequirementEntry:
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)


def clear_requirement_cache():
    global _CACHE_KEY, _CACHE_SOURCES, _CACHE_SOURCES_BY_PACK
    _CACHE_KEY = None
    _CACHE_SOURCES = None
    _CACHE_SOURCES_BY_PACK = None


def _safe_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        return list(value)
    except Exception:
        return []


def _entry_pose_names(entry):
    raw_pose_names = getattr(entry, "pose_names", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "poses", None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, "pose_name", None)

    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    for pose_name in _safe_list(raw_pose_names):
        pose_name = str(pose_name or "").strip()
        if pose_name:
            result.append(pose_name)
    return result


def _variant_has_cas_part(variant):
    for name in ("cas_part_id", "resource_id"):
        try:
            if int(getattr(variant, name, 0) or 0):
                return True
        except Exception:
            pass
    return False


def _variant_has_object_resource(variant):
    for name in ("object_definition_id", "object_tuning_id", "definition_id"):
        try:
            if int(getattr(variant, name, 0) or 0):
                return True
        except Exception:
            pass
    return False


def _normalize_group_type(entry_info):
    entry = entry_info.get("entry")
    resource_type = str(
        getattr(entry, "resource_type", "")
        or getattr(entry, "requirement_type", "")
        or entry_info.get("resource_type", "")
        or entry_info.get("category", "")
        or ""
    ).strip().lower()

    if resource_type in OBJECT_RESOURCE_TYPES:
        return OBJECT_GROUP_TYPE
    if resource_type in CAS_RESOURCE_TYPES:
        return CAS_GROUP_TYPE

    variants = _safe_list(entry_info.get("variants"))
    if any(_variant_has_object_resource(variant) for variant in variants):
        return OBJECT_GROUP_TYPE
    if any(_variant_has_cas_part(variant) for variant in variants):
        return CAS_GROUP_TYPE

    return CAS_GROUP_TYPE


def _iter_pose_items_for_entry(pack, entry_info):
    entry = entry_info.get("entry")
    allowed_pose_names = set(_entry_pose_names(entry))

    for pose_item in getattr(pack, "pose_list", []) or []:
        pose_name = getattr(pose_item, "pose_name", None)
        if not pose_name:
            continue
        if allowed_pose_names and pose_name not in allowed_pose_names:
            continue
        yield pose_item


def _count_pose_items_for_entry(pack, entry_info):
    entry = entry_info.get("entry")
    allowed_pose_names = set(_entry_pose_names(entry))
    if allowed_pose_names:
        return len(allowed_pose_names)
    try:
        return len(getattr(pack, "pose_list", []) or [])
    except Exception:
        return 0


def _pack_cache_key(pack_cache):
    try:
        return (id(pack_cache), len(pack_cache or {}))
    except Exception:
        return (id(pack_cache), 0)


def _pack_lookup_keys(pack_id, pack):
    keys = set()
    for value in (
        pack_id,
        getattr(pack, "__name__", None),
        getattr(pack, "pack_id", None),
        getattr(pack, "source_pose_pack_name", None),
    ):
        value = str(value or "").strip()
        if value:
            keys.add(value)
    return keys


def _build_pack_lookup(pack_cache):
    lookup = {}
    for pack_id, pack in (pack_cache or {}).items():
        for key in _pack_lookup_keys(pack_id, pack):
            if key not in lookup:
                lookup[key] = (pack_id, pack)
    return lookup


def _snippet_pack_keys(snippet):
    keys = []
    for attr_name in ("pack_id", "source_pose_pack_name", "source_pose_pack_id"):
        value = str(getattr(snippet, attr_name, "") or "").strip()
        if value and value not in keys:
            keys.append(value)
    return keys


def _find_pack_for_snippet(snippet, pack_lookup):
    for key in _snippet_pack_keys(snippet):
        match = pack_lookup.get(key)
        if match is not None:
            return match
    return None, None


def _text(value):
    return str(value or "").strip()


def _normalize_source_type(value):
    source_type = _text(value).lower()
    if source_type in SOURCE_TYPES:
        return source_type
    return "unknown"


def _v3_pose_names(snippet, link):
    target_type = _text(getattr(link, "target_type", "")).lower()
    target_id = _text(getattr(link, "target_id", ""))
    pose_name = _text(getattr(link, "pose_name", ""))
    pack_keys = set((
        _text(getattr(snippet, "pack_id", "")),
        _text(getattr(snippet, "source_pose_pack_name", "")),
        _text(getattr(snippet, "source_pose_pack_id", "")),
    ))

    if target_type == "pose":
        return [target_id or pose_name] if (target_id or pose_name) else []
    if target_type == "pack":
        return []
    if pose_name and pose_name not in pack_keys:
        return [pose_name]
    return []


def _build_v3_requirement_entries(snippet):
    assets = _safe_list(getattr(snippet, "assets", None))
    links = _safe_list(getattr(snippet, "action_links", None))
    if not assets or not links:
        return []

    assets_by_id = {}
    for asset in assets:
        asset_id = _text(getattr(asset, "asset_id", ""))
        if asset_id:
            assets_by_id[asset_id] = asset

    entries = []
    seen = set()
    for link in links:
        asset_id = _text(getattr(link, "asset_id", ""))
        asset = assets_by_id.get(asset_id)
        if asset is None:
            continue

        variants = _safe_list(getattr(asset, "variants", None))
        if not variants:
            continue

        category = (
            _text(getattr(link, "category_id", ""))
            or _text(getattr(asset, "category_id", ""))
            or _text(getattr(link, "asset_kind", ""))
            or _text(getattr(asset, "asset_kind", ""))
            or CAS_GROUP_TYPE
        )
        resource_type = (
            _text(getattr(link, "asset_kind", ""))
            or _text(getattr(asset, "asset_kind", ""))
            or category
            or CAS_GROUP_TYPE
        )
        source_type = _normalize_source_type(
            _text(getattr(link, "source_type", ""))
            or _text(getattr(asset, "source_type", ""))
        )
        pose_names = _v3_pose_names(snippet, link)
        link_id = _text(getattr(link, "link_id", ""))
        signature = (asset_id, link_id, tuple(pose_names), resource_type, category, source_type)
        if signature in seen:
            continue
        seen.add(signature)

        entry = _RequirementEntry(
            category=category,
            category_id=category,
            resource_type=resource_type,
            asset_kind=resource_type,
            source_type=source_type,
            asset_id=asset_id,
            link_id=link_id,
            pose_names=pose_names,
            variants=variants,
        )
        entries.append({
            "snippet": snippet,
            "entry": entry,
            "variants": variants,
            "category": category,
            "resource_type": resource_type,
            "source_type": source_type,
            "asset_id": asset_id,
            "link_id": link_id,
        })

    return entries


def _build_requirement_entries(snippet, fallback_builder):
    v3_entries = _build_v3_requirement_entries(snippet)
    if v3_entries:
        return v3_entries
    return fallback_builder((snippet,))


def _build_saved_object_requirement_entries(pack_lookup):
    try:
        from fgeh_linked_object_bindings import iter_saved_object_assets
    except Exception:
        return []

    entries = []
    seen = set()
    for asset in iter_saved_object_assets():
        pack_key = _text(asset.get("pack_id"))
        definition_id = 0
        try:
            definition_id = int(asset.get("definition_id") or 0)
        except Exception:
            definition_id = 0
        if not pack_key or not definition_id:
            continue

        match = pack_lookup.get(pack_key)
        if match is None:
            continue
        pack_id, pack = match

        signature = (pack_id, definition_id)
        if signature in seen:
            continue
        seen.add(signature)

        display_name = _text(asset.get("display_name")) or "Object {}".format(definition_id)
        source_type = _normalize_source_type(asset.get("source_type"))
        variant = _RequirementEntry(
            label=display_name,
            display_name=display_name,
            object_definition_id=definition_id,
            definition_id=definition_id,
        )
        entry = _RequirementEntry(
            category=OBJECT_GROUP_TYPE,
            category_id=OBJECT_GROUP_TYPE,
            resource_type=OBJECT_GROUP_TYPE,
            asset_kind=OBJECT_GROUP_TYPE,
            source_type=source_type,
            asset_id="user.object.{}".format(definition_id),
            link_id="local.object.{}.{}".format(pack_id, definition_id),
            pose_names=[],
            variants=[variant],
        )
        entry_info = {
            "snippet": None,
            "entry": entry,
            "variants": [variant],
            "category": OBJECT_GROUP_TYPE,
            "resource_type": OBJECT_GROUP_TYPE,
            "source_type": source_type,
            "asset_id": entry.asset_id,
            "link_id": entry.link_id,
        }
        entries.append({
            "group_type": OBJECT_GROUP_TYPE,
            "pack_id": pack_id,
            "pack": pack,
            "entry_info": entry_info,
            "pose_count": _count_pose_items_for_entry(pack, entry_info),
        })
    return entries


def _get_cached_sources(pack_cache):
    global _CACHE_KEY, _CACHE_SOURCES, _CACHE_SOURCES_BY_PACK
    cache_key = _pack_cache_key(pack_cache)
    if _CACHE_KEY == cache_key and _CACHE_SOURCES is not None:
        return _CACHE_SOURCES

    try:
        from fgeh_cas_accessory_picker import (
            build_accessory_entries,
            iter_accessory_metadata_snippets,
        )
    except Exception:
        _CACHE_KEY = cache_key
        _CACHE_SOURCES = []
        _CACHE_SOURCES_BY_PACK = None
        return _CACHE_SOURCES

    sources = []
    pack_lookup = _build_pack_lookup(pack_cache)
    sources.extend(_build_saved_object_requirement_entries(pack_lookup))

    for snippet in iter_accessory_metadata_snippets():
        if getattr(snippet, "disabled", False):
            continue

        pack_id, pack = _find_pack_for_snippet(snippet, pack_lookup)
        if pack is None:
            continue

        for entry_info in _build_requirement_entries(snippet, build_accessory_entries):
            group_type = _normalize_group_type(entry_info)
            sources.append({
                "group_type": group_type,
                "pack_id": pack_id,
                "pack": pack,
                "entry_info": entry_info,
                "pose_count": _count_pose_items_for_entry(pack, entry_info),
            })

    _CACHE_KEY = cache_key
    _CACHE_SOURCES = sources
    _CACHE_SOURCES_BY_PACK = None
    return _CACHE_SOURCES


def iter_requirement_sources(pack_cache):
    for source in _get_cached_sources(pack_cache):
        yield source


def iter_requirement_sources_for_pack(pack_cache, pack_id, group_type=None):
    global _CACHE_SOURCES_BY_PACK
    pack_id = str(pack_id or "")
    if not pack_id:
        return

    sources = _get_cached_sources(pack_cache)
    if _CACHE_SOURCES_BY_PACK is None:
        index = {}
        for source in sources:
            source_pack_id = str(source.get("pack_id") or "")
            if source_pack_id:
                index.setdefault(source_pack_id, []).append(source)
        _CACHE_SOURCES_BY_PACK = index

    for source in _CACHE_SOURCES_BY_PACK.get(pack_id, ()):
        if group_type and source.get("group_type") != group_type:
            continue
        yield source


def iter_linked_pack_refs(pack_cache, group_type=None):
    seen = set()
    for source in iter_requirement_sources(pack_cache):
        source_group_type = source.get("group_type")
        if group_type and source_group_type != group_type:
            continue

        pack_id = source.get("pack_id")
        if not pack_id or pack_id in seen:
            continue
        seen.add(pack_id)
        yield {
            "group_type": source_group_type,
            "pack_id": pack_id,
            "pack": source.get("pack"),
            "pose_count": int(source.get("pose_count") or 0),
        }


def iter_linked_pose_refs(pack_cache, group_type=None):
    seen = set()
    for source in iter_requirement_sources(pack_cache):
        if group_type and source.get("group_type") != group_type:
            continue

        pack = source.get("pack")
        pack_id = source.get("pack_id")
        for pose_item in _iter_pose_items_for_entry(pack, source.get("entry_info") or {}):
            pose_name = getattr(pose_item, "pose_name", None)
            key = (pack_id, pose_name)
            if key in seen:
                continue
            seen.add(key)
            yield {
                "group_type": source.get("group_type"),
                "pack_id": pack_id,
                "pose_name": pose_name,
                "pack": pack,
                "pose_item": pose_item,
            }


def iter_linked_pose_refs_for_pack(pack_cache, pack_id, group_type=None):
    pack_id = str(pack_id or "")
    if not pack_id:
        return

    seen = set()
    for source in iter_requirement_sources(pack_cache):
        if str(source.get("pack_id") or "") != pack_id:
            continue
        if group_type and source.get("group_type") != group_type:
            continue

        pack = source.get("pack")
        for pose_item in _iter_pose_items_for_entry(pack, source.get("entry_info") or {}):
            pose_name = getattr(pose_item, "pose_name", None)
            key = (pack_id, pose_name)
            if not pose_name or key in seen:
                continue
            seen.add(key)
            yield {
                "group_type": source.get("group_type"),
                "pack_id": pack_id,
                "pose_name": pose_name,
                "pack": pack,
                "pose_item": pose_item,
            }


def make_pose_ref(pack_id, pose_name):
    return {
        "pack_id": str(pack_id or ""),
        "pose_name": str(pose_name or ""),
    }


def pose_ref_key(ref):
    if isinstance(ref, dict):
        return (str(ref.get("pack_id", "")), str(ref.get("pose_name", "")))
    if isinstance(ref, (list, tuple)) and len(ref) >= 2:
        return (str(ref[0]), str(ref[1]))
    return ("", "")


def pose_ref_in(ref, ref_keys):
    return pose_ref_key(ref) in ref_keys


def collect_grouped_refs(linked_groups, group_type):
    keys = set()
    for refs in ((linked_groups or {}).get(group_type, {}) or {}).values():
        for ref in refs or []:
            key = pose_ref_key(ref)
            if key[0] and key[1]:
                keys.add(key)
    return keys


def get_available_group_types(pack_cache):
    counts = {CAS_GROUP_TYPE: 0, OBJECT_GROUP_TYPE: 0}
    for ref in iter_linked_pack_refs(pack_cache):
        group_type = ref.get("group_type")
        if group_type in counts:
            counts[group_type] += 1
    return counts


def get_pose_item(pack_cache, pack_id, pose_name):
    pack = (pack_cache or {}).get(pack_id)
    if pack is None:
        return None, None

    for pose_item in getattr(pack, "pose_list", []) or []:
        if getattr(pose_item, "pose_name", None) == pose_name:
            return pack, pose_item
    return pack, None

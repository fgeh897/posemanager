import uuid
from enum import IntEnum

from andrew_positioning_native import (
    build_axis_rotation,
    get_axis_vector,
    get_horizontal_local_offset,
    set_world_location,
    get_yaw_degrees,
)

try:
    import services
except Exception:
    services = None

class PositioningNodeType(IntEnum):
    ACTOR = 0
    OBJECT = 1
    PROP = 2


class PositioningObjectType(IntEnum):
    CORE = 1

    POSITIONING_NORTH = 10
    POSITIONING_SOUTH = 11
    POSITIONING_EAST = 12
    POSITIONING_WEST = 13

    POSITIONING_UP = 14
    POSITIONING_DOWN = 15

    ROTATION_CLOCKWISE = 20
    ROTATION_COUNTERCLOCKWISE = 21

    ROTATION_AXIS_X = 30
    ROTATION_AXIS_Y = 31
    ROTATION_AXIS_Z = 32


class RotationAxisType(IntEnum):
    YAW = 0
    PITCH = 1
    ROLL = 2


class AndrewPositioningState(object):
    POSITIONING_MODE = "positioning_mode"
    CANCELED = "canceled"


class AndrewPositioningNode(object):
    """
    A lightweight node record that mirrors the minimum shape WW positioning
    expects: an identifiable target plus accumulated offsets.
    """

    def __init__(self, node_type, owner, label=None, key=None):
        self.node_type = node_type
        self.owner = owner
        self.label = label or self._build_default_label(owner)
        self.key = key or self._build_default_key(node_type, owner)
        self.position_offset = [0.0, 0.0, 0.0]
        self.pitch_rotation_offset = 0.0
        self.rotation_offset = 0.0
        self.roll_rotation_offset = 0.0
        self.rotation_steps = []
        self.restore_location = None

    def _build_default_label(self, owner):
        first_name = getattr(owner, "first_name", None)
        last_name = getattr(owner, "last_name", None)
        if first_name and last_name:
            return "{} {}".format(first_name, last_name)
        if first_name:
            return str(first_name)
        return str(owner)

    def _build_default_key(self, node_type, owner):
        owner_id = getattr(owner, "id", None)
        if owner_id is None:
            owner_id = getattr(owner, "sim_id", None)
        if owner_id is None:
            owner_id = id(owner)
        return "{}:{}".format(int(node_type), owner_id)

    def reset(self):
        self.position_offset = [0.0, 0.0, 0.0]
        self.pitch_rotation_offset = 0.0
        self.rotation_offset = 0.0
        self.roll_rotation_offset = 0.0
        self.rotation_steps = []

    def restore_owner_location(self):
        if self.restore_location is None:
            return False
        return set_world_location(self.owner, self.restore_location)

    def add_rotation_step(self, axis, degrees):
        degrees = float(degrees)
        if not degrees:
            return

        if self.rotation_steps and self.rotation_steps[-1][0] == axis:
            combined_degrees = self.rotation_steps[-1][1] + degrees
            if abs(combined_degrees) < 0.000001:
                self.rotation_steps.pop()
            else:
                self.rotation_steps[-1] = (axis, combined_degrees)
            return

        self.rotation_steps.append((axis, degrees))

    def add_world_rotation_step(self, axis, degrees):
        axis_value = (
            float(axis.x),
            float(axis.y),
            float(axis.z),
        )
        self.rotation_steps.append((axis_value, float(degrees), "world"))

    def serialize(self):
        return {
            "node_type": int(self.node_type),
            "label": self.label,
            "position_offset": list(self.position_offset),
            "pitch_rotation_offset": float(self.pitch_rotation_offset),
            "rotation_offset": float(self.rotation_offset),
            "roll_rotation_offset": float(self.roll_rotation_offset),
            "rotation_steps": [
                tuple(rotation)
                for rotation in self.rotation_steps
            ],
        }


_ACTIVE_ANDREW_POSITIONING_SESSIONS = {}


def register_andrew_positioning_session(session):
    _ACTIVE_ANDREW_POSITIONING_SESSIONS[session.get_identifier()] = session
    return session


def get_andrew_positioning_session(session_identifier):
    if not session_identifier:
        return None
    return _ACTIVE_ANDREW_POSITIONING_SESSIONS.get(session_identifier)


def unregister_andrew_positioning_session(session_or_identifier):
    if hasattr(session_or_identifier, "get_identifier"):
        session_or_identifier = session_or_identifier.get_identifier()
    if not session_or_identifier:
        return
    _ACTIVE_ANDREW_POSITIONING_SESSIONS.pop(session_or_identifier, None)


def clear_andrew_positioning_sessions():
    _ACTIVE_ANDREW_POSITIONING_SESSIONS.clear()


def get_all_andrew_positioning_sessions():
    return list(_ACTIVE_ANDREW_POSITIONING_SESSIONS.values())


def get_active_andrew_positioning_session():
    for session in reversed(get_all_andrew_positioning_sessions()):
        if (
            session is not None
            and not session.is_canceled
            and session.get_state(AndrewPositioningState.POSITIONING_MODE, False)
        ):
            return session
    return None


def _owner_matches_sim(owner, sim_or_sim_id):
    if owner is None or sim_or_sim_id is None:
        return False

    owner_id = getattr(owner, "sim_id", None)
    if owner_id is None:
        owner_id = getattr(owner, "id", None)

    compare_id = getattr(sim_or_sim_id, "sim_id", None)
    if compare_id is None:
        compare_id = getattr(sim_or_sim_id, "id", None)
    if compare_id is None:
        compare_id = sim_or_sim_id

    try:
        return int(owner_id) == int(compare_id)
    except Exception:
        return owner_id == compare_id


def get_sessions_for_sim(sim_or_sim_id):
    matches = []
    for session in get_all_andrew_positioning_sessions():
        target_sim = None
        try:
            target_sim = session.get_target_sim()
        except Exception:
            target_sim = None
        if _owner_matches_sim(target_sim, sim_or_sim_id):
            matches.append(session)
            continue

        try:
            source_sim = session.get_source_sim()
        except Exception:
            source_sim = None
        if _owner_matches_sim(source_sim, sim_or_sim_id):
            matches.append(session)
    return matches


def get_target_sessions_for_sim(sim_or_sim_id):
    matches = []
    for session in get_all_andrew_positioning_sessions():
        try:
            target_sim = session.get_target_sim()
        except Exception:
            target_sim = None
        if _owner_matches_sim(target_sim, sim_or_sim_id):
            matches.append(session)
    return matches


def cancel_all_andrew_positioning_sessions(except_identifier=None):
    for session in get_all_andrew_positioning_sessions():
        try:
            session_identifier = session.get_identifier()
        except Exception:
            session_identifier = None
        if except_identifier is not None and session_identifier == except_identifier:
            continue
        try:
            session.cancel()
        except Exception:
            pass


def resolve_fgeh_target(interaction_instance):
    """
    Mirrors your couplepose target-switch logic so the positioning bridge can
    track the same actor Andrew is currently posing.
    """
    if interaction_instance is None:
        return None

    custom_target_id = getattr(interaction_instance, "fgeh_custom_target_id", None)
    if custom_target_id and services is not None:
        found_sim = services.object_manager().get(custom_target_id)
        if found_sim is not None:
            return found_sim

    return getattr(interaction_instance, "target", None)


class AndrewPositioningSession(object):
    """
    Independent positioning state used on top of Andrew's pose flow.

    Public methods used by the arrow objects and pie-menu interactions:
    - get_identifier
    - get_location
    - get_state / set_state
    - on_positioning_arrow_click
    - get_positioning_selected_nodes
    - get_actors_list
    - get_props
    - set/get positioning axis increment
    - set/get positioning rotation increment
    - set_positioning_rotation_axis_type
    - reset_positioning

    The important Andrew-specific hook is replay_pose_callback. That callback is
    where you re-push the current Andrew pose after offsets change.
    """

    INTERACTION_ATTR = "fgeh_positioning_session_id"

    def __init__(
        self,
        source_sim=None,
        target_sim=None,
        actors=None,
        pose_name=None,
        interaction_instance=None,
        replay_pose_callback=None,
        live_transform_callback=None,
        stop_callback=None,
    ):
        self._identifier = uuid.uuid4().hex
        self._source_sim = source_sim
        self._target_sim = target_sim
        self._pose_name = pose_name
        self._interaction_instance = interaction_instance
        self._replay_pose_callback = replay_pose_callback
        self._live_transform_callback = live_transform_callback
        self._stop_callback = stop_callback

        self._states = {
            AndrewPositioningState.POSITIONING_MODE: False,
            AndrewPositioningState.CANCELED: False,
        }

        self._positioning_axis_increment = 0.05
        self._positioning_rotation_increment = 5.0
        self._rotation_axis_type = RotationAxisType.YAW
        self._reference_center = None
        target_location = getattr(target_sim, "location", None)
        self._positioning_base_heading = get_yaw_degrees(target_location)

        self._actors = []
        self._props = []
        self._nodes_by_key = {}
        self._selected_node_keys = []

        initial_actors = []
        if actors:
            initial_actors.extend([actor for actor in actors if actor is not None])
        elif target_sim is not None:
            initial_actors.append(target_sim)

        for actor in initial_actors:
            self.add_actor(actor)

        if self._selected_node_keys == [] and self._nodes_by_key:
            self._selected_node_keys = [next(iter(self._nodes_by_key.keys()))]

        if interaction_instance is not None:
            self.attach_to_interaction(interaction_instance)

    @property
    def is_canceled(self):
        return bool(self._states.get(AndrewPositioningState.CANCELED, False))

    def get_identifier(self):
        return self._identifier

    def get_pose_name(self):
        return self._pose_name

    def set_pose_name(self, pose_name):
        self._pose_name = pose_name

    def get_source_sim(self):
        return self._source_sim

    def get_target_sim(self):
        return self._target_sim

    def set_target_sim(self, target_sim):
        self._target_sim = target_sim
        self._positioning_base_heading = get_yaw_degrees(
            getattr(target_sim, "location", None)
        )

    def set_source_sim(self, source_sim):
        self._source_sim = source_sim

    def get_location(self):
        """Return the current world anchor for the positioning layout."""
        anchor = self.get_reference_center() or self._target_sim or self._source_sim
        return getattr(anchor, "location", None)

    def get_anchor_object(self):
        return self.get_reference_center()

    def get_reference_center(self):
        reference_center = self._reference_center
        if reference_center is None:
            return None
        if getattr(reference_center, "location", None) is None:
            self._reference_center = None
            return None
        return reference_center

    def set_reference_center(self, reference_center):
        if reference_center is None or getattr(reference_center, "location", None) is None:
            return False
        for node in self.get_positioning_selected_nodes():
            if node.owner is reference_center:
                return False
        self._reference_center = reference_center
        return True

    def clear_reference_center(self):
        self._reference_center = None

    def is_reference_center(self, candidate):
        return candidate is not None and self.get_reference_center() is candidate

    def get_state(self, state_key, default=False):
        return self._states.get(state_key, default)

    def set_state(self, state_key, value):
        self._states[state_key] = value

    def attach_to_interaction(self, interaction_instance):
        if (
            self._interaction_instance is not None
            and self._interaction_instance is not interaction_instance
        ):
            try:
                setattr(self._interaction_instance, self.INTERACTION_ATTR, None)
            except Exception:
                pass
        self._interaction_instance = interaction_instance
        if interaction_instance is not None:
            setattr(interaction_instance, self.INTERACTION_ATTR, self.get_identifier())

    def detach_from_interaction(self):
        if self._interaction_instance is not None:
            try:
                setattr(self._interaction_instance, self.INTERACTION_ATTR, None)
            except Exception:
                pass
        self._interaction_instance = None

    def get_interaction_instance(self):
        return self._interaction_instance

    def get_actors_list(self):
        return list(self._actors)

    def get_props(self):
        return list(self._props)

    def get_positioning_selected_nodes(self):
        selected_nodes = []
        for node_key in self._selected_node_keys:
            node = self._nodes_by_key.get(node_key)
            if node is not None:
                selected_nodes.append(node)
        return selected_nodes

    def get_all_nodes(self):
        return list(self._nodes_by_key.values())

    def add_actor(self, actor, label=None):
        if actor is None:
            return None

        node = AndrewPositioningNode(
            PositioningNodeType.ACTOR,
            actor,
            label=label,
        )
        self._nodes_by_key[node.key] = node
        if actor not in self._actors:
            self._actors.append(actor)
        if node.key not in self._selected_node_keys:
            self._selected_node_keys.append(node.key)
        return node

    def set_linked_actors(self, actors):
        """
        Keep the primary target selected and replace the optional linked Sims.
        Existing nodes retain their accumulated offsets and base locations.
        """
        desired_actors = []
        primary_actor = self._target_sim
        if primary_actor is not None:
            desired_actors.append(primary_actor)

        for actor in actors or ():
            if actor is not None and actor not in desired_actors:
                desired_actors.append(actor)

        desired_keys = []
        for actor in desired_actors:
            node = AndrewPositioningNode(PositioningNodeType.ACTOR, actor)
            desired_keys.append(node.key)
            if node.key not in self._nodes_by_key:
                node._fgeh_base_location = None
                self._nodes_by_key[node.key] = node

        desired_key_set = set(desired_keys)
        for node_key, node in tuple(self._nodes_by_key.items()):
            if (
                node.node_type == PositioningNodeType.ACTOR
                and node_key not in desired_key_set
            ):
                self._nodes_by_key.pop(node_key, None)

        self._actors = desired_actors
        self._selected_node_keys = [
            node_key
            for node_key in desired_keys
            if node_key in self._nodes_by_key
        ]
        if self.get_reference_center() in desired_actors:
            self.clear_reference_center()

    def get_linked_actor_ids(self):
        linked_ids = []
        primary_actor = self._target_sim
        for actor in self._actors:
            if actor is primary_actor:
                continue
            actor_id = getattr(actor, "sim_id", None)
            if actor_id is None:
                actor_id = getattr(actor, "id", None)
            if actor_id is not None:
                linked_ids.append(actor_id)
        return linked_ids

    def add_prop(self, prop, label=None):
        if prop is None:
            return None

        existing_node = self.get_node_for_owner(prop)
        if existing_node is not None:
            if existing_node.key not in self._selected_node_keys:
                self._selected_node_keys.append(existing_node.key)
            return existing_node

        node = AndrewPositioningNode(
            PositioningNodeType.PROP,
            prop,
            label=label,
        )
        node.restore_location = getattr(prop, "location", None)
        self._nodes_by_key[node.key] = node
        if prop not in self._props:
            self._props.append(prop)
        if node.key not in self._selected_node_keys:
            self._selected_node_keys.append(node.key)
        return node

    def get_node_for_owner(self, owner):
        for node in self._nodes_by_key.values():
            if node.owner is owner:
                return node
        return None

    def is_linked_prop(self, prop):
        node = self.get_node_for_owner(prop)
        return node is not None and node.node_type == PositioningNodeType.PROP

    def remove_prop(self, prop):
        node = self.get_node_for_owner(prop)
        if node is None or node.node_type != PositioningNodeType.PROP:
            return False
        node.restore_owner_location()
        self._nodes_by_key.pop(node.key, None)
        self._selected_node_keys = [
            node_key
            for node_key in self._selected_node_keys
            if node_key != node.key
        ]
        self._props = [
            existing_prop
            for existing_prop in self._props
            if existing_prop is not prop
        ]
        if self.is_reference_center(prop):
            self.clear_reference_center()
        return True

    def clear_linked_props(self):
        removed = False
        for prop in list(self._props):
            removed = self.remove_prop(prop) or removed
        return removed

    def toggle_linked_prop(self, prop):
        if self.is_linked_prop(prop):
            return not self.remove_prop(prop)
        return self.add_prop(prop) is not None

    def restore_prop_nodes(self):
        for node in self.get_all_nodes():
            if node.node_type == PositioningNodeType.PROP:
                node.restore_owner_location()

    def select_node_keys(self, node_keys):
        self._selected_node_keys = [
            node_key for node_key in node_keys if node_key in self._nodes_by_key
        ]

    def set_positioning_selected_nodes(self, selected_nodes):
        selected_node_keys = []
        for node in selected_nodes or ():
            node_key = getattr(node, "key", None)
            if node_key in self._nodes_by_key:
                selected_node_keys.append(node_key)
        self.select_node_keys(selected_node_keys)

    def select_actor_by_id(self, actor_id):
        actor_id = str(actor_id)
        for node in self._nodes_by_key.values():
            node_owner = node.owner
            owner_id = getattr(node_owner, "id", None)
            if owner_id is None:
                owner_id = getattr(node_owner, "sim_id", None)
            if owner_id is not None and str(owner_id) == actor_id:
                self._selected_node_keys = [node.key]
                return node
        return None

    def select_all_actor_nodes(self):
        self._selected_node_keys = [
            node.key
            for node in self._nodes_by_key.values()
            if node.node_type == PositioningNodeType.ACTOR
        ]

    def set_positioning_axis_increment_value(self, value):
        try:
            value = float(value)
        except Exception:
            return
        if value <= 0:
            return
        self._positioning_axis_increment = value

    def get_positioning_axis_increment_value(self):
        return self._positioning_axis_increment

    def set_positioning_rotation_increment_value(self, value):
        try:
            value = float(value)
        except Exception:
            return
        if value <= 0:
            return
        self._positioning_rotation_increment = value

    def get_positioning_rotation_increment_value(self):
        return self._positioning_rotation_increment

    def set_positioning_rotation_axis_type(self, rotation_axis_type):
        self._rotation_axis_type = rotation_axis_type

    def get_positioning_rotation_axis_type(self):
        return self._rotation_axis_type

    def get_positioning_heading_degrees(self):
        reference_center = self.get_reference_center()
        if reference_center is not None:
            return get_yaw_degrees(getattr(reference_center, "location", None))

        target_location = getattr(self._target_sim, "location", None)
        if target_location is not None:
            return get_yaw_degrees(target_location)
        return self._positioning_base_heading

    def on_positioning_arrow_click(self, object_type):
        """Apply one positioning command from a clickable helper object."""
        if self.is_canceled:
            return False

        if object_type == PositioningObjectType.ROTATION_AXIS_X:
            self.set_positioning_rotation_axis_type(RotationAxisType.PITCH)
            return True
        if object_type == PositioningObjectType.ROTATION_AXIS_Y:
            self.set_positioning_rotation_axis_type(RotationAxisType.YAW)
            return True
        if object_type == PositioningObjectType.ROTATION_AXIS_Z:
            self.set_positioning_rotation_axis_type(RotationAxisType.ROLL)
            return True

        delta_position = [0.0, 0.0, 0.0]
        delta_rotation = 0.0
        increment = self.get_positioning_axis_increment_value()
        origin_location = self.get_location()
        heading_degrees = self.get_positioning_heading_degrees()

        if object_type == PositioningObjectType.POSITIONING_NORTH:
            offset = get_horizontal_local_offset(
                origin_location,
                z=1.0,
                distance=increment,
                yaw_degrees=heading_degrees,
            )
            delta_position[0] += offset.x
            delta_position[2] += offset.z
        elif object_type == PositioningObjectType.POSITIONING_SOUTH:
            offset = get_horizontal_local_offset(
                origin_location,
                z=-1.0,
                distance=increment,
                yaw_degrees=heading_degrees,
            )
            delta_position[0] += offset.x
            delta_position[2] += offset.z
        elif object_type == PositioningObjectType.POSITIONING_EAST:
            offset = get_horizontal_local_offset(
                origin_location,
                x=1.0,
                distance=increment,
                yaw_degrees=heading_degrees,
            )
            delta_position[0] += offset.x
            delta_position[2] += offset.z
        elif object_type == PositioningObjectType.POSITIONING_WEST:
            offset = get_horizontal_local_offset(
                origin_location,
                x=-1.0,
                distance=increment,
                yaw_degrees=heading_degrees,
            )
            delta_position[0] += offset.x
            delta_position[2] += offset.z
        elif object_type == PositioningObjectType.POSITIONING_UP:
            delta_position[1] += increment
        elif object_type == PositioningObjectType.POSITIONING_DOWN:
            delta_position[1] -= increment
        elif object_type == PositioningObjectType.ROTATION_CLOCKWISE:
            delta_rotation += self.get_positioning_rotation_increment_value()
        elif object_type == PositioningObjectType.ROTATION_COUNTERCLOCKWISE:
            delta_rotation -= self.get_positioning_rotation_increment_value()
        else:
            return False

        self.apply_delta_to_selected_nodes(
            delta_position=delta_position,
            delta_rotation=delta_rotation,
        )
        return True

    def apply_delta_to_selected_nodes(self, delta_position=None, delta_rotation=0.0):
        delta_position = delta_position or (0.0, 0.0, 0.0)
        selected_nodes = self.get_positioning_selected_nodes()
        if not selected_nodes:
            return

        reference_center = self.get_reference_center()
        reference_location = getattr(reference_center, "location", None)
        reference_transform = None
        if reference_location is not None:
            reference_transform = getattr(reference_location, "world_transform", None)
            if reference_transform is None:
                reference_transform = getattr(reference_location, "transform", None)

        rotation_axis = None
        rotation_orientation = None
        if delta_rotation and reference_transform is not None:
            if self._rotation_axis_type == RotationAxisType.PITCH:
                rotation_axis = reference_transform.orientation.transform_vector(
                    get_axis_vector("x")
                )
            elif self._rotation_axis_type == RotationAxisType.ROLL:
                rotation_axis = reference_transform.orientation.transform_vector(
                    get_axis_vector("z")
                )
            else:
                rotation_axis = reference_transform.orientation.transform_vector(
                    get_axis_vector("y")
                )
            rotation_orientation = build_axis_rotation(
                rotation_axis,
                delta_rotation,
            )

        for node in selected_nodes:
            node.position_offset[0] += float(delta_position[0])
            node.position_offset[1] += float(delta_position[1])
            node.position_offset[2] += float(delta_position[2])
            if rotation_orientation is not None:
                owner_location = getattr(node.owner, "location", None)
                owner_transform = None
                if owner_location is not None:
                    owner_transform = getattr(owner_location, "world_transform", None)
                    if owner_transform is None:
                        owner_transform = getattr(owner_location, "transform", None)
                if owner_transform is not None:
                    relative_position = (
                        owner_transform.translation
                        - reference_transform.translation
                    )
                    rotated_position = (
                        reference_transform.translation
                        + rotation_orientation.transform_vector(relative_position)
                    )
                    node.position_offset[0] += (
                        rotated_position.x - owner_transform.translation.x
                    )
                    node.position_offset[1] += (
                        rotated_position.y - owner_transform.translation.y
                    )
                    node.position_offset[2] += (
                        rotated_position.z - owner_transform.translation.z
                    )
                    node.add_world_rotation_step(rotation_axis, delta_rotation)
                    continue
            if self._rotation_axis_type == RotationAxisType.PITCH:
                node.pitch_rotation_offset += float(delta_rotation)
                node.add_rotation_step("x", delta_rotation)
            elif self._rotation_axis_type == RotationAxisType.ROLL:
                node.roll_rotation_offset += float(delta_rotation)
                node.add_rotation_step("z", delta_rotation)
            else:
                node.rotation_offset += float(delta_rotation)
                node.add_rotation_step("y", delta_rotation)

        self.apply_current_adjustments(selected_nodes)

    def apply_current_adjustments(self, target_nodes=None):
        """
        You only need one of these two hooks:

        1. live_transform_callback
           Apply node offsets immediately to sim/object transforms.

        2. replay_pose_callback
           Re-push the Andrew pose after offsets change.

        In practice, Andrew integrations usually start with replay_pose_callback
        and add live_transform_callback only if direct transform nudging proves
        stable for the specific pose type.
        """
        target_nodes = target_nodes or self.get_positioning_selected_nodes()

        if callable(self._replay_pose_callback):
            self._replay_pose_callback(self)

        if callable(self._live_transform_callback):
            for node in target_nodes:
                self._live_transform_callback(self, node)

    def build_adjustment_snapshot(self):
        return {
            node.key: node.serialize()
            for node in self._nodes_by_key.values()
        }

    def sync_selected_nodes_as_base(self):
        for node in self.get_positioning_selected_nodes():
            node._fgeh_base_location = getattr(node.owner, "location", None)
            node.reset()

    def reset_positioning(self):
        self.restore_prop_nodes()
        for node in self._nodes_by_key.values():
            node.reset()
        self.apply_current_adjustments(
            [
                node
                for node in self.get_all_nodes()
                if node.node_type != PositioningNodeType.PROP
            ]
        )

    def cancel(self):
        self.restore_prop_nodes()
        self.set_state(AndrewPositioningState.CANCELED, True)
        if callable(self._stop_callback):
            self._stop_callback(self)
        self.detach_from_interaction()
        unregister_andrew_positioning_session(self)

    def close(self):
        self.cancel()


def create_andrew_positioning_session(
    interaction_instance,
    pose_name=None,
    source_sim=None,
    target_sim=None,
    actors=None,
    replay_pose_callback=None,
    live_transform_callback=None,
    stop_callback=None,
):
    """
    Convenience factory for couplepose/Andrew integration.

    Suggested hook point:
    - inside custom_pose_on_choice, right before or right after
      push_tunable_continuation(...)

    Suggested replay callback:
    - store enough context to re-call Andrew's pose continuation for the same
      pose_name and target actor after an offset change
    """
    source_sim = source_sim or getattr(interaction_instance, "sim", None)
    target_sim = target_sim or resolve_fgeh_target(interaction_instance)

    if actors is None:
        actors = []
        if target_sim is not None:
            actors.append(target_sim)

    session = AndrewPositioningSession(
        source_sim=source_sim,
        target_sim=target_sim,
        actors=actors,
        pose_name=pose_name,
        interaction_instance=interaction_instance,
        replay_pose_callback=replay_pose_callback,
        live_transform_callback=live_transform_callback,
        stop_callback=stop_callback,
    )
    return register_andrew_positioning_session(session)


def get_session_for_interaction(interaction_instance):
    if interaction_instance is None:
        return None
    session_identifier = getattr(
        interaction_instance,
        AndrewPositioningSession.INTERACTION_ATTR,
        None,
    )
    return get_andrew_positioning_session(session_identifier)

import services
import sims4.localization
import sims4.resources
import injector2

from event_testing.results import TestResult
from interactions.base.immediate_interaction import ImmediateSuperInteraction
from sims4.resources import Types
from sims4.localization import LocalizationHelperTuning
from sims4.tuning.instance_manager import InstanceManager
from sims4.tuning.tunable import Tunable
from sims.sim import Sim
from ui.ui_dialog_generic import UiDialogTextInputOkCancel
from ui.ui_dialog_picker import SimPickerRow, UiSimPicker

from fgeh_config import (
    POSITIONING_CORE_DEFINITION_ID,
    POSITIONING_TOGGLE_INTERACTION_ID,
    POSITIONING_SET_REFERENCE_CENTER_INTERACTION_ID,
    POSITIONING_TOGGLE_LINKED_OBJECT_INTERACTION_ID,
    STR_POS_SELECT_SIMS_DESC,
    STR_POS_SELECT_SIMS_TITLE,
)
from fgeh_positioning_log import positioning_log, positioning_log_exception

from andrew_positioning_arrows import (
    get_positioning_object_type_from_target,
    get_positioning_session_from_target,
    remove_arrow_layout,
    spawn_arrow_layout,
    update_arrow_layout,
)
from andrew_positioning_session import (
    AndrewPositioningState,
    PositioningObjectType,
    create_andrew_positioning_session,
    get_all_andrew_positioning_sessions,
    get_active_andrew_positioning_session,
    get_sessions_for_sim,
    get_target_sessions_for_sim,
)
from andrew_positioning_runtime import apply_session_location


TEXT_INPUT_INCREMENT = "positioning_increment"
ANDREW_POSE_STOP_INTERACTION_ID = 12580983238869710811
_POSITIONING_TOGGLE_INJECTED_SIM_IDS = set()


def _localized_text(string_id):
    try:
        if string_id:
            return sims4.localization._create_localized_string(string_id)
    except Exception:
        pass
    return LocalizationHelperTuning.get_raw_text("")


def _format_float(value):
    text = "{:.3f}".format(float(value))
    text = text.rstrip("0").rstrip(".")
    return text or "0"


def _get_core_session(interaction_target):
    if (
        get_positioning_object_type_from_target(interaction_target)
        != PositioningObjectType.CORE
    ):
        if _looks_like_positioning_core_object(interaction_target):
            session = get_active_andrew_positioning_session()
            positioning_log(
                "Toggle core fallback target={} active_session={}",
                interaction_target,
                getattr(session, "get_identifier", lambda: None)() if session is not None else None,
            )
            return session
        return None

    session = get_positioning_session_from_target(interaction_target)
    if session is None and _looks_like_positioning_core_object(interaction_target):
        session = get_active_andrew_positioning_session()
        positioning_log(
            "Toggle core attached-data missing fallback target={} active_session={}",
            interaction_target,
            getattr(session, "get_identifier", lambda: None)() if session is not None else None,
        )
    return session


def _looks_like_positioning_core_object(target):
    if target is None:
        return False
    try:
        if "positioning_core" in str(target).lower():
            return True
    except Exception:
        pass
    try:
        definition = getattr(target, "definition", None)
        definition_id = getattr(definition, "id", None)
        if definition_id is None:
            definition_id = getattr(definition, "guid64", None)
        return int(definition_id) == int(POSITIONING_CORE_DEFINITION_ID)
    except Exception:
        return False


def _get_latest_uncanceled_session(prefer_positioning_mode=False):
    sessions = [
        session for session in get_all_andrew_positioning_sessions()
        if session is not None and not session.is_canceled
    ]
    if prefer_positioning_mode:
        for session in reversed(sessions):
            try:
                if session.get_state(AndrewPositioningState.POSITIONING_MODE, False):
                    return session
            except Exception:
                pass
    if sessions:
        return sessions[-1]
    return None


def _is_pose_interaction(interaction):
    if interaction is None:
        return False
    try:
        if getattr(interaction, "has_been_canceled", False):
            return False
        if getattr(interaction, "has_been_killed", False):
            return False
    except Exception:
        pass
    if hasattr(interaction, "pose_name"):
        return True
    try:
        affordance = getattr(interaction, "affordance", None)
        module_name = getattr(affordance, "__module__", "")
        class_name = getattr(affordance, "__name__", "")
        return module_name == "poseplayer" and "Pose" in class_name
    except Exception:
        return False


def _iter_sim_interactions(sim):
    if sim is None:
        return
    getter = getattr(sim, "get_all_running_and_queued_interactions", None)
    if callable(getter):
        try:
            for interaction in getter():
                yield interaction
            return
        except Exception:
            pass
    for attr_name in ("queue", "si_state"):
        try:
            for interaction in getattr(sim, attr_name, ()):
                yield interaction
        except Exception:
            pass


def _get_pose_interaction_for_sim(sim):
    for interaction in _iter_sim_interactions(sim):
        if _is_pose_interaction(interaction):
            return interaction
    return None


def _iter_instanced_sims():
    try:
        object_manager = services.object_manager()
        for obj in object_manager.get_all():
            if getattr(obj, "is_sim", False):
                yield obj
    except Exception:
        try:
            for sim_info in services.sim_info_manager().instanced_sims_gen():
                sim = sim_info
                if not getattr(sim, "is_sim", False):
                    getter = getattr(sim_info, "get_sim_instance", None)
                    sim = getter() if callable(getter) else None
                if sim is not None and getattr(sim, "is_sim", False):
                    yield sim
        except Exception:
            positioning_log_exception("_iter_instanced_sims failed")


def _find_pose_sim_for_positioning(target_sim=None, actor_sim=None):
    for sim in (target_sim, actor_sim):
        if sim is not None and getattr(sim, "is_sim", False):
            interaction = _get_pose_interaction_for_sim(sim)
            if interaction is not None:
                return sim, interaction
    for sim in _iter_instanced_sims():
        interaction = _get_pose_interaction_for_sim(sim)
        if interaction is not None:
            return sim, interaction
    return None, None


def _apply_positioning_live_transform(session, node):
    try:
        if apply_session_location(session, node):
            update_arrow_layout(session)
    except Exception:
        positioning_log_exception("Andrew positioning queue fallback apply failed")


def _stop_queue_positioning_session(session):
    try:
        remove_arrow_layout(session)
    except Exception:
        positioning_log_exception("Andrew positioning queue fallback stop failed")


def _create_session_from_pose_queue(target_sim, pose_interaction=None):
    if target_sim is None:
        return None
    pose_name = getattr(pose_interaction, "pose_name", None)
    try:
        session = create_andrew_positioning_session(
            pose_interaction,
            pose_name=pose_name,
            target_sim=target_sim,
            source_sim=target_sim,
            actors=[target_sim],
            live_transform_callback=_apply_positioning_live_transform,
            stop_callback=_stop_queue_positioning_session,
        )
        positioning_log(
            "Toggle queue fallback created session={} sim={} pose_name={}",
            getattr(session, "get_identifier", lambda: None)() if session is not None else None,
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            pose_name,
        )
        return session
    except Exception:
        positioning_log_exception("Toggle queue fallback create session failed")
        return None


def _get_session_for_sim_with_log(sim, reason):
    if sim is None or not getattr(sim, "is_sim", False):
        return None
    sessions = list(get_sessions_for_sim(sim))
    positioning_log(
        "Toggle session lookup for {} sim={} sim_id={} sessions={}",
        reason,
        sim,
        getattr(sim, "sim_id", getattr(sim, "id", None)),
        len(sessions),
    )
    for session in reversed(sessions):
        if session is not None and not session.is_canceled:
            try:
                actors = [
                    getattr(actor, "sim_id", getattr(actor, "id", None))
                    for actor in session.get_actors_list()
                ]
            except Exception:
                actors = []
            positioning_log(
                "Toggle session resolved for {} sim={} session={} actors={} target_sim={} source_sim={} positioning_mode={}",
                reason,
                sim,
                getattr(session, "get_identifier", lambda: None)(),
                actors,
                getattr(getattr(session, "get_target_sim", lambda: None)(), "sim_id", None),
                getattr(getattr(session, "get_source_sim", lambda: None)(), "sim_id", None),
                session.get_state(AndrewPositioningState.POSITIONING_MODE, False),
            )
            return session
    return None


def _get_toggle_session(interaction_target, actor_sim=None):
    session = _get_core_session(interaction_target)
    if session is not None:
        positioning_log(
            "Toggle session resolved from core target={} session={}",
            interaction_target,
            getattr(session, "get_identifier", lambda: None)(),
        )
        return session

    session = _get_session_for_sim_with_log(interaction_target, "target")
    if session is not None:
        return session

    if actor_sim is not interaction_target:
        session = _get_session_for_sim_with_log(actor_sim, "actor")
        if session is not None:
            return session

    session = _get_latest_uncanceled_session(prefer_positioning_mode=True)
    if session is not None:
        positioning_log(
            "Toggle session fallback latest target={} actor={} session={}",
            interaction_target,
            actor_sim,
            getattr(session, "get_identifier", lambda: None)(),
        )
        return session

    positioning_log("Toggle session not found for target={} actor={}", interaction_target, actor_sim)
    return None


def _get_or_create_toggle_session(interaction_target, actor_sim=None):
    session = _get_toggle_session(interaction_target, actor_sim=actor_sim)
    if session is not None:
        return session
    pose_sim, pose_interaction = _find_pose_sim_for_positioning(interaction_target, actor_sim)
    if pose_sim is None:
        return None
    return _create_session_from_pose_queue(pose_sim, pose_interaction)


def _get_positioning_affordance(interaction_id):
    try:
        key = sims4.resources.get_resource_key(
            interaction_id,
            Types.INTERACTION,
        )
        affordance = services.affordance_manager().get(key)
        positioning_log(
            "Positioning affordance lookup id={} key={} found={}",
            interaction_id,
            key,
            affordance is not None,
        )
        return affordance
    except Exception:
        positioning_log_exception("Positioning affordance lookup failed id={}".format(interaction_id))
        return None


def _ensure_positioning_toggle_on_instanced_sims(affordance, triggering_sim=None):
    if affordance is None:
        return 0

    sims_to_check = []
    if triggering_sim is not None:
        sims_to_check.append(triggering_sim)
    for sim in _iter_instanced_sims():
        if sim not in sims_to_check:
            sims_to_check.append(sim)

    injected_count = 0
    for sim in sims_to_check:
        try:
            sim_id = getattr(sim, "sim_id", getattr(sim, "id", None))
            if sim_id in _POSITIONING_TOGGLE_INJECTED_SIM_IDS:
                continue
            affordances = tuple(getattr(sim, "_super_affordances", ()))
            if affordance not in affordances:
                sim._super_affordances = affordances + (affordance,)
                injected_count += 1
            _POSITIONING_TOGGLE_INJECTED_SIM_IDS.add(sim_id)
        except Exception:
            positioning_log_exception("positioning toggle instanced sim inject failed")
    return injected_count


@injector2.inject(Sim, "potential_interactions", safe=True)
def _inject_positioning_toggle_potential_interaction(original, self, context, *args, **kwargs):
    seen_toggle = False
    seen_andrew_stop_pose = False
    try:
        for aop in original(self, context, *args, **kwargs):
            try:
                affordance = getattr(aop, "affordance", None)
                if affordance is None:
                    affordance = getattr(aop, "interaction_factory", None)
                affordance_id = getattr(affordance, "guid64", None)
                if affordance_id == POSITIONING_TOGGLE_INTERACTION_ID:
                    seen_toggle = True
                elif affordance_id == ANDREW_POSE_STOP_INTERACTION_ID:
                    seen_andrew_stop_pose = True
            except Exception:
                pass
            yield aop
    except Exception:
        positioning_log_exception("positioning toggle potential_interactions original failed")
        return

    if seen_toggle:
        return

    if not seen_andrew_stop_pose:
        return

    affordance = _get_positioning_affordance(POSITIONING_TOGGLE_INTERACTION_ID)
    if affordance is None:
        positioning_log("positioning toggle potential_interactions skipped: affordance missing")
        return

    injected_count = _ensure_positioning_toggle_on_instanced_sims(affordance, triggering_sim=self)
    positioning_log(
        "positioning toggle potential_interactions inject after Andrew Stop Posing target={} sim_id={} actor={} instanced_injected={}",
        self,
        getattr(self, "sim_id", getattr(self, "id", None)),
        getattr(context, "sim", None),
        injected_count,
    )
    try:
        for aop in affordance.potential_interactions(self, context, **kwargs):
            yield aop
    except Exception:
        positioning_log_exception("positioning toggle potential_interactions inject failed")


@injector2.inject(InstanceManager, "load_data_into_class_instances")
def _inject_reference_center_affordance(original, self, *args, **kwargs):
    result = original(self, *args, **kwargs)
    if self.TYPE != Types.OBJECT:
        return result

    positioning_log("reference/linked injector running for OBJECT manager tuned_count={}", len(getattr(self, "_tuned_classes", {})))

    affordances_to_add = []
    for interaction_id in (
        POSITIONING_SET_REFERENCE_CENTER_INTERACTION_ID,
        POSITIONING_TOGGLE_LINKED_OBJECT_INTERACTION_ID,
    ):
        affordance = _get_positioning_affordance(interaction_id)
        if affordance is not None:
            affordances_to_add.append(affordance)

    if not affordances_to_add:
        positioning_log("reference/linked injector found no affordances to add")
        return result

    injected_count = 0
    for object_tuning in self._tuned_classes.values():
        if not hasattr(object_tuning, "_super_affordances"):
            continue
        if getattr(object_tuning, "provides_terrain_interactions", False):
            if getattr(object_tuning, "__qualname__", "") != "object_terrain":
                continue
        affordances = tuple(getattr(object_tuning, "_super_affordances", ()))
        missing_affordances = tuple(
            affordance
            for affordance in affordances_to_add
            if affordance not in affordances
        )
        if missing_affordances:
            object_tuning._super_affordances = affordances + missing_affordances
            injected_count += 1
    positioning_log(
        "reference/linked injector complete affordance_count={} injected_tunings={}",
        len(affordances_to_add),
        injected_count,
    )
    return result


def _is_valid_reference_target(session, target):
    if session is None:
        return TestResult(False, "No visible Andrew positioning session.")
    if target is None or getattr(target, "location", None) is None:
        return TestResult(False, "Target has no world location.")
    if get_positioning_object_type_from_target(target) is not None:
        return TestResult(False, "Positioning helpers cannot be used.")
    return TestResult.TRUE


class AndrewPositioningSetReferenceCenterInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result

        session = get_active_andrew_positioning_session()
        result = _is_valid_reference_target(session, target)
        if not result:
            return result
        if not session.is_reference_center(target):
            for node in session.get_positioning_selected_nodes():
                if node.owner is target:
                    return TestResult(False, "Selected positioning nodes cannot be pivots.")
        return TestResult.TRUE

    def _run_interaction_gen(self, timeline):
        session = get_active_andrew_positioning_session()
        if session is not None:
            if session.is_reference_center(self.target):
                session.clear_reference_center()
            else:
                session.set_reference_center(self.target)
            update_arrow_layout(session)
        return True
        if False:
            yield None


class AndrewPositioningToggleLinkedObjectInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result

        session = get_active_andrew_positioning_session()
        result = _is_valid_reference_target(session, target)
        if not result:
            return result
        if getattr(target, "is_sim", False):
            return TestResult(False, "Use linked Sims picker for Sims.")
        if session.is_reference_center(target):
            return TestResult(False, "Reference center cannot be linked object.")
        return TestResult.TRUE

    def _run_interaction_gen(self, timeline):
        session = get_active_andrew_positioning_session()
        if session is not None:
            session.toggle_linked_prop(self.target)
            update_arrow_layout(session)
        return True
        if False:
            yield None


class AndrewPositioningCoreInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result

        session = _get_core_session(target)
        if session is None or session.is_canceled:
            return TestResult(False, "No active Andrew positioning session.")
        return TestResult.TRUE

    def get_positioning_session(self):
        return _get_core_session(self.target)

    def _run_interaction_gen(self, timeline):
        session = self.get_positioning_session()
        if session is not None:
            self.run_positioning_action(session)
        return True
        if False:
            yield None

    def run_positioning_action(self, session):
        raise NotImplementedError


class AndrewPositioningToggleArrowsInteraction(ImmediateSuperInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            positioning_log("ToggleArrows _test super failed target={} result={}", target, result)
            return result
        actor_sim = getattr(context, "sim", None)
        session = _get_toggle_session(target, actor_sim=actor_sim)
        if session is None:
            pose_sim, pose_interaction = _find_pose_sim_for_positioning(target, actor_sim)
            if pose_sim is not None:
                positioning_log(
                    "ToggleArrows _test visible from pose queue target={} actor={} pose_sim={} interaction={}",
                    target,
                    actor_sim,
                    getattr(pose_sim, "sim_id", getattr(pose_sim, "id", None)),
                    pose_interaction,
                )
                return TestResult.TRUE
            positioning_log("ToggleArrows _test hidden: no session target={}", target)
            return TestResult(False, "No active Andrew positioning session.")
        positioning_log(
            "ToggleArrows _test visible target={} session={}",
            target,
            getattr(session, "get_identifier", lambda: None)(),
        )
        return TestResult.TRUE

    def _run_interaction_gen(self, timeline):
        session = _get_or_create_toggle_session(self.target, actor_sim=getattr(self, "sim", None))
        if session is not None:
            positioning_log(
                "ToggleArrows run target={} session={} current_mode={}",
                self.target,
                getattr(session, "get_identifier", lambda: None)(),
                session.get_state(AndrewPositioningState.POSITIONING_MODE, False),
            )
            self.run_positioning_action(session)
        return True
        if False:
            yield None

    def run_positioning_action(self, session):
        if session.get_state(AndrewPositioningState.POSITIONING_MODE, False):
            remove_arrow_layout(
                session,
                keep_core=not getattr(self.target, "is_sim", False),
            )
        else:
            for other_session in get_all_andrew_positioning_sessions():
                if other_session is session or other_session.is_canceled:
                    continue
                remove_arrow_layout(other_session)
            spawn_arrow_layout(session)


class AndrewPositioningAxisIncrementInteraction(AndrewPositioningCoreInteraction):
    INSTANCE_TUNABLES = {
        "increment_value": Tunable(
            description="Position movement increment in world units.",
            tunable_type=float,
            default=0.05,
        ),
    }

    def run_positioning_action(self, session):
        session.set_positioning_axis_increment_value(self.increment_value)


class AndrewPositioningRotateIncrementInteraction(AndrewPositioningCoreInteraction):
    INSTANCE_TUNABLES = {
        "increment_value": Tunable(
            description="Position rotation increment in degrees.",
            tunable_type=float,
            default=5.0,
        ),
    }

    def run_positioning_action(self, session):
        session.set_positioning_rotation_increment_value(self.increment_value)


class AndrewPositioningSelectLinkedSimsInteraction(AndrewPositioningCoreInteraction):
    def run_positioning_action(self, session):
        linked_actor_ids = set(session.get_linked_actor_ids())
        primary_sim = session.get_target_sim()
        primary_sim_id = getattr(primary_sim, "sim_id", None)
        if primary_sim_id is None:
            primary_sim_id = getattr(primary_sim, "id", None)

        sim_infos = []
        for sim_info in services.sim_info_manager().instanced_sims_gen():
            if sim_info is None:
                continue
            sim_id = getattr(sim_info, "sim_id", None)
            if sim_id is None:
                sim_id = getattr(sim_info, "id", None)
            if sim_id is None or sim_id == primary_sim_id:
                continue
            sim_infos.append((sim_id, sim_info))

        if not sim_infos:
            return

        dialog = UiSimPicker.TunableFactory().default(
            self.sim,
            title=lambda **_: _localized_text(STR_POS_SELECT_SIMS_TITLE),
            text=lambda **_: _localized_text(STR_POS_SELECT_SIMS_DESC),
            min_selectable=0,
            max_selectable=len(sim_infos),
            column_count=3,
            should_show_names=True,
        )

        for sim_id, _sim_info in sim_infos:
            dialog.add_row(
                SimPickerRow(
                    sim_id=sim_id,
                    select_default=sim_id in linked_actor_ids,
                    tag=sim_id,
                )
            )

        def on_response(response_dialog):
            if not response_dialog.accepted:
                return

            selected_sims = []
            for sim_id in response_dialog.get_result_tags() or ():
                sim = services.object_manager().get(sim_id)
                if sim is not None:
                    selected_sims.append(sim)
            session.set_linked_actors(selected_sims)

        dialog.add_listener(on_response)
        dialog.show_dialog()


class _AndrewPositioningCustomIncrementInteraction(AndrewPositioningCoreInteraction):
    INSTANCE_TUNABLES = {
        "input_dialog": UiDialogTextInputOkCancel.TunableFactory(
            description="Dialog used to enter a positioning increment.",
            text_inputs=(TEXT_INPUT_INCREMENT,),
        ),
    }

    def get_current_value(self, session):
        raise NotImplementedError

    def apply_value(self, session, value):
        raise NotImplementedError

    def run_positioning_action(self, session):
        def on_response(dialog_response):
            if not dialog_response.accepted:
                return
            raw_value = dialog_response.text_input_responses.get(TEXT_INPUT_INCREMENT)
            try:
                value = float(raw_value)
            except (TypeError, ValueError):
                return
            if value <= 0:
                return
            self.apply_value(session, value)

        current_value = _format_float(self.get_current_value(session))
        text_input_overrides = {
            TEXT_INPUT_INCREMENT: lambda *_, **__: LocalizationHelperTuning.get_raw_text(
                current_value
            )
        }
        dialog = self.input_dialog(self.sim, self.get_resolver())
        dialog.show_dialog(
            on_response=on_response,
            text_input_overrides=text_input_overrides,
        )


class AndrewPositioningCustomAxisIncrementInteraction(
    _AndrewPositioningCustomIncrementInteraction
):
    def get_current_value(self, session):
        return session.get_positioning_axis_increment_value()

    def apply_value(self, session, value):
        session.set_positioning_axis_increment_value(value)


class AndrewPositioningCustomRotateIncrementInteraction(
    _AndrewPositioningCustomIncrementInteraction
):
    def get_current_value(self, session):
        return session.get_positioning_rotation_increment_value()

    def apply_value(self, session, value):
        session.set_positioning_rotation_increment_value(value)


class AndrewPositioningResetInteraction(AndrewPositioningCoreInteraction):
    def run_positioning_action(self, session):
        session.reset_positioning()


class AndrewPositioningSyncBaseInteraction(AndrewPositioningCoreInteraction):
    def run_positioning_action(self, session):
        session.sync_selected_nodes_as_base()
        update_arrow_layout(session)


class AndrewPositioningClearReferenceCenterInteraction(AndrewPositioningCoreInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result

        session = _get_core_session(target)
        if session is None or session.get_reference_center() is None:
            return TestResult(False, "No reference center is active.")
        return TestResult.TRUE

    def run_positioning_action(self, session):
        session.clear_reference_center()
        update_arrow_layout(session)


class AndrewPositioningClearLinkedObjectsInteraction(AndrewPositioningCoreInteraction):
    @classmethod
    def _test(cls, target, context, **interaction_parameters):
        result = super()._test(target, context, **interaction_parameters)
        if not result:
            return result

        session = _get_core_session(target)
        if session is None or not session.get_props():
            return TestResult(False, "No linked objects are active.")
        return TestResult.TRUE

    def run_positioning_action(self, session):
        if session.clear_linked_props():
            update_arrow_layout(session)

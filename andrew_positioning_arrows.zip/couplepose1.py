import os
import json
import traceback
import services
import sims4.utils
import sims4.collections
from ui.ui_dialog_picker import ObjectPickerRow, SimPickerRow, UiSimPicker
import sims4.localization
from sims4.localization import LocalizationHelperTuning
import poseplayer
import sims4.resources
import injector2
from fgeh_config import *
POSITIONING_SYSTEM_ACTIVE = False
if ENABLE_POSITIONING_SYSTEM:
    try:
        from andrew_positioning_session import (
            AndrewPositioningState,
            PositioningObjectType,
            create_andrew_positioning_session,
            get_session_for_interaction,
            get_sessions_for_sim,
        )
        from andrew_positioning_arrows import (
            remove_arrow_layout,
            spawn_arrow_layout,
            update_arrow_layout,
        )
        from andrew_positioning_runtime import (
            apply_session_location,
            reset_base_location,
        )
        POSITIONING_SYSTEM_ACTIVE = True
    except Exception:
        POSITIONING_SYSTEM_ACTIVE = False

if not POSITIONING_SYSTEM_ACTIVE:
    class AndrewPositioningState:
        POSITIONING_MODE = "POSITIONING_MODE"

    class PositioningObjectType:
        POSITIONING_NORTH = "POSITIONING_NORTH"
        POSITIONING_SOUTH = "POSITIONING_SOUTH"
        POSITIONING_EAST = "POSITIONING_EAST"
        POSITIONING_WEST = "POSITIONING_WEST"
        POSITIONING_UP = "POSITIONING_UP"
        POSITIONING_DOWN = "POSITIONING_DOWN"
        ROTATION_CLOCKWISE = "ROTATION_CLOCKWISE"
        ROTATION_COUNTERCLOCKWISE = "ROTATION_COUNTERCLOCKWISE"

    def create_andrew_positioning_session(*args, **kwargs):
        return None

    def get_session_for_interaction(*args, **kwargs):
        return None

    def get_sessions_for_sim(*args, **kwargs):
        return ()

    def remove_arrow_layout(*args, **kwargs):
        return None

    def spawn_arrow_layout(*args, **kwargs):
        return None

    def update_arrow_layout(*args, **kwargs):
        return None

    def apply_session_location(*args, **kwargs):
        return False

    def reset_base_location(*args, **kwargs):
        return None
# 引入我们的状态管理器和枚举
from fgeh_state import state, ViewMode, FavPackMode, CreatorMode, FavPoseMode, GroupMode, GlobalSettingsMode
from fgeh_positioning_log import positioning_log, positioning_log_exception

try:
    import fgeh_cas_accessory_loader as _fgeh_cas_accessory_loader
except Exception:
    try:
        from acclinked import fgeh_cas_accessory_loader as _fgeh_cas_accessory_loader
    except Exception:
        _fgeh_cas_accessory_loader = None

try:
    import fgeh_linked_object_binding_interactions as _fgeh_linked_object_binding_interactions
except Exception:
    _fgeh_linked_object_binding_interactions = None


def try_apply_linked_accessory_before_pose(target_sim, pose_name, pose_pack=None):
    if not bool(getattr(state, "auto_apply_linked_requirements", True)):
        return False
    pack_id = str(getattr(pose_pack, "__name__", "") or getattr(pose_pack, "pack_id", "") or "")
    if is_linked_cas_restore_before_apply_enabled(pack_id, pose_name):
        try_restore_linked_accessory_before_pose(target_sim)
        try:
            from fgeh_cas_accessory_outfit_utils import restore_all_original_outfits
            restore_all_original_outfits()
        except Exception:
            pass
    try:
        from fgeh_cas_accessory_picker import try_auto_apply_matching_accessory
    except Exception:
        try:
            from acclinked.fgeh_cas_accessory_picker import try_auto_apply_matching_accessory
        except Exception:
            return False

    try:
        return try_auto_apply_matching_accessory(
            target_sim,
            pose_name=pose_name,
            pose_pack=pose_pack,
            selected_cas_part_ids=get_enabled_linked_cas_part_ids(
                pack_id,
                pose_name,
            ),
        )
    except Exception:
        return False


def try_restore_linked_accessory_before_pose(target_sim):
    try:
        from fgeh_cas_accessory_outfit_utils import get_sim_info_from_target, restore_original_outfit
    except Exception:
        return False
    try:
        sim_info = get_sim_info_from_target(target_sim)
        if sim_info is None:
            return False
        return restore_original_outfit(sim_info)
    except Exception:
        return False


def try_spawn_linked_objects_before_pose(target_sim, pose_name, pose_pack=None):
    if not bool(getattr(state, "auto_apply_linked_requirements", True)):
        return []
    try:
        from fgeh_linked_object_runtime import spawn_matching_linked_objects
    except Exception:
        return []

    try:
        if bool(getattr(state, "replace_linked_objects_on_replay", True)):
            try:
                from fgeh_linked_object_runtime import destroy_all_linked_objects
                destroy_all_linked_objects()
            except Exception:
                pass
        pack_id = str(getattr(pose_pack, "__name__", "") or getattr(pose_pack, "pack_id", "") or "")
        available_definition_ids = []
        for option in get_linked_object_variant_options(pack_id, pose_name):
            try:
                definition_id = int(option.get("definition_id") or 0)
            except Exception:
                definition_id = 0
            if definition_id:
                available_definition_ids.append(definition_id)
        selected_definition_ids = get_enabled_linked_object_definition_ids(pack_id, pose_name, available_definition_ids)
        if selected_definition_ids == []:
            return []
        return spawn_matching_linked_objects(
            target_sim,
            pose_name=pose_name,
            pose_pack=pose_pack,
            pack_cache=getattr(state, "all_packs_cache", {}),
            selected_definition_id=get_selected_linked_object_definition_id(pack_id, pose_name),
            selected_definition_ids=selected_definition_ids,
        )
    except Exception:
        return []


def get_pose_pack_for_linked_pose(pose_name, fallback_pack=None):
    pose_name = str(pose_name or "")
    if not pose_name:
        return fallback_pack

    if fallback_pack is not None:
        try:
            for pose_item in getattr(fallback_pack, "pose_list", []) or []:
                if str(getattr(pose_item, "pose_name", "") or "") == pose_name:
                    return fallback_pack
        except Exception:
            pass

    try:
        if not getattr(state, "cache_built", False):
            build_cache_safe()
        pose_info = (getattr(state, "all_poses_cache", {}) or {}).get(pose_name)
        pack = pose_info.get("pack_ref") if isinstance(pose_info, dict) else None
        if pack is not None:
            return pack
    except Exception:
        pass

    try:
        for pack in (getattr(state, "all_packs_cache", {}) or {}).values():
            for pose_item in getattr(pack, "pose_list", []) or []:
                if str(getattr(pose_item, "pose_name", "") or "") == pose_name:
                    return pack
    except Exception:
        pass

    return fallback_pack


def apply_linked_requirements_when_pose_runs(interaction):
    if getattr(interaction, "_fgeh_linked_requirements_applied", False):
        return False
    setattr(interaction, "_fgeh_linked_requirements_applied", True)

    pose_name = getattr(interaction, "pose_name", None)
    if not pose_name:
        try:
            pose_name = (getattr(interaction, "interaction_parameters", {}) or {}).get("pose_name")
        except Exception:
            pose_name = None
    if not pose_name:
        return False

    target_sim = getattr(interaction, "sim", None) or getattr(interaction, "target", None)
    pose_pack = get_pose_pack_for_linked_pose(pose_name)
    try_apply_linked_accessory_before_pose(target_sim, pose_name, pose_pack)
    try_spawn_linked_objects_before_pose(target_sim, pose_name, pose_pack)
    return True


def schedule_linked_requirements_when_pose_runs(interaction):
    if getattr(interaction, "_fgeh_linked_requirements_scheduled", False):
        return False
    setattr(interaction, "_fgeh_linked_requirements_scheduled", True)

    try:
        import alarms
        from date_and_time import TimeSpan

        def _apply_linked_requirements(_alarm_handle):
            apply_linked_requirements_when_pose_runs(interaction)

        try:
            alarms.add_alarm_real_time(interaction, TimeSpan.ZERO, _apply_linked_requirements, use_sleep_time=False)
        except Exception:
            alarms.add_alarm(interaction, TimeSpan.ZERO, _apply_linked_requirements)
        return True
    except Exception:
        return apply_linked_requirements_when_pose_runs(interaction)


def cleanup_linked_objects_after_pose(target_sim):
    if not bool(getattr(state, "auto_destroy_linked_objects", True)):
        return 0
    try:
        from fgeh_linked_object_runtime import destroy_linked_objects_for_sim
    except Exception:
        return 0
    try:
        return destroy_linked_objects_for_sim(target_sim)
    except Exception:
        return 0


def restore_linked_requirements_after_pose_chain(target_sim):
    try:
        from fgeh_cas_accessory_outfit_utils import debug_log
        debug_log(
            "restore_linked_requirements_after_pose_chain called sim={} sim_id={} enabled={}",
            target_sim,
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            getattr(state, "restore_linked_requirements_when_pose_chain_finished", False),
        )
    except Exception:
        pass
    if not bool(getattr(state, "restore_linked_requirements_when_pose_chain_finished", False)):
        return False
    restored = False
    try:
        restored = bool(try_restore_linked_accessory_before_pose(target_sim))
    except Exception:
        restored = False
    try:
        from fgeh_cas_accessory_outfit_utils import restore_all_original_outfits
        restored = bool(restore_all_original_outfits()) or restored
    except Exception:
        pass
    try:
        from fgeh_linked_object_runtime import destroy_linked_objects_for_sim
        destroy_linked_objects_for_sim(target_sim)
    except Exception:
        pass
    try:
        from fgeh_cas_accessory_outfit_utils import debug_log
        debug_log("restore_linked_requirements_after_pose_chain result={}", restored)
    except Exception:
        pass
    return restored


# ==========================================
# 重命名弹窗组件
# ==========================================
from ui.ui_dialog_generic import UiDialogTextInputOkCancel
from interactions.base.immediate_interaction import ImmediateSuperInteraction
from sims4.tuning.tunable import TunableVariant

class FGEH_RenameGroupInteraction(ImmediateSuperInteraction):
    TEXT_INPUT_NEW_NAME = 'new_name_field'
    INSTANCE_TUNABLES = {
        'rename_dialog': TunableVariant(
            ok_dialog=UiDialogTextInputOkCancel.TunableFactory(text_inputs=TEXT_INPUT_NEW_NAME),
            ok_cancel_dialog=UiDialogTextInputOkCancel.TunableFactory(text_inputs=TEXT_INPUT_NEW_NAME),
            default='ok_dialog'
        )
    }

def show_fgeh_rename_dialog(interaction_instance, old_name, on_success_callback, allow_empty_submit=False):
    fgeh_interaction = services.get_instance_manager(sims4.resources.Types.INTERACTION).get(5376477438524819063)
    if not fgeh_interaction: return

    dialog = fgeh_interaction.rename_dialog(interaction_instance.sim, interaction_instance.get_resolver())
    
    actual_target = interaction_instance.target
    custom_target_id = getattr(interaction_instance, 'fgeh_custom_target_id', None)
    if custom_target_id:
        found_sim = services.object_manager().get(custom_target_id)
        if found_sim: actual_target = found_sim

    def on_rename_response(response_dialog):
        if not response_dialog.accepted:
            interaction_instance._show_picker_dialog(interaction_instance.sim, target_sim=actual_target)
            return

        new_name = response_dialog.text_input_responses.get(fgeh_interaction.TEXT_INPUT_NEW_NAME)
        if new_name is not None:
            new_name = new_name.strip()
            if allow_empty_submit:
                if new_name != old_name:
                    on_success_callback(new_name)
            elif new_name and new_name != old_name:
                on_success_callback(new_name)
        
        interaction_instance._show_picker_dialog(interaction_instance.sim, target_sim=actual_target)

    localized_old_name_factory = lambda *args, **kwargs: LocalizationHelperTuning.get_raw_text(old_name)
    overrides = {fgeh_interaction.TEXT_INPUT_NEW_NAME: localized_old_name_factory}

    dialog.add_listener(on_rename_response)
    dialog.show_dialog(text_input_overrides=overrides)


# ✨ 【完美修复版】：严格过滤幽灵数据防 1009 闪退，且只存 ID 防退出闪退
def show_fgeh_sim_picker(interaction_instance):
    from ui.ui_dialog_picker import UiSimPicker, SimPickerRow
    import services

    actual_target = interaction_instance.target
    custom_target_id = getattr(interaction_instance, 'fgeh_custom_target_id', None)
    if custom_target_id:
        found_sim = services.object_manager().get(custom_target_id)
        if found_sim: actual_target = found_sim

    try:
        dialog = UiSimPicker.TunableFactory().default(
            interaction_instance.sim,
            title=lambda **_: get_stbl_text(0xBE21DE2E),
            text=lambda **_: get_stbl_text(0xA3071EE6),
            min_selectable=1,
            max_selectable=1,
            column_count=3,
            should_show_names=True
        )

        for sim_info in services.sim_info_manager().instanced_sims_gen():
            if sim_info is None: continue
            
            sim_id = getattr(sim_info, 'id', getattr(sim_info, 'sim_id', 0))
            first_name = getattr(sim_info, 'first_name', None)
            
            if sim_id and first_name:
                dialog.add_row(SimPickerRow(sim_id=sim_id, select_default=False, tag=sim_id))

        def on_sim_picked(response_dialog):
            if not response_dialog.accepted or not response_dialog.get_result_tags():
                interaction_instance._show_picker_dialog(interaction_instance.sim, target_sim=actual_target)
                return

            selected_sim_id = response_dialog.get_result_tags()[0]
            interaction_instance.fgeh_custom_target_id = selected_sim_id

            new_target = services.object_manager().get(selected_sim_id) or interaction_instance.target
            interaction_instance._show_picker_dialog(interaction_instance.sim, target_sim=new_target)

        dialog.add_listener(on_sim_picked)
        dialog.show_dialog()
    except Exception as e:
        interaction_instance._show_picker_dialog(interaction_instance.sim, target_sim=actual_target)



def get_stbl_text(stbl_id, *args):
    try:
        if args:
            processed_args = []
            for arg in args:
                if isinstance(arg, str):
                    processed_args.append(LocalizationHelperTuning.get_raw_text(arg))
                else:
                    processed_args.append(arg)
            return sims4.localization._create_localized_string(stbl_id, *processed_args)
        return sims4.localization._create_localized_string(stbl_id)
    except:
        return LocalizationHelperTuning.get_raw_text(f"ID:{hex(stbl_id)}")

def get_display_name(obj_id, prefix=""):
    """
    获取对象（作者/动作包等）的自定义名称。
    obj_id: 原名字或原ID
    prefix: 用于区分类型的词缀，比如 "creator_" 或 "pack_"
    """
    key = f"{prefix}{obj_id}"
    return state.custom_names.get(key, str(obj_id))


def raw_picker_text(text):
    try:
        return LocalizationHelperTuning.get_raw_text(str(text))
    except:
        return str(text)


GLOBAL_SETTINGS_PACK_TOKEN = "fgeh_global_settings_folder"
LINKED_ACTIONS_PACK_TOKEN = "fgeh_linked_actions_folder"
LINKED_ALL_GROUP_TYPE = "all"
LINKED_UNGROUPED_GROUP_NAME = "未整理的联动动作"
LINKED_ALL_GROUP_NAME = "全部"
LINKED_GROUPED_ENTRY_NAME = "分组联动"
LINKED_ACTIONS_CATEGORY_PREFIX = "FGEH_LINKED_CATEGORY::"
LINKED_ACTIONS_POSE_PREFIX = "FGEH_LINKED_POSE::"
LINKED_GROUP_TYPE_PREFIX = "FGEH_LINKED_TYPE::"
LINKED_GROUP_PREFIX = "FGEH_LINKED_GROUP::"
LINKED_GROUPED_OUTER_PREFIX = "FGEH_LINKED_GROUPED_OUTER::"
LINKED_GROUPED_PACK_PREFIX = "FGEH_LINKED_GROUPED_PACK::"
LINKED_GROUPED_POSE_GROUP_PREFIX = "FGEH_LINKED_GROUPED_POSE_GROUP::"
LINKED_PLAY_CURRENT_GROUP_TAG = "FGEH_LINKED_PLAY_CURRENT_GROUP"
LINKED_PACK_PREFIX = "FGEH_LINKED_PACK::"
LINKED_ASSIGN_GROUP_PREFIX = "FGEH_LINKED_ASSIGN_GROUP::"
LINKED_GROUP_RENAME_PREFIX = "FGEH_LINKED_GROUP_RENAME::"
LINKED_GROUP_DELETE_PREFIX = "FGEH_LINKED_GROUP_DELETE::"
LINKED_OBJECT_STYLE_POSE_PREFIX = "FGEH_LINKED_OBJECT_STYLE_POSE::"
LINKED_OBJECT_STYLE_VARIANT_PREFIX = "FGEH_LINKED_OBJECT_STYLE_VARIANT::"
LINKED_OBJECT_SPAWN_TOGGLE_PREFIX = "FGEH_LINKED_OBJECT_SPAWN_TOGGLE::"
LINKED_OBJECT_APPLY_PACK_PREFIX = "FGEH_LINKED_OBJECT_APPLY_PACK::"
LINKED_SETTING_AUTO_TOGGLE_PREFIX = "FGEH_LINKED_SETTING_AUTO_TOGGLE::"
LINKED_SETTING_ENABLE_ALL_PREFIX = "FGEH_LINKED_SETTING_ENABLE_ALL::"
LINKED_SETTING_ITEM_TOGGLE_PREFIX = "FGEH_LINKED_SETTING_ITEM_TOGGLE::"
LINKED_SETTING_APPLY_PACK_PREFIX = "FGEH_LINKED_SETTING_APPLY_PACK::"
LINKED_SETTING_SET_POSE_ALL_PREFIX = "FGEH_LINKED_SETTING_SET_POSE_ALL::"
LINKED_SETTING_RESTORE_CAS_PREFIX = "FGEH_LINKED_SETTING_RESTORE_CAS::"
LINKED_SETTING_HIDE_OBJECT_PREFIX = "FGEH_LINKED_SETTING_HIDE_OBJECT::"
LINKED_SETTING_CLEAR_HIDDEN_OBJECTS_PREFIX = "FGEH_LINKED_SETTING_CLEAR_HIDDEN_OBJECTS::"
LINKED_SETTING_FOLDER_PREFIX = "FGEH_LINKED_SETTING_FOLDER::"
LINKED_SETTING_ASSET_FOLDER_PREFIX = "FGEH_LINKED_SETTING_ASSET_FOLDER::"
LINKED_IMPORTED_GROUP_NAME = "分组动作"
SPECIAL_VIEW_PACK_TOKENS = frozenset((
    "fgeh_grouped_folder",
    "fgeh_fav_packs_folder",
    "hegfcreator_folder",
    "fgeh_poses_folder",
    LINKED_ACTIONS_PACK_TOKEN,
    GLOBAL_SETTINGS_PACK_TOKEN,
))


def is_blank_entry_text(value):
    text = str(value).strip() if value is not None else ""
    if not text:
        return True
    return text.lower() in ("unknown", "0x00000000", "0x0", "0", "none", "nan")


def get_pack_display_name(pack, allow_placeholder=False):
    candidate = getattr(pack, 'display_name', None)
    if not is_blank_entry_text(candidate):
        return candidate
    if allow_placeholder:
        return get_stbl_text(STR_UI_UNNAMED_PACK)
    return None


def get_pose_display_name_safe(pose_item, allow_placeholder=False):
    candidate = getattr(pose_item, 'pose_display_name', None)
    if not is_blank_entry_text(candidate):
        return candidate
    if allow_placeholder:
        return get_stbl_text(STR_UI_UNNAMED_POSE)
    return None


def get_visible_pack_name(pack, fallback_text=None):
    name = get_pack_display_name(pack, allow_placeholder=False)
    if name is not None:
        return name
    return fallback_text if fallback_text is not None else get_stbl_text(STR_UI_UNNAMED_PACK)


def get_visible_pack_tuple(pack_id, pack):
    pack_name = get_pack_display_name(pack, allow_placeholder=False)
    if pack_name is None:
        return None
    return (pack_name, pack_id, pack)


def get_visible_pose_name(pose_item, fallback_text=None):
    name = get_pose_display_name_safe(pose_item, allow_placeholder=False)
    if name is not None:
        return name
    return fallback_text if fallback_text is not None else get_stbl_text(STR_UI_UNNAMED_POSE)


def should_hide_pack_entry(pack):
    return get_pack_display_name(pack, allow_placeholder=False) is None


def should_hide_pose_entry(pose_item):
    return get_pose_display_name_safe(pose_item, allow_placeholder=False) is None


def serialize_pack_reference(pack):
    if pack is None:
        return None
    if isinstance(pack, str):
        if pack in SPECIAL_VIEW_PACK_TOKENS:
            return pack
        return None
    pack_id = str(getattr(pack, '__name__', '')).strip()
    return pack_id or None


def deserialize_pack_reference(pack_ref):
    if not pack_ref:
        return None
    if pack_ref in SPECIAL_VIEW_PACK_TOKENS:
        return pack_ref
    build_cache_safe()
    return state.all_packs_cache.get(pack_ref)


def add_pack_to_browse_history(pack):
    pack_ref = serialize_pack_reference(pack)
    if not pack_ref or pack_ref in SPECIAL_VIEW_PACK_TOKENS:
        return
    old_history = list(getattr(state, 'browse_history_packs', []))
    history = [entry for entry in old_history if entry and entry != pack_ref]
    history.insert(0, pack_ref)
    limit = getattr(state, 'browse_history_limit', 30) or 30
    if limit < 1:
        limit = 1
    state.browse_history_limit = limit
    state.browse_history_packs = history[:limit]
    if state.browse_history_packs != old_history:
        try:
            save_favorites()
        except Exception:
            pass


def iter_browse_history_packs():
    build_cache_safe()
    items = []
    cleaned = []
    for pack_ref in getattr(state, 'browse_history_packs', []):
        pack = deserialize_pack_reference(pack_ref)
        if pack is None or isinstance(pack, str):
            continue
        cleaned.append(pack_ref)
        items.append((pack_ref, pack))
    if cleaned != getattr(state, 'browse_history_packs', []):
        state.browse_history_packs = cleaned
    return items


def remember_last_ui_snapshot(pack):
    pack_ref = serialize_pack_reference(pack)
    if not pack_ref:
        return
    state.last_ui_selection = pack_ref
    state.last_ui_snapshot = {
        'selected_pose_pack': pack_ref,
        'current_mode': int(state.current_mode),
        'came_from_l1_favs': bool(state.came_from_l1_favs),
        'came_from_creator': bool(state.came_from_creator),
        'came_from_grouped': bool(state.came_from_grouped),
        'is_in_normal_pack_manage_mode': bool(state.is_in_normal_pack_manage_mode),
        'return_to_fav_on_close': bool(state.return_to_fav_on_close),
        'global_fav_pack_ref': serialize_pack_reference(state.global_fav_pack_ref),
        'global_traced_pack_ref': serialize_pack_reference(state.global_traced_pack_ref),
        'p_view_mode': int(state.p_view_mode),
        'c_view_mode': int(state.c_view_mode),
        's_view_mode': int(state.s_view_mode),
        'g_view_mode': int(state.g_view_mode),
        'selected_fav_creator': state.selected_fav_creator,
        'selected_fav_group': state.selected_fav_group,
        'selected_creator': state.selected_creator,
        'selected_fav_pose_group': state.selected_fav_pose_group,
        'selected_group': state.selected_group,
        'selected_group_creator': state.selected_group_creator,
    }


def resolve_last_ui_snapshot():
    snapshot = getattr(state, 'last_ui_snapshot', None)
    if not snapshot:
        pack_ref = getattr(state, 'last_ui_selection', None)
        if not pack_ref:
            return None
        snapshot = {'selected_pose_pack': pack_ref}
    selected_pack = deserialize_pack_reference(snapshot.get('selected_pose_pack'))
    if selected_pack is None or selected_pack == GLOBAL_SETTINGS_PACK_TOKEN:
        return None
    return snapshot, selected_pack


def apply_last_ui_snapshot(snapshot):
    if not snapshot:
        return None

    selected_pack = deserialize_pack_reference(snapshot.get('selected_pose_pack'))
    if selected_pack is None:
        return None

    state.current_mode = ViewMode(snapshot.get('current_mode', int(ViewMode.NORMAL)))
    state.came_from_l1_favs = bool(snapshot.get('came_from_l1_favs', False))
    state.came_from_creator = bool(snapshot.get('came_from_creator', False))
    state.came_from_grouped = bool(snapshot.get('came_from_grouped', False))
    state.is_in_normal_pack_manage_mode = bool(snapshot.get('is_in_normal_pack_manage_mode', False))
    state.return_to_fav_on_close = bool(snapshot.get('return_to_fav_on_close', False))

    state.global_fav_pack_ref = deserialize_pack_reference(snapshot.get('global_fav_pack_ref'))
    state.global_traced_pack_ref = deserialize_pack_reference(snapshot.get('global_traced_pack_ref'))

    state.p_view_mode = FavPackMode(snapshot.get('p_view_mode', int(FavPackMode.FAVS)))
    state.c_view_mode = CreatorMode(snapshot.get('c_view_mode', int(CreatorMode.FAVS)))
    state.s_view_mode = FavPoseMode(snapshot.get('s_view_mode', int(FavPoseMode.PLAY)))
    state.g_view_mode = GroupMode(snapshot.get('g_view_mode', int(GroupMode.LIST)))

    state.selected_fav_creator = snapshot.get('selected_fav_creator')
    state.selected_fav_group = snapshot.get('selected_fav_group')
    state.selected_creator = snapshot.get('selected_creator')
    state.selected_fav_pose_group = snapshot.get('selected_fav_pose_group')
    state.selected_group = snapshot.get('selected_group')
    state.selected_group_creator = snapshot.get('selected_group_creator')
    return selected_pack


def get_raw_text(text):
    try:
        return LocalizationHelperTuning.get_raw_text(str(text))
    except:
        return str(text)


def create_localized_picker_row(name, icon, tag=None, description=None, count=0):
    kwargs = {
        'name': name,
        'icon': icon,
        'tag': tag
    }
    if description is not None:
        kwargs['row_description'] = description
    if count:
        kwargs['count'] = count
    return ObjectPickerRow(**kwargs)


def create_raw_picker_row(name, icon, tag, description=None):
    kwargs = {
        'name': get_raw_text(name),
        'icon': icon,
        'tag': tag
    }
    if description:
        kwargs['row_description'] = get_raw_text(description)
    return ObjectPickerRow(**kwargs)


def get_positioning_session(interaction_instance):
    if not POSITIONING_SYSTEM_ACTIVE:
        positioning_log("get_positioning_session skipped: positioning system inactive")
        return None
    try:
        session = get_session_for_interaction(interaction_instance)
        if session is not None and not session.is_canceled:
            positioning_log(
                "get_positioning_session found attached session={} interaction={} target={}",
                getattr(session, "get_identifier", lambda: None)(),
                interaction_instance,
                getattr(interaction_instance, "target", None),
            )
            return session

        target_sim = resolve_positioning_target(interaction_instance)
        sessions = list(get_sessions_for_sim(target_sim))
        positioning_log(
            "get_positioning_session lookup target={} sim_id={} sessions={}",
            target_sim,
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            len(sessions),
        )
        for session in reversed(sessions):
            if session is None or session.is_canceled:
                continue
            try:
                session.attach_to_interaction(interaction_instance)
            except:
                pass
            positioning_log(
                "get_positioning_session attached existing session={} to interaction={}",
                getattr(session, "get_identifier", lambda: None)(),
                interaction_instance,
            )
            return session
    except Exception:
        positioning_log_exception("get_positioning_session failed")
        return None

    return None


def resolve_positioning_target(interaction_instance):
    if interaction_instance is None:
        return None
    custom_target_id = getattr(interaction_instance, 'fgeh_custom_target_id', None)
    if custom_target_id:
        try:
            found_sim = services.object_manager().get(custom_target_id)
            if found_sim is not None:
                return found_sim
        except:
            pass
    return getattr(interaction_instance, 'target', None)


def cancel_positioning_session_for_interaction(interaction_instance):
    """
    The pose browser is only a controller for the active positioning session.
    Closing or navigating the browser must not end positioning while the pose
    itself is still running.
    """
    if not POSITIONING_SYSTEM_ACTIVE:
        return
    try:
        session = get_session_for_interaction(interaction_instance)
    except:
        session = None
    if session is not None:
        try:
            session.detach_from_interaction()
        except:
            pass


def _get_sim_id_safe(sim_or_sim_id):
    if sim_or_sim_id is None:
        return None
    sim_id = getattr(sim_or_sim_id, 'sim_id', None)
    if sim_id is None:
        sim_id = getattr(sim_or_sim_id, 'id', None)
    if sim_id is None:
        sim_id = sim_or_sim_id
    return sim_id


def cancel_positioning_sessions_for_sim(sim_or_sim_id, reason="unknown"):
    if not POSITIONING_SYSTEM_ACTIVE:
        return
    for session in list(get_sessions_for_sim(sim_or_sim_id)):
        positioning_log(
            "cancel_positioning_sessions_for_sim reason={} sim={} session={} positioning_mode={}",
            reason,
            getattr(sim_or_sim_id, "sim_id", getattr(sim_or_sim_id, "id", sim_or_sim_id)),
            getattr(session, "get_identifier", lambda: None)(),
            session.get_state(AndrewPositioningState.POSITIONING_MODE, False),
        )
        try:
            remove_arrow_layout(session)
        except:
            pass
        try:
            session.cancel()
        except:
            pass


def stop_positioning_session(session):
    positioning_log(
        "stop_positioning_session session={}",
        getattr(session, "get_identifier", lambda: None)() if session is not None else None,
    )
    try:
        remove_arrow_layout(session)
    except Exception:
        positioning_log_exception("stop_positioning_session remove_arrow_layout failed")
        pass


def _is_live_pose_interaction(interaction, exclude_interaction=None):
    if interaction is None or interaction is exclude_interaction:
        return False
    try:
        if isinstance(interaction, poseplayer.PoseInteraction):
            if getattr(interaction, 'has_been_canceled', False):
                return False
            if getattr(interaction, 'has_been_killed', False):
                return False
            return True
    except:
        pass
    return hasattr(interaction, 'pose_name')


def sim_has_pending_pose_interaction(sim, exclude_interaction=None):
    if sim is None:
        return False

    getter = getattr(sim, 'get_all_running_and_queued_interactions', None)
    if callable(getter):
        try:
            for interaction in getter():
                if _is_live_pose_interaction(interaction, exclude_interaction=exclude_interaction):
                    return True
        except:
            pass

    try:
        for interaction in getattr(sim, 'queue', ()):
            if _is_live_pose_interaction(interaction, exclude_interaction=exclude_interaction):
                return True
    except:
        pass

    try:
        for interaction in getattr(sim, 'si_state', ()):
            if _is_live_pose_interaction(interaction, exclude_interaction=exclude_interaction):
                return True
    except:
        pass

    return False


def schedule_pose_chain_cleanup_check(sim, reason="unknown"):
    if sim is None:
        return False
    if getattr(sim, "_fgeh_pose_chain_cleanup_check_scheduled", False):
        return False
    try:
        setattr(sim, "_fgeh_pose_chain_cleanup_check_scheduled", True)
    except Exception:
        pass
    try:
        import alarms
        from date_and_time import TimeSpan

        def _delayed_cleanup(_alarm_handle):
            try:
                setattr(sim, "_fgeh_pose_chain_cleanup_check_scheduled", False)
            except Exception:
                pass
            cleanup_positioning_if_pose_chain_finished(sim, reason=str(reason) + "_delayed")

        try:
            alarms.add_alarm_real_time(sim, TimeSpan.ONE, _delayed_cleanup, use_sleep_time=False)
        except Exception:
            alarms.add_alarm(sim, TimeSpan.ONE, _delayed_cleanup)
        return True
    except Exception:
        try:
            setattr(sim, "_fgeh_pose_chain_cleanup_check_scheduled", False)
        except Exception:
            pass
        return False


def cleanup_positioning_if_pose_chain_finished(sim, exclude_interaction=None, reason="unknown"):
    if sim is None:
        positioning_log("cleanup_positioning skipped reason={} sim=None", reason)
        try:
            from fgeh_cas_accessory_outfit_utils import debug_log
            debug_log("cleanup_positioning_if_pose_chain_finished skipped reason={} sim=None", reason)
        except Exception:
            pass
        return
    if sim_has_pending_pose_interaction(sim, exclude_interaction=exclude_interaction):
        positioning_log(
            "cleanup_positioning kept reason={} sim={} pending_pose=True exclude={}",
            reason,
            getattr(sim, "sim_id", getattr(sim, "id", None)),
            exclude_interaction,
        )
        try:
            from fgeh_cas_accessory_outfit_utils import debug_log
            debug_log(
                "cleanup_positioning_if_pose_chain_finished delayed reason={} sim_id={} restore_enabled={}",
                reason,
                getattr(sim, "sim_id", getattr(sim, "id", None)),
                getattr(state, "restore_linked_requirements_when_pose_chain_finished", False),
            )
        except Exception:
            pass
        schedule_pose_chain_cleanup_check(sim, reason=reason)
        return
    try:
        from fgeh_cas_accessory_outfit_utils import debug_log
        debug_log(
            "cleanup_positioning_if_pose_chain_finished running reason={} sim_id={} restore_enabled={} positioning_active={}",
            reason,
            getattr(sim, "sim_id", getattr(sim, "id", None)),
            getattr(state, "restore_linked_requirements_when_pose_chain_finished", False),
            POSITIONING_SYSTEM_ACTIVE,
        )
    except Exception:
        pass
    if bool(getattr(state, "restore_linked_requirements_when_pose_chain_finished", False)):
        restore_linked_requirements_after_pose_chain(sim)
    else:
        cleanup_linked_objects_after_pose(sim)
    if not POSITIONING_SYSTEM_ACTIVE:
        return
    positioning_log(
        "cleanup_positioning closing reason={} sim={} pending_pose=False exclude={}",
        reason,
        getattr(sim, "sim_id", getattr(sim, "id", None)),
        exclude_interaction,
    )
    cancel_positioning_sessions_for_sim(sim, reason=reason)


def _get_pose_cleanup_sim(interaction):
    target_sim = getattr(interaction, 'sim', None)
    if target_sim is None:
        target_sim = getattr(interaction, 'target', None)
    return target_sim


def _pose_interaction_cancelled_cleanup(interaction):
    target_sim = _get_pose_cleanup_sim(interaction)
    try:
        positioning_log(
            "pose cancelled callback scheduling linked cleanup interaction={} sim={} pose_name={}",
            interaction,
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            getattr(interaction, "pose_name", None),
        )
    except:
        pass
    try:
        from fgeh_cas_accessory_outfit_utils import debug_log
        debug_log(
            "pose cancelled callback scheduling cleanup sim_id={} pose_name={}",
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            getattr(interaction, "pose_name", None),
        )
    except Exception:
        pass
    if not schedule_pose_chain_cleanup_check(target_sim, reason="pose_cancelled_callback"):
        cleanup_positioning_if_pose_chain_finished(target_sim, exclude_interaction=interaction, reason="pose_cancelled_callback")


def register_positioning_cleanup_callback_for_pose_interaction(interaction):
    if interaction is None:
        return
    if getattr(interaction, '_fgeh_positioning_cleanup_registered', False):
        return
    if not _is_live_pose_interaction(interaction):
        return
    target_sim = _get_pose_cleanup_sim(interaction)
    register_callback = getattr(interaction, 'register_on_cancelled_callback', None)
    if not callable(register_callback):
        return
    try:
        register_callback(_pose_interaction_cancelled_cleanup)
        interaction._fgeh_positioning_cleanup_registered = True
        try:
            from fgeh_cas_accessory_outfit_utils import debug_log
            debug_log(
                "registered pose cancel cleanup callback sim_id={} pose_name={}",
                getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
                getattr(interaction, "pose_name", None),
            )
        except Exception:
            pass
    except:
        pass


def _apply_positioning_live_transform(session, node):
    if not POSITIONING_SYSTEM_ACTIVE:
        return
    if apply_session_location(session, node):
        try:
            update_arrow_layout(session)
        except:
            pass


def _replay_current_andrew_pose(session):
    return


def ensure_positioning_session(interaction_instance, pose_name, target_sim):
    if not POSITIONING_SYSTEM_ACTIVE:
        positioning_log("ensure_positioning_session skipped inactive pose_name={} target={}", pose_name, target_sim)
        return None

    positioning_log(
        "ensure_positioning_session start pose_name={} interaction={} interaction_sim={} target_sim={} custom_target_id={}",
        pose_name,
        interaction_instance,
        getattr(interaction_instance, "sim", None),
        target_sim,
        getattr(interaction_instance, "fgeh_custom_target_id", None),
    )
    source_sim = getattr(interaction_instance, 'sim', None)
    actors = []
    for actor in (target_sim, source_sim):
        if actor is not None and actor not in actors:
            actors.append(actor)
    positioning_log(
        "ensure_positioning_session actors prepared count={} actors={}",
        len(actors),
        [getattr(actor, "sim_id", getattr(actor, "id", None)) for actor in actors],
    )

    existing_session = get_positioning_session(interaction_instance)
    if existing_session is not None:
        positioning_log(
            "ensure_positioning_session reuse existing session={} pose_name={} target_sim={} source_sim={}",
            getattr(existing_session, "get_identifier", lambda: None)(),
            pose_name,
            getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
            getattr(source_sim, "sim_id", getattr(source_sim, "id", None)),
        )
        try:
            existing_session.attach_to_interaction(interaction_instance)
        except:
            pass
        try:
            existing_session.set_pose_name(pose_name)
        except:
            pass
        try:
            existing_session.set_target_sim(target_sim)
        except:
            pass
        try:
            existing_session.set_source_sim(source_sim)
        except:
            pass
        try:
            existing_session.set_linked_actors(actors)
        except:
            pass
        try:
            register_positioning_cleanup_callback_for_pose_interaction(interaction_instance)
        except:
            pass
        return existing_session

    session = create_andrew_positioning_session(
        interaction_instance,
        pose_name=pose_name,
        target_sim=target_sim,
        source_sim=source_sim,
        actors=actors or None,
        live_transform_callback=_apply_positioning_live_transform,
        stop_callback=stop_positioning_session
    )
    positioning_log(
        "ensure_positioning_session created session={} target_sim={} source_sim={} actors={}",
        getattr(session, "get_identifier", lambda: None)(),
        getattr(getattr(session, "get_target_sim", lambda: None)(), "sim_id", None),
        getattr(getattr(session, "get_source_sim", lambda: None)(), "sim_id", None),
        [getattr(actor, "sim_id", getattr(actor, "id", None)) for actor in session.get_actors_list()],
    )
    for node in session.get_all_nodes():
        try:
            reset_base_location(node)
        except:
            pass

    try:
        register_positioning_cleanup_callback_for_pose_interaction(interaction_instance)
    except:
        pass
    return session


def handle_positioning_choice(interaction_instance, choice_tag):
    if not POSITIONING_SYSTEM_ACTIVE:
        return False
    session = get_positioning_session(interaction_instance)
    if session is None:
        return False

    action = str(choice_tag).split("::", 1)[1]
    if action == "STOP":
        positioning_log(
            "handle_positioning_choice manual STOP session={} interaction={}",
            getattr(session, "get_identifier", lambda: None)(),
            interaction_instance,
        )
        session.cancel()
        return True
    if action == "RESET":
        session.reset_positioning()
        return True
    if action == "TOGGLE_LAYOUT":
        if session.get_state(AndrewPositioningState.POSITIONING_MODE, False):
            remove_arrow_layout(session)
        else:
            spawn_arrow_layout(session)
        return True
    if action == "STEP_SMALL":
        session.set_positioning_axis_increment_value(0.02)
        return True
    if action == "STEP_MED":
        session.set_positioning_axis_increment_value(0.05)
        return True
    if action == "STEP_LARGE":
        session.set_positioning_axis_increment_value(0.10)
        return True

    mapping = {
        "NORTH": PositioningObjectType.POSITIONING_NORTH,
        "SOUTH": PositioningObjectType.POSITIONING_SOUTH,
        "EAST": PositioningObjectType.POSITIONING_EAST,
        "WEST": PositioningObjectType.POSITIONING_WEST,
        "UP": PositioningObjectType.POSITIONING_UP,
        "DOWN": PositioningObjectType.POSITIONING_DOWN,
        "ROT_CW": PositioningObjectType.ROTATION_CLOCKWISE,
        "ROT_CCW": PositioningObjectType.ROTATION_COUNTERCLOCKWISE,
    }
    object_type = mapping.get(action)
    if object_type is None:
        return False

    session.on_positioning_arrow_click(object_type)
    return True
# ==========================================
# 【C 方案完美修复版】RowFactory 工厂函数
# ==========================================
class RowFactory:
    """集中管理所有 ObjectPickerRow 生成逻辑，绝对安全防崩溃版"""
    
    @staticmethod
    def create_button(name_stbl, icon, tag, desc_stbl=None, count=0):
        kwargs = {
            'name': get_stbl_text(name_stbl),
            'icon': icon,
            'tag': tag
        }
        if desc_stbl:
            kwargs['row_description'] = get_stbl_text(desc_stbl)
        if count:  
            kwargs['count'] = count
        return ObjectPickerRow(**kwargs)
    
    @staticmethod
    def create_button_with_params(name_stbl, icon, tag, desc_stbl=None, *desc_params):
        kwargs = {
            'name': get_stbl_text(name_stbl, *desc_params),
            'icon': icon,
            'tag': tag
        }
        if desc_stbl:
            kwargs['row_description'] = get_stbl_text(desc_stbl, *desc_params)
        return ObjectPickerRow(**kwargs)
    
    @staticmethod
    def create_pack_row(pack_name, pack_id, pack, tag_prefix=""):
        resolved_name = pack_name or get_pack_display_name(pack, allow_placeholder=False)
        if resolved_name is None:
            resolved_name = get_stbl_text(STR_UI_UNNAMED_PACK)
        kwargs = {
            'name': resolved_name,
            'icon': getattr(pack, 'icon', MY_CUSTOM_ICON),
            'tag': f"{tag_prefix}{pack_id}" if tag_prefix else pack_id
        }
        desc = getattr(pack, 'description', None)
        if desc: 
            kwargs['row_description'] = desc
        pose_list = getattr(pack, 'pose_list', [])
        if pose_list: 
            kwargs['count'] = len(pose_list)
        return ObjectPickerRow(**kwargs)

    @staticmethod
    def create_delete_pack_row(pck_name, pck_id, pck, tag_prefix):
        kwargs = {
            'name': get_stbl_text(STR_DYN_DELETE_ITEM, pck_name),
            'icon': getattr(pck, 'icon', MY_CUSTOM_ICON),
            'tag': f"{tag_prefix}{pck_id}"
        }
        desc = getattr(pck, 'description', None)
        if desc: kwargs['row_description'] = desc
        pose_list = getattr(pck, 'pose_list', [])
        if pose_list: kwargs['count'] = len(pose_list)
        return ObjectPickerRow(**kwargs)
    
    @staticmethod
    def create_pose_row(pose_item, tag_prefix=""):
        resolved_name = get_pose_display_name_safe(pose_item, allow_placeholder=False)
        if resolved_name is None:
            resolved_name = get_stbl_text(STR_UI_UNNAMED_POSE)
        kwargs = {
            'name': resolved_name,
            'icon': pose_item.icon,
            'tag': f"{tag_prefix}{getattr(pose_item, 'pose_name', '')}" if tag_prefix else pose_item
        }
        desc = getattr(pose_item, 'pose_description', None)
        if desc: kwargs['row_description'] = desc
        return ObjectPickerRow(**kwargs)
    
    @staticmethod
    def create_folder_row(name_stbl, desc_stbl, icon, tag):
        kwargs = {
            'name': get_stbl_text(name_stbl),
            'icon': icon,
            'tag': tag
        }
        if desc_stbl: 
            kwargs['row_description'] = get_stbl_text(desc_stbl)
        return ObjectPickerRow(**kwargs)


# === 文件系统重构 ===
def get_mod_directory():
    try: return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except: return ''

FAV_FILE = os.path.join(get_mod_directory(), 'my_favorite_poses.json')
FAV_CREATORS_FILE = os.path.join(get_mod_directory(), 'my_favorite_creators.json')
FAV_PACKS_FILE = os.path.join(get_mod_directory(), 'my_favorite_packs.json')
USER_DATA_FILE = os.path.join(get_mod_directory(), 'fgeh_user_data.json')
USER_DATA_TMP = os.path.join(get_mod_directory(), 'fgeh_user_data_tmp')
USER_DATA_TMP_LEGACY = os.path.join(get_mod_directory(), 'fgeh_user_data.json.tmp')
USER_DATA_BAK = os.path.join(get_mod_directory(), 'fgeh_user_data_backup')
USER_DATA_BAK_LEGACY = os.path.join(get_mod_directory(), 'fgeh_user_data.bak')

def load_favorites():
    def try_load_file(filepath):
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict): return data
            except: pass
        return None

    data = try_load_file(USER_DATA_FILE)
    if data is None: data = try_load_file(USER_DATA_TMP)
    if data is None: data = try_load_file(USER_DATA_TMP_LEGACY)
    if data is None: data = try_load_file(USER_DATA_BAK)
    if data is None: data = try_load_file(USER_DATA_BAK_LEGACY)
        
    if data:
        state.favorite_poses = list(dict.fromkeys(data.get("fav_poses", [])))
        state.favorite_creators = list(dict.fromkeys(data.get("fav_creators", [])))
        state.favorite_packs = list(dict.fromkeys(data.get("fav_packs", [])))
        
        raw_grouped = data.get("grouped_packs", {})
        state.grouped_packs = raw_grouped if isinstance(raw_grouped, dict) else {}
        
        raw_fav_groups = data.get("user_fav_groups", {})
        state.user_fav_groups = raw_fav_groups if isinstance(raw_fav_groups, dict) else {}

        raw_fav_pose_groups = data.get("user_fav_pose_groups", {})
        state.user_fav_pose_groups = raw_fav_pose_groups if isinstance(raw_fav_pose_groups, dict) else {}
        
        raw_grouped_packs_groups = data.get("user_grouped_packs_groups", {})
        state.user_grouped_packs_groups = raw_grouped_packs_groups if isinstance(raw_grouped_packs_groups, dict) else {}

        raw_linked_groups = data.get("linked_groups", {})
        state.linked_groups = raw_linked_groups if isinstance(raw_linked_groups, dict) else {}

        legacy_creator_toggle = data.get("fav_packs_view_by_creator", False)
        state.fav_packs_view_toggle = data.get("fav_packs_view_toggle", 1 if legacy_creator_toggle else 0)

        legacy_grp_toggle = data.get("grouped_view_by_creator", False)
        state.grouped_view_toggle = data.get("grouped_view_toggle", 1 if legacy_grp_toggle else 0)

        state.fav_poses_view_toggle = data.get("fav_poses_view_toggle", 0)
        state.filter_blank_poses = True
        state.restore_last_view_on_open = data.get("restore_last_view_on_open", False)
        state.auto_apply_linked_requirements = data.get("auto_apply_linked_requirements", True)
        state.auto_destroy_linked_objects = data.get("auto_destroy_linked_objects", True)
        state.replace_linked_objects_on_replay = data.get("replace_linked_objects_on_replay", True)
        state.restore_linked_requirements_when_pose_chain_finished = data.get("restore_linked_requirements_when_pose_chain_finished", False)
        raw_linked_object_variant_choices = data.get("linked_object_variant_choices", {})
        state.linked_object_variant_choices = raw_linked_object_variant_choices if isinstance(raw_linked_object_variant_choices, dict) else {}
        raw_linked_object_enabled_choices = data.get("linked_object_enabled_choices", {})
        state.linked_object_enabled_choices = raw_linked_object_enabled_choices if isinstance(raw_linked_object_enabled_choices, dict) else {}
        raw_linked_object_spawn_disabled = data.get("linked_object_spawn_disabled", {})
        state.linked_object_spawn_disabled = raw_linked_object_spawn_disabled if isinstance(raw_linked_object_spawn_disabled, dict) else {}
        raw_linked_cas_enabled_choices = data.get("linked_cas_enabled_choices", {})
        state.linked_cas_enabled_choices = raw_linked_cas_enabled_choices if isinstance(raw_linked_cas_enabled_choices, dict) else {}
        raw_linked_cas_apply_disabled = data.get("linked_cas_apply_disabled", {})
        state.linked_cas_apply_disabled = raw_linked_cas_apply_disabled if isinstance(raw_linked_cas_apply_disabled, dict) else {}
        raw_linked_cas_restore_before_apply = data.get("linked_cas_restore_before_apply", {})
        state.linked_cas_restore_before_apply = raw_linked_cas_restore_before_apply if isinstance(raw_linked_cas_restore_before_apply, dict) else {}
        raw_linked_object_hidden_choices = data.get("linked_object_hidden_choices", {})
        state.linked_object_hidden_choices = raw_linked_object_hidden_choices if isinstance(raw_linked_object_hidden_choices, dict) else {}
        
        raw_custom_names = data.get("custom_names", {})
        state.custom_names = raw_custom_names if isinstance(raw_custom_names, dict) else {}
        return

    migrated = False
    if os.path.exists(FAV_FILE):
        try:
            with open(FAV_FILE, 'r', encoding='utf-8') as f: state.favorite_poses = list(dict.fromkeys(json.load(f)))
            migrated = True
        except: pass
    if os.path.exists(FAV_CREATORS_FILE):
        try:
            with open(FAV_CREATORS_FILE, 'r', encoding='utf-8') as f: state.favorite_creators = list(dict.fromkeys(json.load(f)))
            migrated = True
        except: pass
    if os.path.exists(FAV_PACKS_FILE):
        try:
            with open(FAV_PACKS_FILE, 'r', encoding='utf-8') as f: state.favorite_packs = list(dict.fromkeys(json.load(f)))
            migrated = True
        except: pass
        
    if migrated:
        save_favorites()


def save_favorites():
    try:
        data = {
            "fav_poses": state.favorite_poses,
            "fav_creators": state.favorite_creators,
            "fav_packs": state.favorite_packs,
            "grouped_packs": state.grouped_packs,
            "user_fav_groups": state.user_fav_groups,
            "user_fav_pose_groups": state.user_fav_pose_groups,
            "user_grouped_packs_groups": state.user_grouped_packs_groups, 
            "linked_groups": state.linked_groups,
            "fav_packs_view_toggle": state.fav_packs_view_toggle,
            "grouped_view_toggle": state.grouped_view_toggle,
            "custom_names": state.custom_names,
            "fav_poses_view_toggle": state.fav_poses_view_toggle,
            "restore_last_view_on_open": state.restore_last_view_on_open,
            "auto_apply_linked_requirements": state.auto_apply_linked_requirements,
            "auto_destroy_linked_objects": state.auto_destroy_linked_objects,
            "replace_linked_objects_on_replay": state.replace_linked_objects_on_replay,
            "restore_linked_requirements_when_pose_chain_finished": getattr(state, "restore_linked_requirements_when_pose_chain_finished", False),
            "linked_object_variant_choices": state.linked_object_variant_choices,
            "linked_object_enabled_choices": state.linked_object_enabled_choices,
            "linked_object_spawn_disabled": state.linked_object_spawn_disabled,
            "linked_cas_enabled_choices": state.linked_cas_enabled_choices,
            "linked_cas_apply_disabled": state.linked_cas_apply_disabled,
            "linked_cas_restore_before_apply": getattr(state, "linked_cas_restore_before_apply", {}),
            "linked_object_hidden_choices": getattr(state, "linked_object_hidden_choices", {})
        }
        with open(USER_DATA_TMP, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
            
        if os.path.exists(USER_DATA_FILE):
            if os.path.exists(USER_DATA_BAK):
                os.remove(USER_DATA_BAK)
            elif os.path.exists(USER_DATA_BAK_LEGACY):
                os.remove(USER_DATA_BAK_LEGACY)
            os.rename(USER_DATA_FILE, USER_DATA_BAK)
            
        os.rename(USER_DATA_TMP, USER_DATA_FILE)
    except:
        pass


def auto_sort_couple_pack(pack):
    result = {"组 1": [], "组 2": []}
    try:
        pose_list = getattr(pack, 'pose_list', [])
        for idx, pose in enumerate(pose_list):
            p_name = getattr(pose, 'pose_name', None)
            if p_name:
                if idx % 2 == 0: result["组 1"].append(p_name)
                else: result["组 2"].append(p_name)
    except: pass
    return result


def get_pack_type(pack):
    if not pack: return 'NORMAL'
    combined_str = str(pack).lower() if isinstance(pack, str) else str(getattr(pack, '__name__', '')).lower()

    if 'fgeh_linked_actions' in combined_str: return 'LINKED_ACTIONS'
    if 'hegfcreator' in combined_str: return 'CREATORS'
    if 'fgeh_poses' in combined_str: return 'POSES'
    if 'fgeh_fav_packs' in combined_str: return 'FAV_PACKS'
    if 'fgeh_grouped' in combined_str: return 'GROUPED_PACKS'
    if 'fgeh_global_settings' in combined_str: return 'GLOBAL_SETTINGS'
    return 'NORMAL'


def build_cache_safe():
    if state.cache_built: return
    try:
        manager = services.get_instance_manager(sims4.resources.Types.SNIPPET)
        if manager is None: return
        temp_pose_cache, temp_creator_cache, temp_pack_cache = {}, {}, {}
        for _, pack in manager._tuned_classes.items():
            if hasattr(pack, 's4s_mod_type') and str(pack.s4s_mod_type).upper() == 'POSE_PACK':
                pack_id = str(getattr(pack, '__name__', 'Unknown'))
                temp_pack_cache[pack_id] = pack
                creator = ""
                for pose in getattr(pack, 'pose_list', []):
                    pose_name = getattr(pose, 'pose_name', None)
                    if pose_name and ':' in str(pose_name).strip():
                        creator = str(pose_name).strip().split(':')[0].strip()
                        break
                if not creator or creator.lower() == 'unknown':
                    creator_obj = getattr(pack, 'creator_name', None)
                    creator = str(creator_obj).strip() if creator_obj else 'Unknown'

                if creator not in temp_creator_cache: temp_creator_cache[creator] = []
                temp_creator_cache[creator].append(pack)

                for pose in getattr(pack, 'pose_list', []):
                    p_name = getattr(pose, 'pose_name', None)
                    if p_name: temp_pose_cache[p_name] = {'pose': pose, 'pack_name': creator, 'pack_ref': pack}

        state.all_poses_cache, state.all_creators_cache, state.all_packs_cache = temp_pose_cache, temp_creator_cache, temp_pack_cache
        state.cache_built = True
    except: state.cache_built = True


def get_linked_action_source_entries():
    if not state.cache_built:
        build_cache_safe()

    try:
        from fgeh_cas_accessory_picker import (
            build_accessory_entries,
            get_accessory_snippets_for_pose_pack,
        )
    except:
        return []

    results = []
    for pack_id, pack in (getattr(state, 'all_packs_cache', {}) or {}).items():
        snippets = get_accessory_snippets_for_pose_pack(pack)
        if not snippets:
            continue

        entries = build_accessory_entries(snippets)
        if not entries:
            continue

        for entry_info in entries:
            category = str(entry_info.get('category') or '').strip() or 'uncategorized'
            results.append({
                'category': category,
                'pack_id': pack_id,
                'pack': pack,
                'entry_info': entry_info,
            })

    return results


def linked_entry_pose_names(entry_info):
    entry = entry_info.get('entry') if isinstance(entry_info, dict) else None
    raw_pose_names = getattr(entry, 'pose_names', None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, 'poses', None)
    if not raw_pose_names:
        raw_pose_names = getattr(entry, 'pose_name', None)

    if raw_pose_names is None:
        return []
    if isinstance(raw_pose_names, str):
        raw_pose_names = [raw_pose_names]

    result = []
    try:
        iterator = list(raw_pose_names)
    except:
        iterator = []

    for pose_name in iterator:
        pose_name = str(pose_name or '').strip()
        if pose_name:
            result.append(pose_name)

    return result


def iter_linked_entry_pose_items(pack, entry_info):
    allowed_pose_names = set(linked_entry_pose_names(entry_info))

    for pose_item in getattr(pack, 'pose_list', []) or []:
        pose_name = getattr(pose_item, 'pose_name', None)
        if not pose_name or should_hide_pose_entry(pose_item):
            continue
        if allowed_pose_names and pose_name not in allowed_pose_names:
            continue
        yield pose_item


def count_linked_entry_pose_items(pack, entry_info):
    return sum(1 for _ in iter_linked_entry_pose_items(pack, entry_info))


def get_linked_action_categories():
    categories = {}
    for source in get_linked_action_source_entries():
        category = source.get('category') or 'uncategorized'
        pack = source.get('pack')
        current = categories.setdefault(category, {'category': category, 'pose_keys': set(), 'pose_count': 0})
        pack_id = source.get('pack_id')
        for pose_item in iter_linked_entry_pose_items(pack, source.get('entry_info') or {}):
            pose_name = getattr(pose_item, 'pose_name', None)
            pose_key = (pack_id, pose_name)
            if pose_name and pose_key not in current['pose_keys']:
                current['pose_keys'].add(pose_key)
                current['pose_count'] += 1

    return sorted(categories.values(), key=lambda item: str(item.get('category', '')).lower())


def linked_category_display_name(category):
    text = str(category or '').strip()
    if not text:
        return '未分类'
    display_map = {
        'accessory': '配饰',
        'accessories': '配饰',
        'clothing': '衣服',
        'clothes': '衣服',
        'outfit': '衣服',
        'uncategorized': '未分类',
    }
    return display_map.get(text.lower(), text)


def linked_action_tag(category, pack_id, pose_name):
    try:
        return LINKED_ACTIONS_POSE_PREFIX + json.dumps([category, pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_ACTIONS_POSE_PREFIX + str(category) + "::" + str(pack_id) + "::" + str(pose_name)


def parse_linked_action_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_ACTIONS_POSE_PREFIX):]
    try:
        category, pack_id, pose_name = json.loads(raw_value)
        return str(category), str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
    return None, None, None


def iter_linked_action_pose_rows(category_filter):
    category_filter = str(category_filter or '').strip()
    seen = set()

    for source in get_linked_action_source_entries():
        category = str(source.get('category') or '').strip() or 'uncategorized'
        if category != category_filter:
            continue

        pack = source.get('pack')
        pack_id = source.get('pack_id')
        if not pack:
            continue

        for pose_item in iter_linked_entry_pose_items(pack, source.get('entry_info') or {}):
            pose_name = getattr(pose_item, 'pose_name', None)
            if not pose_name:
                continue

            signature = (pack_id, pose_name)
            if signature in seen:
                continue
            seen.add(signature)

            yield pack, pack_id, pose_item


def get_linked_group_type_title(group_type):
    if group_type == LINKED_ALL_GROUP_TYPE:
        return "全部联动动作"
    if group_type == "object":
        return "物体生成联动"
    return "CAS / 配饰联动"


def get_linked_group_type_desc(group_type):
    if group_type == LINKED_ALL_GROUP_TYPE:
        return "浏览所有带 CAS、配饰或物体生成的动作"
    if group_type == "object":
        return "生成或绑定世界里的物体，包含原版和 CC 物体"
    return "更换小人身上的 CAS 部件，包含原版和 CC 配件"


def get_registry_group_type(group_type):
    return None if group_type == LINKED_ALL_GROUP_TYPE else group_type


def ensure_linked_groups_container(group_type):
    if not isinstance(getattr(state, "linked_groups", None), dict):
        state.linked_groups = {}
    if group_type not in state.linked_groups or not isinstance(state.linked_groups.get(group_type), dict):
        state.linked_groups[group_type] = {}
    return state.linked_groups[group_type]


def linked_pose_ref(pack_id, pose_name):
    return {"pack_id": str(pack_id or ""), "pose_name": str(pose_name or "")}


def linked_pose_ref_key(ref):
    if isinstance(ref, dict):
        return (str(ref.get("pack_id", "")), str(ref.get("pose_name", "")))
    if isinstance(ref, (list, tuple)) and len(ref) >= 2:
        return (str(ref[0]), str(ref[1]))
    return ("", "")


def append_linked_group_ref(group_type, group_name, pack_id, pose_name):
    groups = ensure_linked_groups_container(group_type)
    refs = groups.setdefault(group_name, [])
    key = (str(pack_id or ""), str(pose_name or ""))
    existing = set(linked_pose_ref_key(ref) for ref in refs)
    if key[0] and key[1] and key not in existing:
        refs.append(linked_pose_ref(key[0], key[1]))
        return True
    return False


def get_all_linked_grouped_ref_keys(group_type):
    groups = ensure_linked_groups_container(group_type)
    keys = set()
    for refs in groups.values():
        for ref in refs or []:
            key = linked_pose_ref_key(ref)
            if key[0] and key[1]:
                keys.add(key)
    return keys


def get_linked_registry_pose_keys(group_type):
    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs
    except:
        return get_saved_linked_pose_keys(group_type)

    keys = set()
    for ref in iter_linked_pose_refs(getattr(state, "all_packs_cache", {}), group_type=get_registry_group_type(group_type)):
        key = linked_pose_ref_key(ref)
        if key[0] and key[1]:
            keys.add(key)
    keys.update(get_saved_linked_pose_keys(group_type))
    return keys


def get_saved_linked_pose_keys(group_type):
    keys = set()

    def add_choice_keys(mapping):
        if not isinstance(mapping, dict):
            return
        for raw_key in mapping.keys():
            parts = str(raw_key or "").split("::", 1)
            if len(parts) != 2:
                continue
            pack_id, pose_name = parts
            if pack_id and pose_name:
                keys.add((pack_id, pose_name))

    if group_type in (LINKED_ALL_GROUP_TYPE, "cas"):
        add_choice_keys(getattr(state, "linked_cas_enabled_choices", {}) or {})
        add_choice_keys(getattr(state, "linked_cas_apply_disabled", {}) or {})
        add_choice_keys(getattr(state, "linked_cas_restore_before_apply", {}) or {})
    if group_type in (LINKED_ALL_GROUP_TYPE, "object"):
        add_choice_keys(getattr(state, "linked_object_enabled_choices", {}) or {})
        add_choice_keys(getattr(state, "linked_object_variant_choices", {}) or {})
        add_choice_keys(getattr(state, "linked_object_spawn_disabled", {}) or {})

    return keys


def count_linked_poses_in_grouped_pack(pack_id, group_map, linked_keys):
    count = 0
    pack_id = str(pack_id or "")
    if not isinstance(group_map, dict):
        return 0
    for pose_names in group_map.values():
        for pose_name in pose_names or []:
            if (pack_id, str(pose_name or "")) in linked_keys:
                count += 1
    return count


def get_linked_grouped_outer_refs(group_type):
    linked_keys = get_linked_registry_pose_keys(group_type)
    results = []
    grouped_packs = getattr(state, "grouped_packs", {}) or {}
    outer_groups = getattr(state, "user_grouped_packs_groups", {}) or {}

    for outer_name in sorted(outer_groups.keys(), key=lambda value: str(value).lower()):
        pack_ids = outer_groups.get(outer_name, []) or []
        pack_count = 0
        pose_count = 0
        for pack_id in pack_ids:
            group_map = grouped_packs.get(str(pack_id or ""))
            linked_count = count_linked_poses_in_grouped_pack(pack_id, group_map, linked_keys)
            if linked_count:
                pack_count += 1
                pose_count += linked_count
        if pose_count:
            results.append({
                "outer_name": str(outer_name),
                "pack_count": pack_count,
                "pose_count": pose_count,
            })
    return results


def get_linked_grouped_pack_refs(group_type, outer_name):
    linked_keys = get_linked_registry_pose_keys(group_type)
    grouped_packs = getattr(state, "grouped_packs", {}) or {}
    pack_ids = (getattr(state, "user_grouped_packs_groups", {}) or {}).get(outer_name, []) or []
    refs = []
    for pack_id in pack_ids:
        pack_id = str(pack_id or "")
        pack = (getattr(state, "all_packs_cache", {}) or {}).get(pack_id)
        if not pack:
            continue
        linked_count = count_linked_poses_in_grouped_pack(pack_id, grouped_packs.get(pack_id), linked_keys)
        if linked_count:
            refs.append({
                "pack_id": pack_id,
                "pack": pack,
                "pose_count": linked_count,
            })
    return refs


def get_linked_grouped_pose_group_refs(group_type, pack_id):
    linked_keys = get_linked_registry_pose_keys(group_type)
    pack_id = str(pack_id or "")
    group_map = (getattr(state, "grouped_packs", {}) or {}).get(pack_id, {}) or {}
    refs = []
    for group_name in sorted(group_map.keys(), key=lambda value: str(value).lower()):
        pose_names = group_map.get(group_name, []) or []
        linked_pose_names = [
            str(pose_name or "")
            for pose_name in pose_names
            if (pack_id, str(pose_name or "")) in linked_keys
        ]
        if linked_pose_names:
            refs.append({
                "group_name": str(group_name),
                "pose_count": len(linked_pose_names),
            })
    return refs


def get_linked_grouped_pose_refs(group_type, pack_id, pose_group_name):
    linked_keys = get_linked_registry_pose_keys(group_type)
    pack_id = str(pack_id or "")
    group_map = (getattr(state, "grouped_packs", {}) or {}).get(pack_id, {}) or {}
    refs = []
    for pose_name in group_map.get(pose_group_name, []) or []:
        pose_name = str(pose_name or "")
        if (pack_id, pose_name) in linked_keys:
            refs.append(linked_pose_ref(pack_id, pose_name))
    refs.sort(key=lambda ref: get_pose_ref_sort_key(ref))
    return refs


def get_pose_ref_sort_key(ref):
    pack_id, pose_name = linked_pose_ref_key(ref)
    pack = (getattr(state, "all_packs_cache", {}) or {}).get(pack_id)
    try:
        for index, pose_item in enumerate(getattr(pack, "pose_list", []) or []):
            if str(getattr(pose_item, "pose_name", "") or "") == pose_name:
                return (0, index, pose_name)
    except Exception:
        pass

    marker = "_set_"
    if marker in pose_name:
        try:
            return (1, int(pose_name.rsplit(marker, 1)[1]), pose_name)
        except Exception:
            pass
    return (2, pose_name)


def get_linked_group_refs(group_type, group_name):
    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs
    except:
        return []

    registry_group_type = get_registry_group_type(group_type)
    if group_name == LINKED_ALL_GROUP_NAME:
        refs = []
        for ref in iter_linked_pose_refs(getattr(state, "all_packs_cache", {}), group_type=registry_group_type):
            key = linked_pose_ref_key(ref)
            if key[0] and key[1]:
                refs.append(linked_pose_ref(key[0], key[1]))
        return refs

    if group_name == LINKED_UNGROUPED_GROUP_NAME:
        grouped_keys = get_all_linked_grouped_ref_keys(group_type)
        refs = []
        for ref in iter_linked_pose_refs(getattr(state, "all_packs_cache", {}), group_type=registry_group_type):
            key = linked_pose_ref_key(ref)
            if key[0] and key[1] and key not in grouped_keys:
                refs.append(linked_pose_ref(key[0], key[1]))
        return refs

    return list(ensure_linked_groups_container(group_type).get(group_name, []) or [])


def get_linked_group_pack_refs(group_type, group_name):
    if group_name in (LINKED_ALL_GROUP_NAME, LINKED_UNGROUPED_GROUP_NAME):
        try:
            from fgeh_pose_requirement_registry import iter_linked_pack_refs
        except:
            return []

        refs = []
        registry_group_type = get_registry_group_type(group_type)
        for ref in iter_linked_pack_refs(getattr(state, "all_packs_cache", {}), group_type=registry_group_type):
            pack_id = str(ref.get("pack_id") or "")
            if not pack_id:
                continue
            pose_refs = get_linked_pack_pose_refs(group_type, group_name, pack_id)
            if not pose_refs:
                continue
            fixed_ref = dict(ref)
            fixed_ref["pose_count"] = len(pose_refs)
            refs.append(fixed_ref)
        return refs

    pack_refs = {}
    for ref in get_linked_group_refs(group_type, group_name):
        pack_id, pose_name = linked_pose_ref_key(ref)
        if not pack_id or not pose_name:
            continue
        current = pack_refs.setdefault(pack_id, {
            "group_type": group_type,
            "pack_id": pack_id,
            "pack": state.all_packs_cache.get(pack_id),
            "pose_count": 0,
        })
        current["pose_count"] += 1
    return sorted(pack_refs.values(), key=lambda item: str(item.get("pack_id", "")).lower())


def get_linked_pack_pose_refs(group_type, group_name, pack_id):
    pack_id = str(pack_id or "")
    if not pack_id:
        return []

    if group_name in (LINKED_ALL_GROUP_NAME, LINKED_UNGROUPED_GROUP_NAME):
        try:
            from fgeh_pose_requirement_registry import iter_linked_pose_refs_for_pack
        except:
            return []

        grouped_keys = get_all_linked_grouped_ref_keys(group_type)
        refs = []
        registry_group_type = get_registry_group_type(group_type)
        for ref in iter_linked_pose_refs_for_pack(getattr(state, "all_packs_cache", {}), pack_id, group_type=registry_group_type):
            key = linked_pose_ref_key(ref)
            if key[0] == pack_id and key[1] and (group_name == LINKED_ALL_GROUP_NAME or key not in grouped_keys):
                refs.append(linked_pose_ref(key[0], key[1]))
        return refs

    return [
        linked_pose_ref(pack_key, pose_name)
        for pack_key, pose_name in (linked_pose_ref_key(ref) for ref in get_linked_group_refs(group_type, group_name))
        if pack_key == pack_id and pose_name
    ]


def linked_pack_tag(group_type, pack_id):
    try:
        return LINKED_PACK_PREFIX + json.dumps([group_type, pack_id], ensure_ascii=False)
    except:
        return LINKED_PACK_PREFIX + str(group_type) + "::" + str(pack_id)


def parse_linked_pack_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_PACK_PREFIX):]
    try:
        group_type, pack_id = json.loads(raw_value)
        return str(group_type), str(pack_id)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_grouped_outer_tag(outer_name):
    try:
        return LINKED_GROUPED_OUTER_PREFIX + json.dumps([outer_name], ensure_ascii=False)
    except:
        return LINKED_GROUPED_OUTER_PREFIX + str(outer_name)


def parse_linked_grouped_outer_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_GROUPED_OUTER_PREFIX):]
    try:
        values = json.loads(raw_value)
        if values:
            return str(values[0])
    except:
        pass
    return str(raw_value or "")


def linked_grouped_pack_tag(pack_id):
    try:
        return LINKED_GROUPED_PACK_PREFIX + json.dumps([pack_id], ensure_ascii=False)
    except:
        return LINKED_GROUPED_PACK_PREFIX + str(pack_id)


def parse_linked_grouped_pack_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_GROUPED_PACK_PREFIX):]
    try:
        values = json.loads(raw_value)
        if values:
            return str(values[0])
    except:
        pass
    return str(raw_value or "")


def linked_grouped_pose_group_tag(group_name):
    try:
        return LINKED_GROUPED_POSE_GROUP_PREFIX + json.dumps([group_name], ensure_ascii=False)
    except:
        return LINKED_GROUPED_POSE_GROUP_PREFIX + str(group_name)


def parse_linked_grouped_pose_group_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_GROUPED_POSE_GROUP_PREFIX):]
    try:
        values = json.loads(raw_value)
        if values:
            return str(values[0])
    except:
        pass
    return str(raw_value or "")


def linked_assign_group_tag(group_name):
    try:
        return LINKED_ASSIGN_GROUP_PREFIX + json.dumps([group_name], ensure_ascii=False)
    except:
        return LINKED_ASSIGN_GROUP_PREFIX + str(group_name)


def parse_linked_assign_group_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_ASSIGN_GROUP_PREFIX):]
    try:
        values = json.loads(raw_value)
        if values:
            return str(values[0])
    except:
        pass
    return str(raw_value or "")


def linked_group_action_tag(prefix, group_name):
    try:
        return prefix + json.dumps([group_name], ensure_ascii=False)
    except:
        return prefix + str(group_name)


def parse_linked_group_action_tag(choice_tag, prefix):
    raw_value = choice_tag[len(prefix):]
    try:
        values = json.loads(raw_value)
        if values:
            return str(values[0])
    except:
        pass
    return str(raw_value or "")


def linked_object_choice_key(pack_id, pose_name):
    return str(pack_id or "") + "::" + str(pose_name or "")


def get_selected_linked_object_definition_id(pack_id, pose_name):
    choices = getattr(state, "linked_object_variant_choices", {}) or {}
    try:
        return int(choices.get(linked_object_choice_key(pack_id, pose_name), 0) or 0)
    except:
        return 0


def set_selected_linked_object_definition_id(pack_id, pose_name, definition_id):
    if not isinstance(getattr(state, "linked_object_variant_choices", None), dict):
        state.linked_object_variant_choices = {}
    key = linked_object_choice_key(pack_id, pose_name)
    definition_id = int(definition_id or 0)
    if definition_id:
        state.linked_object_variant_choices[key] = definition_id
    else:
        state.linked_object_variant_choices.pop(key, None)
    save_favorites()


def is_linked_object_spawn_enabled(pack_id, pose_name):
    disabled = getattr(state, "linked_object_spawn_disabled", {}) or {}
    return not bool(disabled.get(linked_object_choice_key(pack_id, pose_name), False))


def set_linked_object_spawn_enabled(pack_id, pose_name, enabled):
    if not isinstance(getattr(state, "linked_object_spawn_disabled", None), dict):
        state.linked_object_spawn_disabled = {}
    key = linked_object_choice_key(pack_id, pose_name)
    if enabled:
        state.linked_object_spawn_disabled.pop(key, None)
    else:
        state.linked_object_spawn_disabled[key] = True
    save_favorites()


def is_linked_cas_restore_before_apply_enabled(pack_id, pose_name):
    restore_map = getattr(state, "linked_cas_restore_before_apply", {}) or {}
    return bool(restore_map.get(linked_object_choice_key(pack_id, pose_name), False))


def set_linked_cas_restore_before_apply_enabled(pack_id, pose_name, enabled):
    if not isinstance(getattr(state, "linked_cas_restore_before_apply", None), dict):
        state.linked_cas_restore_before_apply = {}
    key = linked_object_choice_key(pack_id, pose_name)
    if enabled:
        state.linked_cas_restore_before_apply[key] = True
    else:
        state.linked_cas_restore_before_apply.pop(key, None)
    save_favorites()


def get_hidden_linked_object_definition_ids(pack_id, pose_name):
    hidden_map = getattr(state, "linked_object_hidden_choices", {}) or {}
    raw_values = hidden_map.get(linked_object_choice_key(pack_id, pose_name), []) or []
    hidden_ids = set()
    for value in raw_values:
        try:
            value = int(value or 0)
        except:
            value = 0
        if value:
            hidden_ids.add(value)
    return hidden_ids


def hide_linked_object_definition_id(pack_id, pose_name, definition_id):
    definition_id = int(definition_id or 0)
    if not definition_id:
        return
    if not isinstance(getattr(state, "linked_object_hidden_choices", None), dict):
        state.linked_object_hidden_choices = {}
    key = linked_object_choice_key(pack_id, pose_name)
    hidden_ids = get_hidden_linked_object_definition_ids(pack_id, pose_name)
    hidden_ids.add(definition_id)
    state.linked_object_hidden_choices[key] = sorted(hidden_ids)

    if isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
        current = []
        for value in state.linked_object_enabled_choices.get(key, []) or []:
            try:
                value = int(value or 0)
            except:
                value = 0
            if value and value != definition_id:
                current.append(value)
        if current:
            state.linked_object_enabled_choices[key] = current
        else:
            state.linked_object_enabled_choices.pop(key, None)
    if get_selected_linked_object_definition_id(pack_id, pose_name) == definition_id:
        set_selected_linked_object_definition_id(pack_id, pose_name, 0)
    else:
        save_favorites()


def clear_hidden_linked_object_definition_ids(pack_id, pose_name):
    if not isinstance(getattr(state, "linked_object_hidden_choices", None), dict):
        state.linked_object_hidden_choices = {}
    key = linked_object_choice_key(pack_id, pose_name)
    if key in state.linked_object_hidden_choices:
        state.linked_object_hidden_choices.pop(key, None)
        save_favorites()


def get_enabled_linked_object_definition_ids(pack_id, pose_name, available_ids=None):
    if not is_linked_object_spawn_enabled(pack_id, pose_name):
        return []

    normalized_available_ids = None
    if available_ids is not None:
        normalized_available_ids = []
        for value in available_ids or []:
            try:
                value = int(value or 0)
            except:
                value = 0
            if value and value not in normalized_available_ids:
                normalized_available_ids.append(value)

    key = linked_object_choice_key(pack_id, pose_name)
    enabled_choices = getattr(state, "linked_object_enabled_choices", {}) or {}
    if key in enabled_choices:
        selected = []
        try:
            for value in enabled_choices.get(key, []) or []:
                value = int(value or 0)
                if value and (normalized_available_ids is None or value in normalized_available_ids):
                    selected.append(value)
            return selected
        except:
            return []

    legacy_definition_id = get_selected_linked_object_definition_id(pack_id, pose_name)
    if legacy_definition_id:
        if normalized_available_ids is not None and legacy_definition_id not in normalized_available_ids:
            return []
        return [legacy_definition_id]

    if normalized_available_ids is not None:
        try:
            from fgeh_linked_object_bindings import get_saved_object_ids_for_pose
        except:
            return list(normalized_available_ids)

        try:
            local_asset_ids, local_pose_binding_ids = get_saved_object_ids_for_pose(pack_id, pose_name)
        except:
            local_asset_ids, local_pose_binding_ids = set(), set()

        selected = []
        for definition_id in normalized_available_ids:
            if definition_id not in local_asset_ids:
                selected.append(definition_id)
                continue
            if definition_id in local_pose_binding_ids:
                selected.append(definition_id)
        return selected

    return None


def set_enabled_linked_object_definition_ids(pack_id, pose_name, definition_ids):
    if not isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
        state.linked_object_enabled_choices = {}
    key = linked_object_choice_key(pack_id, pose_name)
    cleaned = []
    for definition_id in definition_ids or []:
        try:
            definition_id = int(definition_id or 0)
        except:
            definition_id = 0
        if definition_id and definition_id not in cleaned:
            cleaned.append(definition_id)
    state.linked_object_enabled_choices[key] = cleaned
    state.linked_object_variant_choices.pop(key, None)
    save_favorites()


def toggle_linked_object_definition_id(pack_id, pose_name, definition_id, available_ids):
    definition_id = int(definition_id or 0)
    available_ids = [int(value) for value in (available_ids or []) if int(value or 0)]
    current = get_enabled_linked_object_definition_ids(pack_id, pose_name, available_ids)
    if current is None:
        current = list(available_ids)
    if definition_id in current:
        current = [value for value in current if value != definition_id]
    elif definition_id:
        current.append(definition_id)
    set_enabled_linked_object_definition_ids(pack_id, pose_name, current)


def linked_object_spawn_toggle_tag(pack_id, pose_name):
    try:
        return LINKED_OBJECT_SPAWN_TOGGLE_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_OBJECT_SPAWN_TOGGLE_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_object_spawn_toggle_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_OBJECT_SPAWN_TOGGLE_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_object_apply_pack_tag(pack_id, pose_name):
    try:
        return LINKED_OBJECT_APPLY_PACK_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_OBJECT_APPLY_PACK_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_object_apply_pack_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_OBJECT_APPLY_PACK_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def apply_linked_object_selection_to_refs(pack_id, source_pose_name, refs, save_changes=True):
    pack_id = str(pack_id or "")
    source_pose_name = str(source_pose_name or "")
    if not pack_id or not source_pose_name:
        return 0

    source_key = linked_object_choice_key(pack_id, source_pose_name)
    source_enabled = is_linked_object_spawn_enabled(pack_id, source_pose_name)
    source_enabled_choices = getattr(state, "linked_object_enabled_choices", {}) or {}
    source_has_enabled_list = source_key in source_enabled_choices
    source_enabled_list = list(source_enabled_choices.get(source_key, []) or [])
    source_legacy_definition_id = get_selected_linked_object_definition_id(pack_id, source_pose_name)

    if not isinstance(getattr(state, "linked_object_spawn_disabled", None), dict):
        state.linked_object_spawn_disabled = {}
    if not isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
        state.linked_object_enabled_choices = {}
    if not isinstance(getattr(state, "linked_object_variant_choices", None), dict):
        state.linked_object_variant_choices = {}

    changed = 0
    for ref in refs:
        ref_pack_id, pose_name = linked_pose_ref_key(ref)
        if ref_pack_id != pack_id or not pose_name:
            continue
        key = linked_object_choice_key(pack_id, pose_name)
        if source_enabled:
            state.linked_object_spawn_disabled.pop(key, None)
        else:
            state.linked_object_spawn_disabled[key] = True

        if source_has_enabled_list:
            state.linked_object_enabled_choices[key] = list(source_enabled_list)
            state.linked_object_variant_choices.pop(key, None)
        elif source_legacy_definition_id:
            state.linked_object_variant_choices[key] = source_legacy_definition_id
            state.linked_object_enabled_choices.pop(key, None)
        else:
            state.linked_object_enabled_choices.pop(key, None)
            state.linked_object_variant_choices.pop(key, None)
        changed += 1

    if changed and save_changes:
        save_favorites()
    return changed


def apply_linked_object_selection_to_pack(pack_id, source_pose_name):
    pack_id = str(pack_id or "")
    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs_for_pack
        refs = list(iter_linked_pose_refs_for_pack(getattr(state, "all_packs_cache", {}), pack_id, group_type="object"))
    except:
        refs = get_linked_pack_pose_refs("object", LINKED_UNGROUPED_GROUP_NAME, pack_id)
    return apply_linked_object_selection_to_refs(pack_id, source_pose_name, refs)


def linked_object_style_pose_tag(pack_id, pose_name):
    try:
        return LINKED_OBJECT_STYLE_POSE_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_OBJECT_STYLE_POSE_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_object_style_pose_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_OBJECT_STYLE_POSE_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_object_style_variant_tag(pack_id, pose_name, definition_id):
    try:
        return LINKED_OBJECT_STYLE_VARIANT_PREFIX + json.dumps([pack_id, pose_name, int(definition_id or 0)], ensure_ascii=False)
    except:
        return LINKED_OBJECT_STYLE_VARIANT_PREFIX + str(pack_id) + "::" + str(pose_name) + "::" + str(definition_id or 0)


def parse_linked_object_style_variant_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_OBJECT_STYLE_VARIANT_PREFIX):]
    try:
        pack_id, pose_name, definition_id = json.loads(raw_value)
        return str(pack_id), str(pose_name), int(definition_id or 0)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            try:
                return parts[0], parts[1], int(parts[2] or 0)
            except:
                pass
    return None, None, 0


def linked_setting_auto_toggle_tag(link_type, pack_id, pose_name):
    try:
        return LINKED_SETTING_AUTO_TOGGLE_PREFIX + json.dumps([link_type, pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_SETTING_AUTO_TOGGLE_PREFIX + str(link_type) + "::" + str(pack_id) + "::" + str(pose_name)


def parse_linked_setting_auto_toggle_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_AUTO_TOGGLE_PREFIX):]
    try:
        link_type, pack_id, pose_name = json.loads(raw_value)
        return str(link_type), str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
    return "", None, None


def linked_setting_enable_all_tag(link_type, pack_id, pose_name):
    try:
        return LINKED_SETTING_ENABLE_ALL_PREFIX + json.dumps([link_type, pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_SETTING_ENABLE_ALL_PREFIX + str(link_type) + "::" + str(pack_id) + "::" + str(pose_name)


def parse_linked_setting_enable_all_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_ENABLE_ALL_PREFIX):]
    try:
        link_type, pack_id, pose_name = json.loads(raw_value)
        return str(link_type), str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
    return "", None, None


def linked_setting_item_toggle_tag(link_type, pack_id, pose_name, item_id):
    try:
        return LINKED_SETTING_ITEM_TOGGLE_PREFIX + json.dumps([link_type, pack_id, pose_name, int(item_id or 0)], ensure_ascii=False)
    except:
        return LINKED_SETTING_ITEM_TOGGLE_PREFIX + str(link_type) + "::" + str(pack_id) + "::" + str(pose_name) + "::" + str(item_id or 0)


def parse_linked_setting_item_toggle_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_ITEM_TOGGLE_PREFIX):]
    try:
        link_type, pack_id, pose_name, item_id = json.loads(raw_value)
        return str(link_type), str(pack_id), str(pose_name), int(item_id or 0)
    except:
        parts = raw_value.split("::", 3)
        if len(parts) == 4:
            try:
                return parts[0], parts[1], parts[2], int(parts[3] or 0)
            except:
                pass
    return "", None, None, 0


def linked_setting_apply_pack_tag(pack_id, pose_name):
    try:
        return LINKED_SETTING_APPLY_PACK_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_SETTING_APPLY_PACK_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_setting_apply_pack_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_APPLY_PACK_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_setting_set_pose_all_tag(pack_id, pose_name, enabled):
    try:
        return LINKED_SETTING_SET_POSE_ALL_PREFIX + json.dumps([pack_id, pose_name, bool(enabled)], ensure_ascii=False)
    except:
        return LINKED_SETTING_SET_POSE_ALL_PREFIX + str(pack_id) + "::" + str(pose_name) + "::" + ("1" if enabled else "0")


def parse_linked_setting_set_pose_all_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_SET_POSE_ALL_PREFIX):]
    try:
        pack_id, pose_name, enabled = json.loads(raw_value)
        return str(pack_id), str(pose_name), bool(enabled)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            return parts[0], parts[1], parts[2] == "1"
    return None, None, False


def linked_setting_restore_cas_tag(pack_id, pose_name):
    try:
        return LINKED_SETTING_RESTORE_CAS_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_SETTING_RESTORE_CAS_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_setting_restore_cas_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_RESTORE_CAS_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_setting_hide_object_tag(pack_id, pose_name, definition_id):
    try:
        return LINKED_SETTING_HIDE_OBJECT_PREFIX + json.dumps([pack_id, pose_name, int(definition_id or 0)], ensure_ascii=False)
    except:
        return LINKED_SETTING_HIDE_OBJECT_PREFIX + str(pack_id) + "::" + str(pose_name) + "::" + str(definition_id or 0)


def parse_linked_setting_hide_object_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_HIDE_OBJECT_PREFIX):]
    try:
        pack_id, pose_name, definition_id = json.loads(raw_value)
        return str(pack_id), str(pose_name), int(definition_id or 0)
    except:
        parts = raw_value.split("::", 2)
        if len(parts) == 3:
            try:
                return parts[0], parts[1], int(parts[2] or 0)
            except:
                return parts[0], parts[1], 0
    return None, None, 0


def linked_setting_clear_hidden_objects_tag(pack_id, pose_name):
    try:
        return LINKED_SETTING_CLEAR_HIDDEN_OBJECTS_PREFIX + json.dumps([pack_id, pose_name], ensure_ascii=False)
    except:
        return LINKED_SETTING_CLEAR_HIDDEN_OBJECTS_PREFIX + str(pack_id) + "::" + str(pose_name)


def parse_linked_setting_clear_hidden_objects_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_CLEAR_HIDDEN_OBJECTS_PREFIX):]
    try:
        pack_id, pose_name = json.loads(raw_value)
        return str(pack_id), str(pose_name)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return None, None


def linked_setting_folder_tag(link_type):
    return LINKED_SETTING_FOLDER_PREFIX + str(link_type or "")


def parse_linked_setting_folder_tag(choice_tag):
    return str(choice_tag[len(LINKED_SETTING_FOLDER_PREFIX):] or "")


def linked_setting_asset_folder_tag(link_type, asset_key):
    try:
        return LINKED_SETTING_ASSET_FOLDER_PREFIX + json.dumps([link_type, asset_key], ensure_ascii=False)
    except:
        return LINKED_SETTING_ASSET_FOLDER_PREFIX + str(link_type) + "::" + str(asset_key)


def parse_linked_setting_asset_folder_tag(choice_tag):
    raw_value = choice_tag[len(LINKED_SETTING_ASSET_FOLDER_PREFIX):]
    try:
        link_type, asset_key = json.loads(raw_value)
        return str(link_type), str(asset_key)
    except:
        parts = raw_value.split("::", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
    return "", ""


def is_linked_object_source_folder(folder_name):
    return str(folder_name or "") in ("object_local", "object_external")


def is_linked_requirement_asset_folder(folder_name):
    return str(folder_name or "") in ("cas", "object_local", "object_external")


def _linked_option_group_label(option, id_field):
    label = str(option.get("entry_label") or option.get("label") or "").strip()
    if not label:
        return "{} {}".format(id_field, option.get(id_field) or "")
    return label


def _linked_option_group_key(label, options, id_field):
    ids = []
    for option in options or []:
        try:
            item_id = int(option.get(id_field) or 0)
        except:
            item_id = 0
        if item_id and item_id not in ids:
            ids.append(item_id)
    return "{}::{}".format(label, ",".join(str(item_id) for item_id in sorted(ids)))


def group_linked_variant_options(options, id_field):
    grouped = []
    index_by_label = {}
    for option in options or []:
        label = _linked_option_group_label(option, id_field)
        index = index_by_label.get(label)
        if index is None:
            index = len(grouped)
            index_by_label[label] = index
            grouped.append({"label": label, "options": []})
        grouped[index]["options"].append(option)
    for group in grouped:
        group["key"] = _linked_option_group_key(group.get("label"), group.get("options"), id_field)
    return grouped


def find_linked_option_group(options, id_field, asset_key):
    for group in group_linked_variant_options(options, id_field):
        if group.get("key") == asset_key:
            return group
    return None


def first_linked_option_icon(options, *field_names):
    for option in options or []:
        for field_name in field_names:
            icon = option.get(field_name)
            if icon is not None:
                return icon
    return None


def get_linked_object_variant_options(pack_id, pose_name):
    try:
        from fgeh_linked_object_runtime import iter_linked_object_variant_options
    except:
        return []
    try:
        hidden_ids = get_hidden_linked_object_definition_ids(pack_id, pose_name)
        options = []
        for option in iter_linked_object_variant_options(getattr(state, "all_packs_cache", {}), pack_id, pose_name):
            try:
                definition_id = int(option.get("definition_id") or 0)
            except:
                definition_id = 0
            if definition_id and definition_id in hidden_ids:
                continue
            options.append(option)
        return options
    except:
        return []


def get_linked_object_selection_summary(pack_id, pose_name, options=None):
    if options is None:
        options = get_linked_object_variant_options(pack_id, pose_name)
    available_ids = [int(option.get("definition_id") or 0) for option in options if int(option.get("definition_id") or 0)]
    if not available_ids:
        return "没有可生成物体"
    if not is_linked_object_spawn_enabled(pack_id, pose_name):
        return "物体生成: 关"
    enabled_ids = get_enabled_linked_object_definition_ids(pack_id, pose_name, available_ids)
    if enabled_ids is None:
        return "物体生成: 全部 {} 个".format(len(available_ids))
    return "物体生成: 已选择 {} / {} 个".format(len(enabled_ids), len(available_ids))


def get_linked_cas_variant_options(pack_id, pose_name):
    pack = (getattr(state, "all_packs_cache", {}) or {}).get(pack_id)
    try:
        from fgeh_cas_accessory_picker import iter_matching_cas_variant_options
    except:
        return []
    try:
        return list(iter_matching_cas_variant_options(pose_name=pose_name, pose_pack=pack))
    except:
        return []


def is_linked_cas_apply_enabled(pack_id, pose_name):
    disabled = getattr(state, "linked_cas_apply_disabled", {}) or {}
    return not bool(disabled.get(linked_object_choice_key(pack_id, pose_name), False))


def set_linked_cas_apply_enabled(pack_id, pose_name, enabled):
    if not isinstance(getattr(state, "linked_cas_apply_disabled", None), dict):
        state.linked_cas_apply_disabled = {}
    key = linked_object_choice_key(pack_id, pose_name)
    if enabled:
        state.linked_cas_apply_disabled.pop(key, None)
    else:
        state.linked_cas_apply_disabled[key] = True
    save_favorites()


def get_enabled_linked_cas_part_ids(pack_id, pose_name, available_ids=None):
    if not is_linked_cas_apply_enabled(pack_id, pose_name):
        return []

    key = linked_object_choice_key(pack_id, pose_name)
    enabled_choices = getattr(state, "linked_cas_enabled_choices", {}) or {}
    if key in enabled_choices:
        try:
            return [int(value) for value in enabled_choices.get(key, []) if int(value or 0)]
        except:
            return []

    if available_ids is None:
        available_ids = [
            int(option.get("cas_part_id") or 0)
            for option in get_linked_cas_variant_options(pack_id, pose_name)
            if int(option.get("cas_part_id") or 0)
        ]
    return list(available_ids or [])


def set_enabled_linked_cas_part_ids(pack_id, pose_name, cas_part_ids):
    if not isinstance(getattr(state, "linked_cas_enabled_choices", None), dict):
        state.linked_cas_enabled_choices = {}
    key = linked_object_choice_key(pack_id, pose_name)
    cleaned = []
    for cas_part_id in cas_part_ids or []:
        try:
            cas_part_id = int(cas_part_id or 0)
        except:
            cas_part_id = 0
        if cas_part_id and cas_part_id not in cleaned:
            cleaned.append(cas_part_id)
    state.linked_cas_enabled_choices[key] = cleaned
    save_favorites()


def toggle_linked_cas_part_id(pack_id, pose_name, cas_part_id, available_ids):
    cas_part_id = int(cas_part_id or 0)
    available_ids = [int(value) for value in (available_ids or []) if int(value or 0)]
    current = get_enabled_linked_cas_part_ids(pack_id, pose_name, available_ids)
    if cas_part_id in current:
        current = [value for value in current if value != cas_part_id]
    elif cas_part_id:
        current.append(cas_part_id)
    set_enabled_linked_cas_part_ids(pack_id, pose_name, current)


def get_linked_cas_selection_summary(pack_id, pose_name, options=None):
    if options is None:
        options = get_linked_cas_variant_options(pack_id, pose_name)
    available_ids = [int(option.get("cas_part_id") or 0) for option in options if int(option.get("cas_part_id") or 0)]
    if not available_ids:
        return "没有可应用 CAS"
    if not is_linked_cas_apply_enabled(pack_id, pose_name):
        return "CAS 自动应用: 关"
    enabled_ids = get_enabled_linked_cas_part_ids(pack_id, pose_name, available_ids)
    return "CAS 自动应用: 已选择 {} / {} 个".format(len(enabled_ids), len(available_ids))


def get_linked_action_selection_summary(pack_id, pose_name, cas_options=None, object_options=None):
    if cas_options is None:
        cas_options = get_linked_cas_variant_options(pack_id, pose_name)
    if object_options is None:
        object_options = get_linked_object_variant_options(pack_id, pose_name)
    parts = []
    if cas_options:
        parts.append(get_linked_cas_selection_summary(pack_id, pose_name, cas_options))
    if object_options:
        parts.append(get_linked_object_selection_summary(pack_id, pose_name, object_options))
    return " | ".join(parts) if parts else "这个动作没有可选择的联动项"


def set_all_linked_requirements_for_pose(pack_id, pose_name, enabled):
    pack_id = str(pack_id or "")
    pose_name = str(pose_name or "")
    if not pack_id or not pose_name:
        return

    set_linked_cas_apply_enabled(pack_id, pose_name, enabled)
    set_linked_object_spawn_enabled(pack_id, pose_name, enabled)
    if enabled:
        key = linked_object_choice_key(pack_id, pose_name)
        if not isinstance(getattr(state, "linked_cas_enabled_choices", None), dict):
            state.linked_cas_enabled_choices = {}
        if not isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
            state.linked_object_enabled_choices = {}
        state.linked_cas_enabled_choices.pop(key, None)
        state.linked_object_enabled_choices.pop(key, None)
        set_selected_linked_object_definition_id(pack_id, pose_name, 0)
        save_favorites()


def apply_linked_cas_selection_to_refs(pack_id, source_pose_name, refs, save_changes=True):
    pack_id = str(pack_id or "")
    source_pose_name = str(source_pose_name or "")
    if not pack_id or not source_pose_name:
        return 0

    source_key = linked_object_choice_key(pack_id, source_pose_name)
    source_enabled = is_linked_cas_apply_enabled(pack_id, source_pose_name)
    source_choices = getattr(state, "linked_cas_enabled_choices", {}) or {}
    source_has_list = source_key in source_choices
    source_list = list(source_choices.get(source_key, []) or [])

    if not isinstance(getattr(state, "linked_cas_apply_disabled", None), dict):
        state.linked_cas_apply_disabled = {}
    if not isinstance(getattr(state, "linked_cas_enabled_choices", None), dict):
        state.linked_cas_enabled_choices = {}

    changed = 0
    for ref in refs:
        ref_pack_id, pose_name = linked_pose_ref_key(ref)
        if ref_pack_id != pack_id or not pose_name:
            continue
        key = linked_object_choice_key(pack_id, pose_name)
        if source_enabled:
            state.linked_cas_apply_disabled.pop(key, None)
        else:
            state.linked_cas_apply_disabled[key] = True

        if source_has_list:
            state.linked_cas_enabled_choices[key] = list(source_list)
        else:
            state.linked_cas_enabled_choices.pop(key, None)
        changed += 1

    if changed and save_changes:
        save_favorites()
    return changed


def apply_linked_cas_selection_to_pack(pack_id, source_pose_name):
    pack_id = str(pack_id or "")
    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs_for_pack
        refs = list(iter_linked_pose_refs_for_pack(getattr(state, "all_packs_cache", {}), pack_id, group_type="cas"))
    except:
        refs = get_linked_pack_pose_refs("cas", LINKED_UNGROUPED_GROUP_NAME, pack_id)
    return apply_linked_cas_selection_to_refs(pack_id, source_pose_name, refs)


def apply_linked_selection_to_current_group(pack_id, source_pose_name, refs):
    changed = 0
    changed += apply_linked_cas_selection_to_refs(pack_id, source_pose_name, refs, save_changes=False)
    changed += apply_linked_object_selection_to_refs(pack_id, source_pose_name, refs, save_changes=False)
    if changed:
        save_favorites()
    return changed


def assign_linked_pack_to_group(group_type, source_group_name, pack_id, target_group_name):
    target_group_name = str(target_group_name or "").strip()
    if not target_group_name:
        return 0

    refs = get_linked_pack_pose_refs(group_type, source_group_name, pack_id)
    added_count = 0
    for ref in refs:
        ref_pack_id, pose_name = linked_pose_ref_key(ref)
        if append_linked_group_ref(group_type, target_group_name, ref_pack_id, pose_name):
            added_count += 1

    if added_count:
        save_favorites()
    return added_count


def import_linked_groups_from_pose_grouping(group_type):
    try:
        from fgeh_pose_requirement_registry import iter_linked_pose_refs
    except:
        return 0

    if not state.cache_built:
        build_cache_safe()

    linked_keys = set()
    for ref in iter_linked_pose_refs(getattr(state, "all_packs_cache", {}), group_type=get_registry_group_type(group_type)):
        key = linked_pose_ref_key(ref)
        if key[0] and key[1]:
            linked_keys.add(key)

    imported_count = 0
    for pack_id, group_map in (getattr(state, "grouped_packs", {}) or {}).items():
        if not isinstance(group_map, dict):
            continue
        for group_name, pose_names in group_map.items():
            target_group_name = str(group_name or "").strip() or LINKED_IMPORTED_GROUP_NAME
            for pose_name in pose_names or []:
                key = (str(pack_id or ""), str(pose_name or ""))
                if key in linked_keys and append_linked_group_ref(group_type, target_group_name, key[0], key[1]):
                    imported_count += 1

    if imported_count:
        save_favorites()
    return imported_count


def create_default_linked_group(group_type):
    groups = ensure_linked_groups_container(group_type)
    index = len(groups) + 1
    group_name = "新联动分组 {}".format(index)
    while group_name in groups:
        index += 1
        group_name = "新联动分组 {}".format(index)
    groups[group_name] = []
    save_favorites()
    return group_name


def play_linked_pose(self, actual_target, pack_id, pose_name):
    pack = state.all_packs_cache.get(pack_id) if pack_id else None
    if pack is None or not pose_name:
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    from interactions.context import QueueInsertStrategy
    from interactions.priority import Priority
    if POSITIONING_SYSTEM_ACTIVE:
        ensure_positioning_session(self, pose_name, actual_target)
    self.interaction_parameters['pose_name'] = pose_name
    self.push_tunable_continuation((self.continuation), pose_name=pose_name, insert_strategy=(QueueInsertStrategy.LAST), priority=Priority.High, actor=(actual_target))
    return self._show_picker_dialog(self.sim, target_sim=actual_target)


def play_linked_pose_refs(self, actual_target, refs):
    if not refs:
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    from interactions.context import QueueInsertStrategy
    from interactions.priority import Priority
    for ref in refs:
        pack_id, pose_name = linked_pose_ref_key(ref)
        pack = state.all_packs_cache.get(pack_id) if pack_id else None
        if pack is None or not pose_name:
            continue
        if POSITIONING_SYSTEM_ACTIVE:
            ensure_positioning_session(self, pose_name, actual_target)
        self.interaction_parameters['pose_name'] = pose_name
        self.push_tunable_continuation((self.continuation), pose_name=pose_name, insert_strategy=(QueueInsertStrategy.LAST), priority=Priority.High, actor=(actual_target))
    return self._show_picker_dialog(self.sim, target_sim=actual_target)


# ==========================================
# 菜单渲染区
# ==========================================
target_cls = getattr(poseplayer, 'PoseByPackInteraction', None)

if target_cls is not None and not isinstance(target_cls, str):
    @injector2.inject(target_cls, 'picker_rows_gen')
    def custom_pack_rows_gen_safe(original, *args, **kwargs):
        state.came_from_grouped, state.came_from_l1_favs, state.came_from_creator = False, False, False
        state.g_view_mode = GroupMode.LIST 
        state.is_in_normal_pack_manage_mode = False  
        
        try:
            if hasattr(target_cls, 'POSE_PACKS') and not getattr(state, 'pose_pack_cache_reset_done', False):
                target_cls.POSE_PACKS = None
                state.pose_pack_cache_reset_done = True
            try: gen = original(*args, **kwargs)
            except TypeError: gen = original(*args[1:], **kwargs)

            yield create_localized_picker_row(
                get_stbl_text(STR_GS_ENTRY_TITLE),
                MANAGE_ICON,
                GLOBAL_SETTINGS_PACK_TOKEN,
                get_stbl_text(STR_GS_ENTRY_DESC)
            )
            yield ObjectPickerRow(
                name=raw_picker_text("联动动作库"),
                row_description=raw_picker_text("查看带配饰、服装、手持道具或物体生成的动作"),
                icon=FOlDER_ICON,
                tag=LINKED_ACTIONS_PACK_TOKEN
            )
            yield RowFactory.create_folder_row(STR_L1_GROUPED_TITLE, STR_L1_GROUPED_DESC, FOlDER_ICON, "fgeh_grouped_folder")
            yield RowFactory.create_folder_row(STR_L1_FAV_PACKS_TITLE, STR_L1_FAV_PACKS_DESC, FOlDER_ICON, "fgeh_fav_packs_folder")
            yield RowFactory.create_folder_row(STR_L1_CREATORS_TITLE, STR_L1_CREATORS_DESC, FOlDER_ICON, "hegfcreator_folder")
            yield RowFactory.create_folder_row(STR_L1_POSES_TITLE, STR_L1_POSES_DESC, FOlDER_ICON, "fgeh_poses_folder")

            seen_tags = {"fgeh_fav_packs_folder", "hegfcreator_folder", "fgeh_poses_folder", "fgeh_grouped_folder", LINKED_ACTIONS_PACK_TOKEN, GLOBAL_SETTINGS_PACK_TOKEN}
            for row in gen:
                if row.tag in seen_tags: continue
                pack = row.tag
                if not isinstance(pack, str):
                    sn = str(getattr(pack, 'sort_name', "")).strip().lower()
                    dn = str(getattr(pack, 'display_name', "")).strip().lower()
                    if not sn or sn in ('', 'unknown', '0x00000000', 'none', 'nan', '0x0', '0') or dn in ('0x00000000', '0x0'):
                        continue
                yield row
        except:
            try: yield from original(*args, **kwargs)
            except TypeError: yield from original(*args[1:], **kwargs)


    @injector2.inject(target_cls, '_run_interaction_gen', safe=True)
    def _fgeh_restore_last_view_on_open(original, self, timeline, *args, **kwargs):
        if state.suppress_next_history_restore:
            state.suppress_next_history_restore = False
            return original(self, timeline, *args, **kwargs)
        if state.restore_last_view_on_open:
            resolved_snapshot = resolve_last_ui_snapshot()
            if resolved_snapshot is not None:
                try:
                    snapshot, restored_pack = resolved_snapshot
                    selected_pack = apply_last_ui_snapshot(snapshot)
                    if selected_pack is not None:
                        self.on_choice_selected(selected_pack)
                        return True
                    self.on_choice_selected(restored_pack)
                    return True
                except:
                    pass
        return original(self, timeline, *args, **kwargs)


def custom_pose_rows_gen(inst, target, context, **kwargs):

    pack = getattr(inst, 'selected_pose_pack', None)
    if not pack: return
    pack_type = get_pack_type(pack)

    if pack_type == 'POSES': state.global_fav_pack_ref = pack
    elif pack_type == 'NORMAL':
        if state.current_mode == ViewMode.TRACE: state.current_mode = ViewMode.NORMAL
        if pack != state.global_traced_pack_ref: state.return_to_fav_on_close = False

    mode_map = {ViewMode.NORMAL: STR_MODE_NAME_PLAY, ViewMode.FAV: STR_MODE_NAME_FAV, ViewMode.TRACE: STR_MODE_NAME_TRACE}
    current_mode_stbl_id = mode_map.get(state.current_mode, STR_MODE_NAME_PLAY)
    current_mode_str = get_stbl_text(current_mode_stbl_id)

    if pack_type != 'GLOBAL_SETTINGS':
        remember_last_ui_snapshot(pack)

    if pack_type == 'GLOBAL_SETTINGS':
        history_status = get_stbl_text(STR_GS_STATUS_ON if state.restore_last_view_on_open else STR_GS_STATUS_OFF)
        yield create_localized_picker_row(
            get_stbl_text(STR_GS_RETURN_HISTORY, history_status),
            SWITCH_ICON,
            "GLOBAL_SETTINGS::TOGGLE_RESTORE_HISTORY",
            get_stbl_text(STR_GS_RETURN_HISTORY_DESC)
        )
        linked_auto_status = "开" if getattr(state, "auto_apply_linked_requirements", True) else "关"
        yield create_localized_picker_row(
            raw_picker_text("全局自动联动: {}".format(linked_auto_status)),
            SWITCH_ICON,
            "GLOBAL_SETTINGS::TOGGLE_AUTO_APPLY_LINKED",
            raw_picker_text("关闭后，所有动作播放时都不会自动更换 CAS 或生成物体；手动选择记录会保留。")
        )
        object_cleanup_status = "开" if getattr(state, "auto_destroy_linked_objects", True) else "关"
        yield create_localized_picker_row(
            raw_picker_text("推荐：动作结束后清理生成物体: {}".format(object_cleanup_status)),
            SWITCH_ICON,
            "GLOBAL_SETTINGS::TOGGLE_AUTO_DESTROY_OBJECTS",
            raw_picker_text("关闭后，动作生成的联动物体会保留在场景里。")
        )
        final_restore_status = "开" if getattr(state, "restore_linked_requirements_when_pose_chain_finished", False) else "关"
        yield create_localized_picker_row(
            raw_picker_text("动作队列结束后恢复联动: {}".format(final_restore_status)),
            SWITCH_ICON,
            "GLOBAL_SETTINGS::TOGGLE_RESTORE_LINKED_ON_CHAIN_FINISHED",
            raw_picker_text("开启后，当前小人没有任何摆动作运行或排队时，恢复动作前 CAS，并清理联动生成物体。")
        )
        object_replace_status = "开" if getattr(state, "replace_linked_objects_on_replay", True) else "关"
        yield create_localized_picker_row(
            raw_picker_text("推荐：重复播放前替换旧物体: {}".format(object_replace_status)),
            SWITCH_ICON,
            "GLOBAL_SETTINGS::TOGGLE_REPLACE_OBJECTS_ON_REPLAY",
            raw_picker_text("开启后，播放新的联动物体动作前会先清理旧联动物体。")
        )
        return

    # ==========================================
    # 动作分组器菜单层级 (三态视图)
    # ==========================================
    if pack_type == 'LINKED_ACTIONS':
        if not state.cache_built:
            build_cache_safe()
        selected_group_type = getattr(state, 'selected_linked_group_type', None)
        selected_group_name = getattr(state, 'selected_linked_group_name', None)
        selected_pack_id = getattr(state, 'selected_linked_pack_id', None)
        selected_assign_pack_id = getattr(state, 'selected_linked_assign_pack_id', None)
        selected_grouped_outer_name = getattr(state, 'selected_linked_grouped_outer_name', None)
        selected_grouped_pose_group_name = getattr(state, 'selected_linked_grouped_pose_group_name', None)
        linked_manage_mode = bool(getattr(state, 'linked_manage_mode', False))
        linked_group_manage_mode = bool(getattr(state, 'linked_group_manage_mode', False))
        linked_object_style_mode = bool(getattr(state, 'linked_object_style_mode', False))
        selected_style_pose_name = getattr(state, 'selected_linked_style_pose_name', None)
        selected_requirement_folder = getattr(state, 'selected_linked_requirement_folder', None)
        selected_requirement_asset_key = getattr(state, 'selected_linked_requirement_asset_key', None)

        if not selected_group_type:
            try:
                from fgeh_pose_requirement_registry import get_available_group_types
                from fgeh_pose_requirement_registry import iter_linked_pack_refs
                counts = get_available_group_types(getattr(state, "all_packs_cache", {}))
                all_count = len(list(iter_linked_pack_refs(getattr(state, "all_packs_cache", {}))))
            except:
                counts = {}
                all_count = 0

            for group_type in (LINKED_ALL_GROUP_TYPE, "cas", "object"):
                yield ObjectPickerRow(
                    name=raw_picker_text(get_linked_group_type_title(group_type)),
                    row_description=raw_picker_text(get_linked_group_type_desc(group_type)),
                    count=int(all_count if group_type == LINKED_ALL_GROUP_TYPE else counts.get(group_type, 0) or 0),
                    icon=FOlDER_ICON,
                    tag=LINKED_GROUP_TYPE_PREFIX + group_type
                )
            yield ObjectPickerRow(
                name=raw_picker_text("联动设置"),
                row_description=raw_picker_text("调整自动应用联动项、物体清理和防重复生成"),
                icon=MANAGE_ICON,
                tag="FGEH_LINKED_OPEN_SETTINGS"
            )
            return

        if not selected_group_name:
            groups = ensure_linked_groups_container(selected_group_type)
            yield ObjectPickerRow(
                name=raw_picker_text("返回联动类型"),
                icon=RETURN_ICON,
                tag="FGEH_LINKED_BACK_TO_TYPES"
            )

            if linked_group_manage_mode:
                yield ObjectPickerRow(
                    name=raw_picker_text("返回分组浏览"),
                    row_description=raw_picker_text("回到播放和浏览联动动作的列表"),
                    icon=RETURN_ICON,
                    tag="FGEH_LINKED_TOGGLE_GROUP_MANAGE"
                )
                yield ObjectPickerRow(
                    name=raw_picker_text("新建联动分组"),
                    row_description=raw_picker_text("创建一个空的玩家联动分组"),
                    icon=ADD_ICON,
                    tag="FGEH_LINKED_CREATE_GROUP"
                )
                yield ObjectPickerRow(
                    name=raw_picker_text("打开分组联动"),
                    row_description=raw_picker_text("直接读取动作分组器外层组和动作包内部动作组，不平铺导入"),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_IMPORT_GROUPED"
                )
                for group_name in sorted(groups.keys()):
                    yield ObjectPickerRow(
                        name=raw_picker_text("重命名: " + str(group_name)),
                        row_description=raw_picker_text("修改这个联动分组名称"),
                        count=len(get_linked_group_pack_refs(selected_group_type, group_name)),
                        icon=MANAGE_ICON,
                        tag=linked_group_action_tag(LINKED_GROUP_RENAME_PREFIX, group_name)
                    )
                    yield ObjectPickerRow(
                        name=raw_picker_text("删除: " + str(group_name)),
                        row_description=raw_picker_text("删除这个联动分组"),
                        count=len(get_linked_group_pack_refs(selected_group_type, group_name)),
                        icon=DELETE_ICON,
                        tag=linked_group_action_tag(LINKED_GROUP_DELETE_PREFIX, group_name)
                    )
                if not groups:
                    yield ObjectPickerRow(
                        name=raw_picker_text("还没有自定义分组"),
                        row_description=raw_picker_text("可以先新建分组，或从动作分组器导入"),
                        icon=MANAGE_ICON,
                        tag="FGEH_LINKED_NOOP"
                    )
                return

            yield ObjectPickerRow(
                name=raw_picker_text(LINKED_ALL_GROUP_NAME),
                row_description=raw_picker_text("查看这个筛选下的全部联动动作"),
                count=len(get_linked_group_pack_refs(selected_group_type, LINKED_ALL_GROUP_NAME)),
                icon=FOlDER_ICON,
                tag=LINKED_GROUP_PREFIX + LINKED_ALL_GROUP_NAME
            )
            yield ObjectPickerRow(
                name=raw_picker_text(LINKED_UNGROUPED_GROUP_NAME),
                row_description=raw_picker_text("只显示还没有放进自定义联动分组的动作"),
                count=len(get_linked_group_pack_refs(selected_group_type, LINKED_UNGROUPED_GROUP_NAME)),
                icon=FOlDER_ICON,
                tag=LINKED_GROUP_PREFIX + LINKED_UNGROUPED_GROUP_NAME
            )
            grouped_outer_refs = get_linked_grouped_outer_refs(selected_group_type)
            if grouped_outer_refs:
                yield ObjectPickerRow(
                    name=raw_picker_text(LINKED_GROUPED_ENTRY_NAME),
                    row_description=raw_picker_text("按动作分组器里的自定义分组浏览联动动作"),
                    count=len(grouped_outer_refs),
                    icon=FOlDER_ICON,
                    tag=LINKED_GROUP_PREFIX + LINKED_GROUPED_ENTRY_NAME
                )
            for group_name in sorted(groups.keys()):
                yield ObjectPickerRow(
                    name=raw_picker_text(group_name),
                    row_description=raw_picker_text("玩家自定义联动分组"),
                    count=len(get_linked_group_pack_refs(selected_group_type, group_name)),
                    icon=FOlDER_ICON,
                    tag=LINKED_GROUP_PREFIX + group_name
                )
            yield ObjectPickerRow(
                name=raw_picker_text("整理联动分组"),
                row_description=raw_picker_text("新建、导入、重命名或删除联动分组"),
                icon=MANAGE_ICON,
                tag="FGEH_LINKED_TOGGLE_GROUP_MANAGE"
            )
            return

        if selected_group_name == LINKED_GROUPED_ENTRY_NAME:
            if not selected_grouped_outer_name:
                yield ObjectPickerRow(
                    name=raw_picker_text("返回分组列表"),
                    icon=RETURN_ICON,
                    tag="FGEH_LINKED_BACK_TO_GROUPS"
                )
                outer_refs = get_linked_grouped_outer_refs(selected_group_type)
                if not outer_refs:
                    yield ObjectPickerRow(
                        name=raw_picker_text("没有可用的分组联动"),
                        row_description=raw_picker_text("动作分组器里需要先有自定义动作包组，并且其中动作需要有联动数据"),
                        icon=MANAGE_ICON,
                        tag="FGEH_LINKED_NOOP"
                    )
                    return
                for ref in outer_refs:
                    outer_name = str(ref.get("outer_name") or "")
                    yield ObjectPickerRow(
                        name=raw_picker_text(outer_name),
                        row_description=raw_picker_text("动作分组器外层分组"),
                        count=int(ref.get("pose_count") or 0),
                        icon=FOlDER_ICON,
                        tag=linked_grouped_outer_tag(outer_name)
                    )
                return

            if not selected_pack_id:
                yield ObjectPickerRow(
                    name=raw_picker_text("返回分组联动"),
                    icon=RETURN_ICON,
                    tag="FGEH_LINKED_BACK_TO_GROUPED_OUTERS"
                )
                pack_refs = get_linked_grouped_pack_refs(selected_group_type, selected_grouped_outer_name)
                if not pack_refs:
                    yield ObjectPickerRow(
                        name=raw_picker_text("这个分组暂无联动动作包"),
                        row_description=raw_picker_text("只会显示动作分组器中有动作组、且动作带联动数据的动作包"),
                        icon=MANAGE_ICON,
                        tag="FGEH_LINKED_NOOP"
                    )
                    return
                for ref in pack_refs:
                    pack_id = str(ref.get("pack_id") or "")
                    pack = ref.get("pack") or state.all_packs_cache.get(pack_id)
                    if not pack:
                        continue
                    yield ObjectPickerRow(
                        name=get_visible_pack_name(pack, get_stbl_text(STR_UI_UNNAMED_PACK)),
                        row_description=raw_picker_text(str(selected_grouped_outer_name)),
                        count=int(ref.get("pose_count") or 0),
                        icon=getattr(pack, 'icon', FOlDER_ICON),
                        tag=linked_grouped_pack_tag(pack_id)
                    )
                return

            if not selected_grouped_pose_group_name:
                yield ObjectPickerRow(
                    name=raw_picker_text("返回动作包列表"),
                    icon=RETURN_ICON,
                    tag="FGEH_LINKED_BACK_TO_GROUPED_PACKS"
                )
                current_target = target
                try:
                    custom_target_id = getattr(inst, 'fgeh_custom_target_id', None)
                    if custom_target_id:
                        found_sim = services.object_manager().get(custom_target_id)
                        if found_sim:
                            current_target = found_sim
                except Exception:
                    pass
                target_name = getattr(current_target, 'first_name', "未知")
                yield ObjectPickerRow(
                    name=raw_picker_text("切换目标小人"),
                    row_description=raw_picker_text("当前目标: {}".format(target_name)),
                    icon=CHOOSESIMS_ICON,
                    tag="BTN_SELECT_OTHER_SIM"
                )
                group_refs = get_linked_grouped_pose_group_refs(selected_group_type, selected_pack_id)
                if not group_refs:
                    yield ObjectPickerRow(
                        name=raw_picker_text("这个动作包暂无可用动作组"),
                        row_description=raw_picker_text("只显示动作组里带联动数据的动作"),
                        icon=MANAGE_ICON,
                        tag="FGEH_LINKED_NOOP"
                    )
                    return
                for ref in group_refs:
                    group_name = str(ref.get("group_name") or "")
                    yield ObjectPickerRow(
                        name=raw_picker_text(group_name),
                        row_description=raw_picker_text("动作分组器里的动作组"),
                        count=int(ref.get("pose_count") or 0),
                        icon=FOlDER_ICON,
                        tag=linked_grouped_pose_group_tag(group_name)
                    )
                return

        if selected_assign_pack_id:
            pack = state.all_packs_cache.get(selected_assign_pack_id)
            yield ObjectPickerRow(
                name=raw_picker_text("返回动作包列表"),
                icon=RETURN_ICON,
                tag="FGEH_LINKED_BACK_TO_PACKS"
            )
            yield ObjectPickerRow(
                name=raw_picker_text("新建联动分组"),
                row_description=raw_picker_text("创建新分组，并把这个动作包加入进去"),
                icon=ADD_ICON,
                tag="FGEH_LINKED_CREATE_GROUP_FOR_ASSIGN"
            )
            groups = ensure_linked_groups_container(selected_group_type)
            for group_name in sorted(groups.keys()):
                yield ObjectPickerRow(
                    name=raw_picker_text(group_name),
                    row_description=get_visible_pack_name(pack, get_stbl_text(STR_UI_UNNAMED_PACK)) if pack else raw_picker_text("分配到这个联动分组"),
                    count=len(groups.get(group_name, []) or []),
                    icon=FOlDER_ICON,
                    tag=linked_assign_group_tag(group_name)
                )
            if not groups:
                yield ObjectPickerRow(
                    name=raw_picker_text("还没有自定义分组"),
                    row_description=raw_picker_text("先点新建联动分组"),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_NOOP"
                )
            return

        if not selected_pack_id:
            yield ObjectPickerRow(
                name=raw_picker_text("返回分组列表"),
                icon=RETURN_ICON,
                tag="FGEH_LINKED_BACK_TO_GROUPS"
            )
            yield ObjectPickerRow(
                name=raw_picker_text("退出整理模式" if linked_manage_mode else "整理这个列表"),
                row_description=raw_picker_text("选择动作包，然后移动到自定义联动分组" if not linked_manage_mode else "回到普通动作包浏览"),
                icon=MANAGE_ICON,
                tag="FGEH_LINKED_TOGGLE_MANAGE"
            )
            if linked_manage_mode:
                yield ObjectPickerRow(
                    name=raw_picker_text("【整理模式】请选择要移动的动作包"),
                    row_description=raw_picker_text("下面的动作包点进去后会选择目标联动分组"),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_NOOP"
                )
            pack_refs = get_linked_group_pack_refs(selected_group_type, selected_group_name)
            if not pack_refs:
                yield ObjectPickerRow(
                    name=raw_picker_text("这个分组暂无动作包"),
                    row_description=raw_picker_text("可以先从动作分组器导入，或之后在分配界面添加"),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_NOOP"
                )
                return

            for ref in pack_refs:
                pack_id = str(ref.get("pack_id") or "")
                pack = ref.get("pack") or state.all_packs_cache.get(pack_id)
                if not pack:
                    continue
                display_name = get_visible_pack_name(pack, get_stbl_text(STR_UI_UNNAMED_PACK))
                yield ObjectPickerRow(
                    name=display_name,
                    row_description=raw_picker_text("整理模式：选择后移动到一个联动分组") if linked_manage_mode else raw_picker_text(get_linked_group_type_title(selected_group_type)),
                    count=int(ref.get("pose_count") or 0),
                    icon=getattr(pack, 'icon', FOlDER_ICON),
                    tag=linked_pack_tag(selected_group_type, pack_id)
                )
            return

        if selected_style_pose_name and selected_requirement_folder:
            if selected_requirement_asset_key:
                back_name = "返回联动项目列表"
                back_tag = "FGEH_LINKED_BACK_TO_REQUIREMENT_ITEMS"
            elif is_linked_object_source_folder(selected_requirement_folder):
                back_name = "返回物体联动"
                back_tag = "FGEH_LINKED_BACK_TO_OBJECT_REQUIREMENTS"
            else:
                back_name = "返回动作联动设置"
                back_tag = "FGEH_LINKED_BACK_TO_REQUIREMENT_SETTINGS"
        else:
            back_name = "返回动作组列表" if selected_group_name == LINKED_GROUPED_ENTRY_NAME else "返回动作包列表"
            back_tag = "FGEH_LINKED_BACK_TO_GROUPED_POSE_GROUPS" if selected_group_name == LINKED_GROUPED_ENTRY_NAME and not selected_style_pose_name else "FGEH_LINKED_BACK_TO_PACKS"
        yield ObjectPickerRow(
            name=raw_picker_text(back_name),
            icon=RETURN_ICON,
            tag=back_tag
        )
        if not selected_style_pose_name and not selected_requirement_folder:
            linked_auto_status = "开" if getattr(state, "auto_apply_linked_requirements", True) else "关"
            yield ObjectPickerRow(
                name=raw_picker_text("全局自动联动: {}".format(linked_auto_status)),
                row_description=raw_picker_text("关闭后，所有动作播放时都不会自动更换 CAS 或生成物体；手动选择记录会保留。"),
                icon=SWITCH_ICON,
                tag="FGEH_LINKED_TOGGLE_AUTO_APPLY"
            )
        if selected_style_pose_name:
            cas_options = get_linked_cas_variant_options(selected_pack_id, selected_style_pose_name)
            object_options = get_linked_object_variant_options(selected_pack_id, selected_style_pose_name)
            cas_status = "无"
            object_status = "无"
            if cas_options:
                cas_status = "开" if is_linked_cas_apply_enabled(selected_pack_id, selected_style_pose_name) else "关"
            if object_options:
                object_status = "开" if is_linked_object_spawn_enabled(selected_pack_id, selected_style_pose_name) else "关"
            if not selected_requirement_folder:
                yield ObjectPickerRow(
                    name=raw_picker_text("当前动作联动状态: CAS {}，物体 {}".format(cas_status, object_status)),
                    row_description=raw_picker_text(get_linked_action_selection_summary(selected_pack_id, selected_style_pose_name, cas_options, object_options)),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_NOOP"
                )
                has_linked_options = bool(cas_options or object_options)
                all_linked_enabled = has_linked_options
                if cas_options and not is_linked_cas_apply_enabled(selected_pack_id, selected_style_pose_name):
                    all_linked_enabled = False
                if object_options and not is_linked_object_spawn_enabled(selected_pack_id, selected_style_pose_name):
                    all_linked_enabled = False
                next_all_enabled = not all_linked_enabled
                yield ObjectPickerRow(
                    name=raw_picker_text("这个动作自动联动: {}".format("开" if all_linked_enabled else "关")),
                    row_description=raw_picker_text(
                        "关闭当前动作的 CAS 和物体自动联动。" if all_linked_enabled
                        else "开启当前动作的 CAS 和物体自动联动，并恢复为全部联动项生效。"
                    ),
                    icon=SWITCH_ICON,
                    tag=linked_setting_set_pose_all_tag(selected_pack_id, selected_style_pose_name, next_all_enabled)
                )
                if cas_options:
                    restore_cas_status = "开" if is_linked_cas_restore_before_apply_enabled(selected_pack_id, selected_style_pose_name) else "关"
                    yield ObjectPickerRow(
                        name=raw_picker_text("播放前先清除旧 CAS: {}".format(restore_cas_status)),
                        row_description=raw_picker_text("开启后，播放这个动作前会先恢复上一次联动换上的 CAS，再应用当前动作的配件。"),
                        icon=SWITCH_ICON,
                        tag=linked_setting_restore_cas_tag(selected_pack_id, selected_style_pose_name)
                    )
                apply_to_group = selected_group_name == LINKED_GROUPED_ENTRY_NAME and bool(selected_grouped_pose_group_name)
                yield ObjectPickerRow(
                    name=raw_picker_text("应用到当前组" if apply_to_group else "应用到整个动作包"),
                    row_description=raw_picker_text(
                        "把当前动作的 CAS 和物体联动选择复制给当前小人组里的动作"
                        if apply_to_group
                        else "把当前动作的 CAS 和物体联动选择复制给同包全部联动动作"
                    ),
                    icon=MANAGE_ICON,
                    tag=linked_setting_apply_pack_tag(selected_pack_id, selected_style_pose_name)
                )
                if cas_options:
                    cas_available_ids = [
                        int(option.get("cas_part_id") or 0)
                        for option in cas_options
                        if int(option.get("cas_part_id") or 0)
                    ]
                    cas_enabled_ids = get_enabled_linked_cas_part_ids(selected_pack_id, selected_style_pose_name, cas_available_ids)
                    cas_folder_status = "开" if is_linked_cas_apply_enabled(selected_pack_id, selected_style_pose_name) else "关"
                    yield ObjectPickerRow(
                        name=raw_picker_text("CAS 联动"),
                        row_description=raw_picker_text("自动应用：{}；已选择 {} / {} 个".format(cas_folder_status, len(cas_enabled_ids), len(cas_available_ids))),
                        count=len(cas_options),
                        icon=FOlDER_ICON,
                        tag=linked_setting_folder_tag("cas")
                    )
                if object_options:
                    object_available_ids = [
                        int(option.get("definition_id") or 0)
                        for option in object_options
                        if int(option.get("definition_id") or 0)
                    ]
                    object_enabled_ids = get_enabled_linked_object_definition_ids(selected_pack_id, selected_style_pose_name, object_available_ids)
                    if object_enabled_ids is None:
                        object_enabled_ids = list(object_available_ids)
                    object_folder_status = "开" if is_linked_object_spawn_enabled(selected_pack_id, selected_style_pose_name) else "关"
                    yield ObjectPickerRow(
                        name=raw_picker_text("物体联动"),
                        row_description=raw_picker_text("自动生成：{}；已选择 {} / {} 个".format(object_folder_status, len(object_enabled_ids), len(object_available_ids))),
                        count=len(object_options),
                        icon=FOlDER_ICON,
                        tag=linked_setting_folder_tag("object")
                    )
                if not cas_options and not object_options:
                    yield ObjectPickerRow(
                        name=raw_picker_text("这个动作没有可选择的联动项"),
                        icon=MANAGE_ICON,
                        tag="FGEH_LINKED_NOOP"
                    )
                return

            if selected_requirement_folder == "cas" and cas_options:
                cas_available_ids = [
                    int(option.get("cas_part_id") or 0)
                    for option in cas_options
                    if int(option.get("cas_part_id") or 0)
                ]
                cas_enabled_ids = get_enabled_linked_cas_part_ids(selected_pack_id, selected_style_pose_name, cas_available_ids)
                cas_auto_enabled = is_linked_cas_apply_enabled(selected_pack_id, selected_style_pose_name)
                if not selected_requirement_asset_key:
                    yield ObjectPickerRow(
                        name=raw_picker_text("自动应用 CAS: {}".format("开" if cas_auto_enabled else "关")),
                        row_description=raw_picker_text("关闭后，播放这个动作时不会自动更换 CAS 配件"),
                        icon=SWITCH_ICON,
                        tag=linked_setting_auto_toggle_tag("cas", selected_pack_id, selected_style_pose_name)
                    )
                    cas_all_selected = bool(cas_available_ids) and len(cas_enabled_ids) >= len(cas_available_ids)
                    yield ObjectPickerRow(
                        name=raw_picker_text("[全不选] CAS 联动项" if cas_all_selected else "[全选] CAS 联动项"),
                        row_description=raw_picker_text("取消选择这个动作的全部 CAS 联动项" if cas_all_selected else "选择这个动作的全部 CAS 联动项"),
                        icon=SWITCH_ICON,
                        tag=linked_setting_enable_all_tag("cas", selected_pack_id, selected_style_pose_name)
                    )
                    for group in group_linked_variant_options(cas_options, "cas_part_id"):
                        group_options = group.get("options") or []
                        group_ids = [
                            int(option.get("cas_part_id") or 0)
                            for option in group_options
                            if int(option.get("cas_part_id") or 0)
                        ]
                        selected_count = len([item_id for item_id in group_ids if item_id in cas_enabled_ids])
                        group_icon = first_linked_option_icon(group_options, "entry_icon", "icon")
                        yield ObjectPickerRow(
                            name=raw_picker_text(group.get("label") or "CAS 联动项"),
                            row_description=raw_picker_text("已选择 {} / {} 个样式".format(selected_count, len(group_ids))),
                            count=len(group_options),
                            icon=group_icon or FOlDER_ICON,
                            tag=linked_setting_asset_folder_tag("cas", group.get("key"))
                        )
                else:
                    group = find_linked_option_group(cas_options, "cas_part_id", selected_requirement_asset_key)
                    group_options = group.get("options") if group else []
                    for option in group_options:
                        item_id = int(option.get("cas_part_id") or 0)
                        label = option.get("variant_label") or option.get("label") or "CAS {}".format(item_id)
                        if not cas_auto_enabled:
                            label = "[暂不生效] " + str(label)
                        elif item_id in cas_enabled_ids:
                            label = "[已选择] " + str(label)
                        else:
                            label = "[未选择] " + str(label)
                        yield ObjectPickerRow(
                            name=raw_picker_text(label),
                            row_description=raw_picker_text("CAS Part ID: {}".format(item_id)),
                            icon=option.get("icon") or option.get("entry_icon") or MY_CUSTOM_ICON,
                            tag=linked_setting_item_toggle_tag("cas", selected_pack_id, selected_style_pose_name, item_id)
                        )
            if selected_requirement_folder == "object" and object_options:
                object_available_ids = [
                    int(option.get("definition_id") or 0)
                    for option in object_options
                    if int(option.get("definition_id") or 0)
                ]
                object_enabled_ids = get_enabled_linked_object_definition_ids(selected_pack_id, selected_style_pose_name, object_available_ids)
                if object_enabled_ids is None:
                    object_enabled_ids = list(object_available_ids)
                object_auto_enabled = is_linked_object_spawn_enabled(selected_pack_id, selected_style_pose_name)
                yield ObjectPickerRow(
                    name=raw_picker_text("自动生成物体: {}".format("开" if object_auto_enabled else "关")),
                    row_description=raw_picker_text("关闭后，播放这个动作时不会自动生成联动物体"),
                    icon=SWITCH_ICON,
                    tag=linked_setting_auto_toggle_tag("object", selected_pack_id, selected_style_pose_name)
                )
                object_all_selected = bool(object_available_ids) and len(object_enabled_ids) >= len(object_available_ids)
                yield ObjectPickerRow(
                    name=raw_picker_text("[全不选] 物体联动项" if object_all_selected else "[全选] 物体联动项"),
                    row_description=raw_picker_text("取消选择这个动作的全部物体联动项" if object_all_selected else "选择这个动作的全部物体联动项"),
                    icon=SWITCH_ICON,
                    tag=linked_setting_enable_all_tag("object", selected_pack_id, selected_style_pose_name)
                )
                hidden_object_ids = get_hidden_linked_object_definition_ids(selected_pack_id, selected_style_pose_name)
                if hidden_object_ids:
                    yield ObjectPickerRow(
                        name=raw_picker_text("恢复隐藏的物体选项"),
                        row_description=raw_picker_text("显示当前动作里被隐藏的 {} 个物体样式。".format(len(hidden_object_ids))),
                        count=len(hidden_object_ids),
                        icon=MANAGE_ICON,
                        tag=linked_setting_clear_hidden_objects_tag(selected_pack_id, selected_style_pose_name)
                    )
                local_object_options = [option for option in object_options if option.get("source_origin") == "local"]
                external_object_options = [option for option in object_options if option.get("source_origin") != "local"]
                yield ObjectPickerRow(
                    name=raw_picker_text("游戏内绑定物体"),
                    row_description=raw_picker_text("通过点击游戏内物体绑定到当前动作的物体"),
                    count=len(local_object_options),
                    icon=FOlDER_ICON,
                    tag=linked_setting_folder_tag("object_local")
                )
                yield ObjectPickerRow(
                    name=raw_picker_text("外部联动包物体"),
                    row_description=raw_picker_text("由外部 XML / 绑定包提供的物体"),
                    count=len(external_object_options),
                    icon=FOlDER_ICON,
                    tag=linked_setting_folder_tag("object_external")
                )

            if is_linked_object_source_folder(selected_requirement_folder) and object_options:
                object_available_ids = [
                    int(option.get("definition_id") or 0)
                    for option in object_options
                    if int(option.get("definition_id") or 0)
                ]
                object_enabled_ids = get_enabled_linked_object_definition_ids(selected_pack_id, selected_style_pose_name, object_available_ids)
                if object_enabled_ids is None:
                    object_enabled_ids = list(object_available_ids)
                object_auto_enabled = is_linked_object_spawn_enabled(selected_pack_id, selected_style_pose_name)
                source_origin = "local" if selected_requirement_folder == "object_local" else "external"
                filtered_object_options = [
                    option for option in object_options
                    if (option.get("source_origin") == "local") == (source_origin == "local")
                ]
                if not selected_requirement_asset_key:
                    for group in group_linked_variant_options(filtered_object_options, "definition_id"):
                        group_options = group.get("options") or []
                        group_ids = [
                            int(option.get("definition_id") or 0)
                            for option in group_options
                            if int(option.get("definition_id") or 0)
                        ]
                        selected_count = len([item_id for item_id in group_ids if item_id in object_enabled_ids])
                        yield ObjectPickerRow(
                            name=raw_picker_text(group.get("label") or "物体联动项"),
                            row_description=raw_picker_text("已选择 {} / {} 个样式".format(selected_count, len(group_ids))),
                            count=len(group_options),
                            icon=FOlDER_ICON,
                            tag=linked_setting_asset_folder_tag(selected_requirement_folder, group.get("key"))
                        )
                else:
                    group = find_linked_option_group(filtered_object_options, "definition_id", selected_requirement_asset_key)
                    group_options = group.get("options") if group else []
                    for option in group_options:
                        item_id = int(option.get("definition_id") or 0)
                        label = option.get("label") or "Object {}".format(item_id)
                        source_label = option.get("source_label") or "物体联动"
                        if not object_auto_enabled:
                            label = "[暂不生效] " + str(label)
                        elif item_id in object_enabled_ids:
                            label = "[已选择] " + str(label)
                        else:
                            label = "[未选择] " + str(label)
                        yield ObjectPickerRow(
                            name=raw_picker_text(label),
                            row_description=raw_picker_text("{} | Object Definition ID: {}".format(source_label, item_id)),
                            icon=MY_CUSTOM_ICON,
                            tag=linked_setting_item_toggle_tag("object", selected_pack_id, selected_style_pose_name, item_id)
                        )
                        yield ObjectPickerRow(
                            name=raw_picker_text("隐藏这个物体选项"),
                            row_description=raw_picker_text("从当前动作的物体联动列表中隐藏这个样式；不会修改外部 XML 或绑定文件。"),
                            icon=MANAGE_ICON,
                            tag=linked_setting_hide_object_tag(selected_pack_id, selected_style_pose_name, item_id)
                        )

            if (
                (selected_requirement_folder == "cas" and not cas_options)
                or (selected_requirement_folder == "object" and not object_options)
                or (selected_requirement_folder == "object_local" and not [option for option in object_options if option.get("source_origin") == "local"])
                or (selected_requirement_folder == "object_external" and not [option for option in object_options if option.get("source_origin") != "local"])
            ):
                yield ObjectPickerRow(
                    name=raw_picker_text("这个文件夹没有可选择的联动项"),
                    icon=MANAGE_ICON,
                    tag="FGEH_LINKED_NOOP"
                )
            return
        yield ObjectPickerRow(
            name=raw_picker_text("播放这个动作包" if linked_object_style_mode else "设置这个动作包的联动"),
            row_description=raw_picker_text("下面的动作会直接播放" if linked_object_style_mode else "进入后，点动作会打开联动设置页"),
            icon=MANAGE_ICON,
            tag="FGEH_LINKED_SET_PLAY_MODE" if linked_object_style_mode else "FGEH_LINKED_SET_SETTING_MODE"
        )
        if selected_group_name == LINKED_GROUPED_ENTRY_NAME:
            refs = get_linked_grouped_pose_refs(selected_group_type, selected_pack_id, selected_grouped_pose_group_name)
        else:
            refs = get_linked_pack_pose_refs(selected_group_type, selected_group_name, selected_pack_id)
        if not refs:
            yield ObjectPickerRow(
                name=raw_picker_text("这个动作包暂无联动动作"),
                row_description=raw_picker_text("如果是整包联动，检查动作包里是否能读到 pose_list"),
                icon=MANAGE_ICON,
                tag="FGEH_LINKED_NOOP"
            )
            return
        if selected_group_name == LINKED_GROUPED_ENTRY_NAME and selected_grouped_pose_group_name:
            yield ObjectPickerRow(
                name=raw_picker_text("一键播放当前小人组"),
                row_description=raw_picker_text("把这个小人组里的联动动作按顺序加入队列"),
                count=len(refs),
                icon=PLAY_ICON,
                tag=LINKED_PLAY_CURRENT_GROUP_TAG
            )

        selected_pack = state.all_packs_cache.get(selected_pack_id)
        pose_items_by_name = {}
        for candidate in getattr(selected_pack, 'pose_list', []) or []:
            candidate_pose_name = getattr(candidate, 'pose_name', None)
            if candidate_pose_name:
                pose_items_by_name[str(candidate_pose_name)] = candidate

        for ref in refs:
            pack_id, pose_name = linked_pose_ref_key(ref)
            pack = selected_pack if str(pack_id or "") == str(selected_pack_id or "") else state.all_packs_cache.get(pack_id)
            pose_item = pose_items_by_name.get(str(pose_name or ""))
            if pose_item is None and pack is not selected_pack:
                for candidate in getattr(pack, 'pose_list', []) or []:
                    if getattr(candidate, 'pose_name', None) == pose_name:
                        pose_item = candidate
                        break
            if not pack or not pose_item:
                continue
            pack_name = get_visible_pack_name(pack, get_stbl_text(STR_UI_UNNAMED_PACK))
            yield ObjectPickerRow(
                name=get_visible_pose_name(pose_item),
                row_description=raw_picker_text("进入后设置这个动作的 CAS / 物体联动") if linked_object_style_mode else pack_name,
                icon=getattr(pose_item, 'icon', MY_CUSTOM_ICON),
                tag=linked_object_style_pose_tag(pack_id, pose_name) if linked_object_style_mode else linked_action_tag(selected_group_type, pack_id, pose_name)
            )
        return

    if pack_type == 'GROUPED_PACKS':
        if not state.cache_built: build_cache_safe()
        
        if state.g_view_mode not in (GroupMode.LIST, GroupMode.DELETE_PACK, GroupMode.CREATOR_PACKS, GroupMode.FAV_GROUP_PLAY, GroupMode.FAV_GROUP_MANAGE, GroupMode.FAV_GROUP_EDIT):
            state.g_view_mode = GroupMode.LIST
            state.came_from_grouped = False

        if state.g_view_mode == GroupMode.LIST:
            yield RowFactory.create_button(STR_BTN_DELETE_MODE, MANAGE_ICON, "BTN_GROUPED_DELETE_MODE", STR_P_BTN_DELETE_DESC)
            
            if state.grouped_view_toggle == 0: view_status_id = STR_G_VIEW_ALL
            elif state.grouped_view_toggle == 1: view_status_id = STR_G_VIEW_CREATOR
            else: view_status_id = STR_F_VIEW_GROUP
            yield RowFactory.create_button_with_params(STR_G_BTN_TOGGLE_VIEW, SWITCH_ICON, "BTN_G_TOGGLE_VIEW", None, get_stbl_text(view_status_id))

            if state.grouped_view_toggle == 1:
                creator_dict = {}
                for pck_id in state.grouped_packs.keys():
                    pck = state.all_packs_cache.get(pck_id)
                    if pck:
                        found_creator = "Unknown"
                        for c_name, pcks in state.all_creators_cache.items():
                            if pck in pcks: found_creator = c_name; break
                        if found_creator not in creator_dict: creator_dict[found_creator] = []
                        creator_dict[found_creator].append(pck_id)

                for c_name in sorted(creator_dict.keys(), key=lambda x: str(x).lower()):
                    count = len(creator_dict[c_name])
                    c_name_stbl = STR_DYN_CREATOR_STAR if c_name in state.favorite_creators else STR_DYN_CREATOR_NO_STAR
                    yield RowFactory.create_button_with_params(c_name_stbl, CREATOR2_ICON, f"G_CREATOR::{c_name}", None, c_name, count)
            
            elif state.grouped_view_toggle == 2:
                yield RowFactory.create_button(STR_F_BTN_FAV_GROUPS_MANAGE, MANAGE_ICON, "BTN_G_F_GROUP_MANAGE")
                for grp_name in sorted(state.user_grouped_packs_groups.keys()):
                    valid_packs = [p for p in state.user_grouped_packs_groups[grp_name] if p in state.grouped_packs and state.all_packs_cache.get(p)]
                    count = len(valid_packs)
                    yield RowFactory.create_button_with_params(STR_F_DYN_PLAY_GRP, FOlDER_ICON, f"G_F_PLAY_GRP::{grp_name}", None, str(grp_name), count)
            
            else:
                grp_packs_sorted = []
                for pck_id in state.grouped_packs.keys():
                    pck = state.all_packs_cache.get(pck_id)
                    if pck:
                        pack_tuple = get_visible_pack_tuple(pck_id, pck)
                        if pack_tuple is not None:
                            grp_packs_sorted.append(pack_tuple)
                grp_packs_sorted.sort(key=lambda x: str(x[1]).lower())
                for pck_name, pck_id, pck in grp_packs_sorted:
                    yield RowFactory.create_pack_row(pck_name, pck_id, pck, "G_SELECT::")

        elif state.g_view_mode == GroupMode.FAV_GROUP_PLAY:
            yield RowFactory.create_button(STR_G_BTN_RETURN_LIST, RETURN_ICON, "BTN_GROUPED_RETURN_LIST")
            grp_packs_sorted = []
            for pck_id in state.user_grouped_packs_groups.get(state.selected_fav_group, []):
                if pck_id in state.grouped_packs:
                    pck = state.all_packs_cache.get(pck_id)
                    if pck:
                        pack_tuple = get_visible_pack_tuple(pck_id, pck)
                        if pack_tuple is not None:
                            grp_packs_sorted.append(pack_tuple)
            grp_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in grp_packs_sorted:
                yield RowFactory.create_pack_row(pck_name, pck_id, pck, "G_SELECT::")

        elif state.g_view_mode == GroupMode.FAV_GROUP_MANAGE:
            yield RowFactory.create_button(STR_P_BTN_RETURN, RETURN_ICON, "BTN_GROUPED_RETURN_LIST")
            yield RowFactory.create_button(STR_F_BTN_ADD_GROUP, ADD_ICON, "BTN_G_F_ADD_GROUP")
            for grp_name in sorted(state.user_grouped_packs_groups.keys()):
                valid_packs = [p for p in state.user_grouped_packs_groups[grp_name] if p in state.grouped_packs and state.all_packs_cache.get(p)]
                yield RowFactory.create_button_with_params(STR_F_DYN_EDIT_RENAME, FOlDER_ICON, f"G_F_EDIT_GRP::{grp_name}", None, str(grp_name), len(valid_packs))
                yield RowFactory.create_button_with_params(STR_F_DYN_DEL_GRP, FOlDER_ICON, f"G_F_DEL_GRP::{grp_name}", None, str(grp_name))

        elif state.g_view_mode == GroupMode.FAV_GROUP_EDIT:
            yield RowFactory.create_button(STR_G_BTN_RETURN_SELECT, FOlDER_ICON, "BTN_G_F_GROUP_MANAGE")
            yield RowFactory.create_button(STR_F_BTN_RENAME_CURRENT, RENAME_ICON, f"G_F_RENAME_GRP::{state.selected_fav_group}")
            
            all_grp_packs_sorted = []
            for pck_id in state.grouped_packs.keys():
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    pack_tuple = get_visible_pack_tuple(pck_id, pck)
                    if pack_tuple is not None:
                        all_grp_packs_sorted.append(pack_tuple)
            all_grp_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            
            grp_packs = state.user_grouped_packs_groups.get(state.selected_fav_group, []) 
            for pck_name, pck_id, pck in all_grp_packs_sorted:
                stbl_id = STR_G_DYN_STAR_ITEM if pck_id in grp_packs else STR_G_DYN_NO_STAR_ITEM
                yield RowFactory.create_button_with_params(stbl_id, getattr(pck, 'icon', MY_CUSTOM_ICON), f"G_F_TOGGLE_PACK::{pck_id}", None, pck_name)

        elif state.g_view_mode == GroupMode.CREATOR_PACKS:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_LIST), icon=RETURN_ICON, tag="BTN_GROUPED_RETURN_LIST")
            creator_packs_sorted = []
            for pck_id in state.grouped_packs.keys():
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    found_creator = "Unknown"
                    for c_name, pcks in state.all_creators_cache.items():
                        if pck in pcks: found_creator = c_name; break
                    if found_creator == state.selected_group_creator:
                        pack_tuple = get_visible_pack_tuple(pck_id, pck)
                        if pack_tuple is not None:
                            creator_packs_sorted.append(pack_tuple)
            creator_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in creator_packs_sorted:
                yield RowFactory.create_pack_row(pck_name, pck_id, pck, "G_SELECT::")

        elif state.g_view_mode == GroupMode.DELETE_PACK:
            yield RowFactory.create_button(STR_G_BTN_RETURN_REMOVE, RETURN_ICON, "BTN_GROUPED_RETURN_LIST")
            del_grp_packs = []
            for pck_id in state.grouped_packs.keys():
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    pack_tuple = get_visible_pack_tuple(pck_id, pck)
                    if pack_tuple is not None:
                        del_grp_packs.append(pack_tuple)
            del_grp_packs.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in del_grp_packs:
                yield RowFactory.create_delete_pack_row(pck_name, pck_id, pck, "G_DEL_PACK::")
        return

    # ✨ ==========================================
    # 普通包视图：增加【分配到大组】恢复
    # ==========================================
    if state.came_from_grouped and pack_type == 'NORMAL':
        pack_id = str(getattr(pack, '__name__', 'Unknown'))
        if pack_id not in state.grouped_packs: state.grouped_packs[pack_id] = {}; save_favorites()

        if state.g_view_mode not in (GroupMode.PACK_HOME, GroupMode.PLAY_GROUP, GroupMode.PACK_MANAGE, GroupMode.EDIT_GROUP, GroupMode.ASSIGN_MACRO_GROUPS):
            state.g_view_mode = GroupMode.PACK_HOME

        if state.g_view_mode == GroupMode.PACK_HOME:
            yield RowFactory.create_button(STR_G_BTN_RETURN_LIST, MY_CUSTOM_ICON, "RETURN_TO_GROUPED_LIST")
            yield RowFactory.create_button(STR_G_BTN_MANAGE_HOME, MANAGE_ICON, "G_BTN_MANAGE_HOME", STR_G_BTN_MANAGE_DESC)
            
            yield RowFactory.create_button(STR_G_BTN_ASSIGN_MACRO_GROUPS, MANAGE_ICON, "BTN_G_ASSIGN_MACRO_GROUPS", STR_G_DESC_ASSIGN_MACRO_GROUPS)

            for grp_name in sorted(state.grouped_packs[pack_id].keys()):
                yield RowFactory.create_button_with_params(STR_G_DYN_PLAY_GRP, FOlDER_ICON, f"G_PLAY_GRP::{grp_name}", None, str(grp_name), len(state.grouped_packs[pack_id][grp_name]))
                
        elif state.g_view_mode == GroupMode.PLAY_GROUP:
            yield RowFactory.create_button(STR_G_BTN_RETURN_UP, RETURN_ICON, "G_BTN_BACK_TO_HOME")
            yield RowFactory.create_button(STR_G_BTN_PLAY_ALL, PLAY_ICON, "G_PLAY_ALL_IN_GROUP", STR_G_DESC_PLAY_ALL)
            
            import services
            current_target = target
            custom_target_id = getattr(inst, 'fgeh_custom_target_id', None)
            if custom_target_id:
                found_sim = services.object_manager().get(custom_target_id)
                if found_sim: current_target = found_sim
            target_name = getattr(current_target, 'first_name', "未知")
            
            yield ObjectPickerRow(
                name=get_stbl_text(STR_G_BTN_SWITCH_TARGET), 
                row_description=get_stbl_text(STR_G_DESC_SWITCH_TARGET, target_name), 
                icon=CHOOSESIMS_ICON, 
                tag="BTN_SELECT_OTHER_SIM"
            )
            
            valid_poses = state.grouped_packs[pack_id].get(state.selected_group, [])
            for pose_item in getattr(pack, 'pose_list', []):
                if getattr(pose_item, 'pose_name', None) in valid_poses:
                    if should_hide_pose_entry(pose_item):
                        continue
                    yield RowFactory.create_pose_row(pose_item)

        elif state.g_view_mode == GroupMode.PACK_MANAGE:
            yield RowFactory.create_button(STR_G_BTN_RETURN_SETTING, RETURN_ICON, "G_BTN_BACK_TO_HOME")
            yield RowFactory.create_button(STR_G_BTN_AUTO_SORT, CHOOSESIMS_ICON, "G_BTN_AUTO_SORT", STR_G_BTN_AUTO_DESC)
            yield RowFactory.create_button(STR_G_BTN_ADD_GROUP, ADD_ICON, "G_BTN_ADD_GROUP")
            
            for grp_name in sorted(state.grouped_packs[pack_id].keys()):
                yield RowFactory.create_button_with_params(STR_G_DYN_EDIT_RENAME_GRP, FOlDER_ICON, f"G_EDIT_GRP::{grp_name}", None, str(grp_name), len(state.grouped_packs[pack_id][grp_name]))
                yield RowFactory.create_button_with_params(STR_G_DYN_DEL_GRP, DELETE_ICON, f"G_DEL_GRP::{grp_name}", None, str(grp_name))
                
        elif state.g_view_mode == GroupMode.EDIT_GROUP:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_SELECT), icon=RETURN_ICON, tag="G_BTN_BACK_TO_MANAGE")
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RENAME_CURRENT), icon=RENAME_ICON, tag=f"G_RENAME_GRP::{state.selected_group}")
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_TOGGLE_ALL), icon=SWITCH_ICON, tag="G_BTN_TOGGLE_ALL")
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_PATTERN_MATCH), row_description=get_stbl_text(STR_G_PATTERN_DESC), icon=CHOOSESIMS_ICON, tag="G_BTN_PATTERN_MATCH")

            grp_poses = state.grouped_packs[pack_id].get(state.selected_group, [])
            for pose_item in getattr(pack, 'pose_list', []):
                p_name = getattr(pose_item, 'pose_name', None)
                if should_hide_pose_entry(pose_item):
                    continue
                stbl_id = STR_G_DYN_STAR_ITEM if p_name in grp_poses else STR_G_DYN_NO_STAR_ITEM
                yield ObjectPickerRow(name=get_stbl_text(stbl_id, get_visible_pose_name(pose_item)), icon=pose_item.icon, tag=f"G_TOGGLE_POSE::{p_name}")

        elif state.g_view_mode == GroupMode.ASSIGN_MACRO_GROUPS:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_UP), icon=RETURN_ICON, tag="G_BTN_BACK_TO_HOME")
            yield ObjectPickerRow(
                name=get_stbl_text(STR_G_BTN_MACRO_ADD_GROUP), 
                icon=ADD_ICON, 
                tag="BTN_G_MACRO_ADD_GROUP"
            )
            
            for grp_name in sorted(state.user_grouped_packs_groups.keys()):
                is_in_group = pack_id in state.user_grouped_packs_groups[grp_name]
                stbl_id = STR_G_DYN_STAR_ITEM if is_in_group else STR_G_DYN_NO_STAR_ITEM
                yield ObjectPickerRow(
                    name=get_stbl_text(stbl_id, grp_name), 
                    icon=FOlDER_ICON, 
                    tag=f"G_ASSIGN_TOGGLE::{grp_name}"
                )
        return

    # ==========================================
    # 收藏动作包层级 (全面支持三态视图与收藏组管理)
    # ==========================================
    if pack_type == 'FAV_PACKS':
        if not state.cache_built: build_cache_safe()
        
        # 1. 主页面分发：三态视图
        if state.p_view_mode == FavPackMode.FAVS:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_MANAGE), row_description=get_stbl_text(STR_P_BTN_MANAGE_DESC), icon=MANAGE_ICON, tag="BTN_FAV_PACKS_MANAGE")
            
            if state.fav_packs_view_toggle == 0: view_status_id = STR_G_VIEW_ALL
            elif state.fav_packs_view_toggle == 1: view_status_id = STR_G_VIEW_CREATOR
            else: view_status_id = STR_F_VIEW_GROUP
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_TOGGLE_VIEW, get_stbl_text(view_status_id)), icon=SWITCH_ICON, tag="BTN_P_TOGGLE_VIEW")

            if state.fav_packs_view_toggle == 1:
                creator_dict = {}
                for pck_id in state.favorite_packs:
                    pck = state.all_packs_cache.get(pck_id)
                    if pck:
                        found_creator = "Unknown"
                        for c_name, pcks in state.all_creators_cache.items():
                            if pck in pcks: found_creator = c_name; break
                        if found_creator not in creator_dict: creator_dict[found_creator] = []
                        creator_dict[found_creator].append(pck_id)

                for c_name in sorted(creator_dict.keys(), key=lambda x: str(x).lower()):
                    count = len(creator_dict[c_name])
                    c_name_stbl = STR_DYN_CREATOR_STAR if c_name in state.favorite_creators else STR_DYN_CREATOR_NO_STAR
                    yield ObjectPickerRow(name=get_stbl_text(c_name_stbl, c_name, count), icon=CREATOR2_ICON, tag=f"P_CREATOR::{c_name}")
            
            elif state.fav_packs_view_toggle == 2:
                yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_FAV_GROUPS_MANAGE), icon=MANAGE_ICON, tag="BTN_F_GROUP_MANAGE")
                for grp_name in sorted(state.user_fav_groups.keys()):
                    valid_packs = [p for p in state.user_fav_groups[grp_name] if p in state.favorite_packs and state.all_packs_cache.get(p)]
                    count = len(valid_packs)
                    yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_PLAY_GRP, str(grp_name), count), icon=FOlDER_ICON, tag=f"F_PLAY_GRP::{grp_name}")

            else:
                fav_packs_sorted = []
                for pck_id in state.favorite_packs:
                    pck = state.all_packs_cache.get(pck_id)
                    if pck:
                        pack_tuple = get_visible_pack_tuple(pck_id, pck)
                        if pack_tuple is not None:
                            fav_packs_sorted.append(pack_tuple)
                fav_packs_sorted.sort(key=lambda x: str(x[1]).lower())
                for pck_name, pck_id, pck in fav_packs_sorted:
                    yield ObjectPickerRow(name=pck_name, row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"P_SELECT::{pck_id}")

        # 2. 自定义收藏组 - 游玩层
        elif state.p_view_mode == FavPackMode.GROUP_PLAY:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_LIST), icon=RETURN_ICON, tag="BTN_FAV_PACKS_RETURN")
            grp_packs_sorted = []
            for pck_id in state.user_fav_groups.get(state.selected_fav_group, []):
                if pck_id not in state.favorite_packs: continue
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    pack_tuple = get_visible_pack_tuple(pck_id, pck)
                    if pack_tuple is not None:
                        grp_packs_sorted.append(pack_tuple)
            grp_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in grp_packs_sorted:
                yield ObjectPickerRow(name=pck_name, row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"P_SELECT::{pck_id}")

        # 3. 自定义收藏组 - 管理层
        elif state.p_view_mode == FavPackMode.GROUP_MANAGE:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_FAV_PACKS_RETURN")
            yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_ADD_GROUP), icon=ADD_ICON, tag="BTN_F_ADD_GROUP")
            for grp_name in sorted(state.user_fav_groups.keys()):
                valid_packs = [p for p in state.user_fav_groups[grp_name] if p in state.favorite_packs and state.all_packs_cache.get(p)]
                yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_EDIT_RENAME, str(grp_name)), count=len(valid_packs), icon=RENAME_ICON, tag=f"F_EDIT_GRP::{grp_name}")
                yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_DEL_GRP, str(grp_name)), icon=DELETE_ICON, tag=f"F_DEL_GRP::{grp_name}")

        # 4. 自定义收藏组 - 编辑/分配层
        elif state.p_view_mode == FavPackMode.GROUP_EDIT:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_SELECT), icon=RETURN_ICON, tag="BTN_F_GROUP_MANAGE")
            yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_RENAME_CURRENT), icon=RENAME_ICON, tag=f"F_RENAME_GRP::{state.selected_fav_group}")
            
            all_fav_packs_sorted = []
            for pck_id in state.favorite_packs:
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    pack_tuple = get_visible_pack_tuple(pck_id, pck)
                    if pack_tuple is not None:
                        all_fav_packs_sorted.append(pack_tuple)
            all_fav_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            
            grp_packs = state.user_fav_groups.get(state.selected_fav_group, [])
            for pck_name, pck_id, pck in all_fav_packs_sorted:
                stbl_id = STR_G_DYN_STAR_ITEM if pck_id in grp_packs else STR_G_DYN_NO_STAR_ITEM
                yield ObjectPickerRow(name=get_stbl_text(stbl_id, pck_name), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"F_TOGGLE_PACK::{pck_id}")

        # 5. 原有的作者点击进入后的视图
        elif state.p_view_mode == FavPackMode.CREATOR_PACKS:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_LIST), icon=RETURN_ICON, tag="BTN_FAV_PACKS_RETURN")
            creator_packs_sorted = []
            for pck_id in state.favorite_packs:
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    found_creator = "Unknown"
                    for c_name, pcks in state.all_creators_cache.items():
                        if pck in pcks: found_creator = c_name; break
                    if found_creator == state.selected_fav_creator:
                        pack_tuple = get_visible_pack_tuple(pck_id, pck)
                        if pack_tuple is not None:
                            creator_packs_sorted.append(pack_tuple)
            creator_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in creator_packs_sorted:
                yield ObjectPickerRow(name=pck_name, row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"P_SELECT::{pck_id}")

        # 6. 管理所有包页面
        elif state.p_view_mode == FavPackMode.MANAGE:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_FAV_PACKS_RETURN")
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_CLEAR), row_description=get_stbl_text(STR_P_BTN_CLEAR_DESC), icon=RETURN_ICON, tag="BTN_FAV_PACKS_CLEAR")
            yield ObjectPickerRow(name=get_stbl_text(STR_BTN_DELETE_MODE), row_description=get_stbl_text(STR_P_BTN_DELETE_DESC), icon=MANAGE_ICON, tag="BTN_FAV_PACKS_DELETE_MODE")
            
            all_packs_sorted = []
            for pck_id, pck in state.all_packs_cache.items():
                pack_tuple = get_visible_pack_tuple(pck_id, pck)
                if pack_tuple is not None:
                    all_packs_sorted.append(pack_tuple)
            all_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in all_packs_sorted:
                yield ObjectPickerRow(name=pck_name, row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"P_TOGGLE::{pck_id}")

        elif state.p_view_mode == FavPackMode.DELETE:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_FAV_PACKS_RETURN_TO_MANAGE")
            del_packs_sorted = []
            for pck_id in state.favorite_packs:
                pck = state.all_packs_cache.get(pck_id)
                if pck:
                    pack_tuple = get_visible_pack_tuple(pck_id, pck)
                    if pack_tuple is not None:
                        del_packs_sorted.append(pack_tuple)
            del_packs_sorted.sort(key=lambda x: str(x[1]).lower())
            for pck_name, pck_id, pck in del_packs_sorted:
                yield ObjectPickerRow(name=get_stbl_text(STR_DYN_DELETE_ITEM, pck_name), row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"P_DELETE::{pck_id}")
        return

    # ==========================================
    # 以下为剩余收藏模块 (保持不变)
    # ==========================================
    if pack_type == 'CREATORS':
        if not state.cache_built: build_cache_safe()

        if state.c_view_mode == CreatorMode.FAVS:
            yield ObjectPickerRow(name=get_stbl_text(STR_C_BTN_ADD), icon=ADD_ICON, tag="BTN_ALL_CREATORS")
            yield ObjectPickerRow(name=get_stbl_text(STR_BTN_DELETE_MODE), row_description=get_stbl_text(STR_C_BTN_DELETE_DESC), icon=MANAGE_ICON, tag="BTN_CREATORS_DELETE_MODE")
            if not state.favorite_creators:
                yield ObjectPickerRow(name=get_stbl_text(STR_C_EMPTY), icon=FOlDER_ICON)
            else:
                # ✨ 新增：按自定义别名排序！
                sorted_creators = sorted(state.favorite_creators, key=lambda c: get_display_name(c, "creator_").lower())
                
                for creator in sorted_creators:
                    if creator in state.all_creators_cache:
                        count = len(state.all_creators_cache[creator])
                        
                        # ✨ 获取别名并显示
                        display_name = get_display_name(creator, "creator_")
                        
                        yield ObjectPickerRow(
                            name=get_stbl_text(STR_DYN_CREATOR_FAVED, display_name, count), 
                            icon=CREATOR2_ICON, 
                            tag=f"C_VIEW::{creator}"
                        )

        elif state.c_view_mode == CreatorMode.ALL:
            yield ObjectPickerRow(name=get_stbl_text(STR_C_BTN_RETURN_LIST), icon=RETURN_ICON, tag="BTN_RETURN_FAV_CREATORS")
            for creator in sorted(state.all_creators_cache.keys()):
                count = len(state.all_creators_cache[creator])
                c_name_stbl = STR_DYN_CREATOR_STAR if creator in state.favorite_creators else STR_DYN_CREATOR_NO_STAR
                yield ObjectPickerRow(name=get_stbl_text(c_name_stbl, creator, count), icon=CREATOR2_ICON, tag=f"C_TOGGLE::{creator}")

        elif state.c_view_mode == CreatorMode.PACKS:
            
            yield ObjectPickerRow(name=get_stbl_text(STR_C_BTN_RETURN_FAVS), icon=RETURN_ICON, tag="BTN_RETURN_FAV_CREATORS")
            current_display_name = get_display_name(state.selected_creator, "creator_")
            yield ObjectPickerRow(
                name=get_stbl_text(STR_C_DYN_EDIT_RENAME, current_display_name), # 复用了你现有的重命名文本ID
                row_description=get_stbl_text(STR_GS_RENAME_EMPTY_RESTORE_DESC),
                icon=RENAME_ICON, 
                tag=f"BTN_RENAME_CREATOR::{state.selected_creator}"
            )
            packs = state.all_creators_cache.get(state.selected_creator, [])
            packs_sorted = sorted(packs, key=lambda x: str(getattr(x, 'display_name', getattr(x, 'sort_name', ''))).lower())
            for pck in packs_sorted:
                if should_hide_pack_entry(pck):
                    continue
                idx = packs.index(pck)
                pck_name = get_visible_pack_name(pck)
                yield ObjectPickerRow(name=pck_name, row_description=getattr(pck, 'description', None), count=len(getattr(pck, 'pose_list', [])), icon=getattr(pck, 'icon', MY_CUSTOM_ICON), tag=f"CREATOR_PACK::{state.selected_creator}::{idx}")

        elif state.c_view_mode == CreatorMode.DELETE:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_CREATORS_RETURN_FAVS")
            for creator in sorted(state.favorite_creators):
                yield ObjectPickerRow(name=get_stbl_text(STR_DYN_DELETE_ITEM, creator), icon=CREATOR2_ICON, tag=f"C_DELETE::{creator}")
        return

    # ==========================================
    # 【全新升级】单独动作收藏 (增加了自定义分组功能)
    # ==========================================
    if pack_type == 'POSES':
        if not state.cache_built: build_cache_safe()
        
        if state.s_view_mode == FavPoseMode.PLAY:
            yield ObjectPickerRow(name=get_stbl_text(STR_DYN_TOGGLE_MODE_1, current_mode_str), row_description=get_stbl_text(STR_DYN_TOGGLE_MODE_1_DESC), icon=SWITCH_ICON, tag="TOGGLE_MODE_BTN")
            yield ObjectPickerRow(name=get_stbl_text(STR_S_BTN_CLEAR), row_description=get_stbl_text(STR_S_BTN_CLEAR_DESC), icon=DELETE_ICON, tag="CLEAR_ALL_FAV_BTN")

            view_status_id = STR_F_VIEW_GROUP if state.fav_poses_view_toggle == 1 else STR_G_VIEW_ALL
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_TOGGLE_VIEW, get_stbl_text(view_status_id)), icon=SWITCH_ICON, tag="BTN_S_TOGGLE_VIEW")

            if state.fav_poses_view_toggle == 1:
                yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_FAV_GROUPS_MANAGE), icon=MANAGE_ICON, tag="BTN_S_GROUP_MANAGE")
                for grp_name in sorted(state.user_fav_pose_groups.keys()):
                    valid_poses = [p for p in state.user_fav_pose_groups[grp_name] if p in state.favorite_poses and state.all_poses_cache.get(p)]
                    count = len(valid_poses)
                    yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_PLAY_GRP, str(grp_name), count), icon=FOlDER_ICON, tag=f"S_PLAY_GRP::{grp_name}")
            
            else:
                if not state.favorite_poses:
                    yield ObjectPickerRow(name=get_stbl_text(STR_S_EMPTY), icon=FOlDER_ICON)
                else:
                    fav_display_list = [state.all_poses_cache.get(p) for p in state.favorite_poses if 'fgeh' not in str(p).lower() and state.all_poses_cache.get(p)]
                    fav_display_list.sort(key=lambda x: x['pack_name'])
                    for item in fav_display_list:
                        p = item['pose']
                        if should_hide_pose_entry(p):
                            continue
                        yield ObjectPickerRow(name=get_visible_pose_name(p), icon=p.icon, row_description=p.pose_description, tag=p)

        elif state.s_view_mode == FavPoseMode.GROUP_PLAY:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_S_RETURN_MAIN")
            valid_poses = [p for p in state.user_fav_pose_groups.get(state.selected_fav_pose_group, []) if p in state.favorite_poses]
            fav_display_list = [state.all_poses_cache.get(p) for p in valid_poses if state.all_poses_cache.get(p)]
            fav_display_list.sort(key=lambda x: x['pack_name'])
            for item in fav_display_list:
                p = item['pose']
                if should_hide_pose_entry(p):
                    continue
                yield ObjectPickerRow(name=get_visible_pose_name(p), icon=p.icon, row_description=p.pose_description, tag=p)

        elif state.s_view_mode == FavPoseMode.GROUP_MANAGE:
            yield ObjectPickerRow(name=get_stbl_text(STR_P_BTN_RETURN), icon=RETURN_ICON, tag="BTN_S_RETURN_MAIN")
            yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_ADD_GROUP), icon=ADD_ICON, tag="BTN_S_ADD_GROUP")
            for grp_name in sorted(state.user_fav_pose_groups.keys()):
                valid_poses = [p for p in state.user_fav_pose_groups[grp_name] if p in state.favorite_poses and state.all_poses_cache.get(p)]
                yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_EDIT_RENAME, str(grp_name)), count=len(valid_poses), icon=MANAGE_ICON, tag=f"S_EDIT_GRP::{grp_name}")
                yield ObjectPickerRow(name=get_stbl_text(STR_F_DYN_DEL_GRP, str(grp_name)), icon=DELETE_ICON, tag=f"S_DEL_GRP::{grp_name}")

        elif state.s_view_mode == FavPoseMode.GROUP_EDIT:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_RETURN_SELECT), icon=RETURN_ICON, tag="BTN_S_GROUP_MANAGE")
            yield ObjectPickerRow(name=get_stbl_text(STR_F_BTN_RENAME_CURRENT), icon=RENAME_ICON, tag=f"S_RENAME_GRP::{state.selected_fav_pose_group}")

            grp_poses = state.user_fav_pose_groups.get(state.selected_fav_pose_group, [])
            fav_display_list = [state.all_poses_cache.get(p) for p in state.favorite_poses if state.all_poses_cache.get(p)]
            fav_display_list.sort(key=lambda x: x['pack_name'])
            for item in fav_display_list:
                p = item['pose']
                p_name = p.pose_name
                if should_hide_pose_entry(p):
                    continue
                stbl_id = STR_G_DYN_STAR_ITEM if p_name in grp_poses else STR_G_DYN_NO_STAR_ITEM
                yield ObjectPickerRow(name=get_stbl_text(stbl_id, get_visible_pose_name(p)), icon=p.icon, tag=f"S_TOGGLE_POSE::{p_name}")

        return

    if state.return_to_fav_on_close and pack == state.global_traced_pack_ref:
        yield ObjectPickerRow(name=get_stbl_text(STR_N_RETURN_TO_POSES), icon=RETURN_ICON, tag="RETURN_TO_FAV_BTN")

    if state.came_from_l1_favs:
        yield ObjectPickerRow(name=get_stbl_text(STR_N_RETURN_TO_PACKS), icon=RETURN_ICON, tag="RETURN_TO_FAV_PACKS_MENU_BTN")

    if state.came_from_creator and state.selected_creator:
        yield ObjectPickerRow(name=get_stbl_text(STR_DYN_RETURN_CREATOR, state.selected_creator), icon=RETURN_ICON, tag="RETURN_TO_CREATOR_PACKS_BTN")

    # ==========================================
    # ✨ 核心：UI 收纳系统 (普通包层级判定)
    # ==========================================
    if state.is_in_normal_pack_manage_mode:
        # 🟢 方案启动：如果玩家点击了“分组与收藏管理”，则进入这里的【第二层】
        yield ObjectPickerRow(
            name=get_stbl_text(STR_BTN_EXIT_NORMAL_MANAGE), 
            icon=RETURN_ICON, 
            tag="BTN_EXIT_NORMAL_MANAGE"
        )
        
        pack_id = str(getattr(pack, '__name__', 'Unknown'))
        is_pack_faved = pack_id in state.favorite_packs
        is_grouped = pack_id in state.grouped_packs
        
        # 按钮1：加入动作分组器
        grp_btn_id = STR_G_BTN_REMOVE_PACK if is_grouped else STR_G_BTN_ADD_PACK
        yield ObjectPickerRow(name=get_stbl_text(grp_btn_id), row_description=get_stbl_text(STR_G_PACK_DESC), icon=FOlDER_ICON, tag="TOGGLE_GROUPED_PACK_ONLY_BTN")
        
        # 按钮2：虫洞跳转（只在已加入分组时显示）
        if is_grouped:
            yield ObjectPickerRow(name=get_stbl_text(STR_G_BTN_WORMHOLE), row_description=get_stbl_text(STR_G_WORMHOLE_DESC), icon=SWITCH_ICON, tag="BTN_G_WORMHOLE_JUMP")

        names = [p.pose_name for p in getattr(pack, 'pose_list', []) if hasattr(p, 'pose_name')]
        is_all_poses_faved = bool(names) and all(n in state.favorite_poses for n in names)

        # 按钮3：全部收藏到动作包
        pack_btn_id = STR_N_REMOVE_PACK if is_pack_faved else STR_N_ADD_PACK
        yield ObjectPickerRow(name=get_stbl_text(pack_btn_id), row_description=get_stbl_text(STR_N_PACK_DESC), icon=CREATOR2_ICON, tag="TOGGLE_FAV_PACK_ONLY_BTN")
        
        # 按钮4：全部收藏到动作夹
        pose_btn_id = STR_N_REMOVE_ALL_POSES if is_all_poses_faved else STR_N_ADD_ALL_POSES
        yield ObjectPickerRow(name=get_stbl_text(pose_btn_id), row_description=get_stbl_text(STR_N_ALL_POSES_DESC), icon=CREATOR2_ICON, tag="TOGGLE_FAV_ALL_POSES_ONLY_BTN")
        
        return # 🌟 核心拦截：在这里截断，不要往下画单个动作列表了！

    else:
        # 🟢 如果不是管理模式，则显示【第一层】(正常的游玩界面)
        import services
        current_target = target
        custom_target_id = getattr(inst, 'fgeh_custom_target_id', None)
        if custom_target_id:
            found_sim = services.object_manager().get(custom_target_id)
            if found_sim: current_target = found_sim
        target_name = getattr(current_target, 'first_name', "未知")
        
        # ✨ 完美替换：使用了动态参数注入小人名字
        yield ObjectPickerRow(
            name=get_stbl_text(STR_G_BTN_SWITCH_TARGET), 
            row_description=get_stbl_text(STR_G_DESC_SWITCH_TARGET, target_name), 
            icon=CHOOSESIMS_ICON, 
            tag="BTN_SELECT_OTHER_SIM"
        )

        yield ObjectPickerRow(name=get_stbl_text(STR_DYN_TOGGLE_MODE_2, current_mode_str), icon=SWITCH_ICON, tag="TOGGLE_MODE_BTN")

        # ✨ 魔法入口也换成了纯净的哈希引用
        yield ObjectPickerRow(
            name=get_stbl_text(STR_BTN_ENTER_NORMAL_MANAGE), 
            row_description=get_stbl_text(STR_DESC_ENTER_NORMAL_MANAGE), 
            icon=MANAGE_ICON, 
            tag="BTN_ENTER_NORMAL_MANAGE"
        )


        # 继续把所有的动作画出来
        for pose_item in getattr(pack, 'pose_list', []):
            if should_hide_pose_entry(pose_item):
                continue
            yield ObjectPickerRow(name=get_visible_pose_name(pose_item), icon=pose_item.icon, tag=pose_item)

# ==========================================
# 路由点击处理区
# ==========================================
original_pose_on_choice = poseplayer.PoseByPackNameInteraction.on_choice_selected


@injector2.inject(poseplayer.PoseByPackNameInteraction, '_on_picker_selected', safe=True)
def _fgeh_preserve_close_back_behavior(original, self, dialog, *args, **kwargs):
    try:
        choice_tags = dialog.get_result_tags()
    except:
        choice_tags = None
    if not any(choice_tags):
        state.suppress_next_history_restore = True
    return original(self, dialog, *args, **kwargs)

def custom_pose_on_choice(self, choice_tag, **kwargs):

    pack_type = get_pack_type(self.selected_pose_pack)

   #根据保存id获取对象
    import services
    actual_target = self.target
    custom_target_id = getattr(self, 'fgeh_custom_target_id', None)
    if custom_target_id:
        found_sim = services.object_manager().get(custom_target_id)
        if found_sim: actual_target = found_sim

    if isinstance(choice_tag, str) and choice_tag.startswith("ANDREW_POS::"):
        if POSITIONING_SYSTEM_ACTIVE and choice_tag != "ANDREW_POS::NOOP":
            handle_positioning_choice(self, choice_tag)
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    # ==========================================
    # 主菜单四个选项的处理 (核心路由)
    # ==========================================
    if choice_tag == "fgeh_grouped_folder":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "fgeh_grouped_folder"
        state.came_from_grouped = False
        state.g_view_mode = GroupMode.LIST
        state.grouped_view_toggle = 0
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    
    if choice_tag == "fgeh_fav_packs_folder":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "fgeh_fav_packs_folder"
        state.came_from_l1_favs = False
        state.p_view_mode = FavPackMode.FAVS
        state.fav_packs_view_toggle = 0
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == GLOBAL_SETTINGS_PACK_TOKEN:
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = GLOBAL_SETTINGS_PACK_TOKEN
        state.gs_view_mode = GlobalSettingsMode.MAIN
        state.global_settings_from_root = True
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    
    if choice_tag == "hegfcreator_folder":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "hegfcreator_folder"
        state.came_from_creator = False
        state.c_view_mode = CreatorMode.FAVS
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    
    if choice_tag == "fgeh_poses_folder":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "fgeh_poses_folder"
        state.s_view_mode = FavPoseMode.PLAY
        state.fav_poses_view_toggle = 0
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
#前四个按键
    if choice_tag == LINKED_ACTIONS_PACK_TOKEN:
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = LINKED_ACTIONS_PACK_TOKEN
        state.selected_linked_action_category = None
        state.selected_linked_group_type = None
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        state.linked_group_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUP_TYPE_PREFIX):
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = LINKED_ACTIONS_PACK_TOKEN
        state.selected_linked_group_type = choice_tag[len(LINKED_GROUP_TYPE_PREFIX):]
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        state.linked_group_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_OPEN_SETTINGS":
        self.selected_pose_pack = GLOBAL_SETTINGS_PACK_TOKEN
        state.gs_view_mode = GlobalSettingsMode.MAIN
        state.global_settings_from_root = True
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUP_PREFIX):
        state.selected_linked_group_name = choice_tag[len(LINKED_GROUP_PREFIX):]
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUPED_OUTER_PREFIX):
        state.selected_linked_grouped_outer_name = parse_linked_grouped_outer_tag(choice_tag)
        state.selected_linked_pack_id = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUPED_PACK_PREFIX):
        state.selected_linked_pack_id = parse_linked_grouped_pack_tag(choice_tag)
        state.selected_linked_grouped_pose_group_name = None
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUPED_POSE_GROUP_PREFIX):
        state.selected_linked_grouped_pose_group_name = parse_linked_grouped_pose_group_tag(choice_tag)
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_TOGGLE_GROUP_MANAGE":
        state.linked_group_manage_mode = not bool(getattr(state, 'linked_group_manage_mode', False))
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUP_DELETE_PREFIX):
        group_type = getattr(state, 'selected_linked_group_type', None) or "cas"
        group_name = parse_linked_group_action_tag(choice_tag, LINKED_GROUP_DELETE_PREFIX)
        groups = ensure_linked_groups_container(group_type)
        if group_name in groups:
            del groups[group_name]
            save_favorites()
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_GROUP_RENAME_PREFIX):
        group_type = getattr(state, 'selected_linked_group_type', None) or "cas"
        old_group_name = parse_linked_group_action_tag(choice_tag, LINKED_GROUP_RENAME_PREFIX)

        def do_rename_linked_group(new_name):
            new_name = str(new_name or "").strip()
            if not new_name:
                return
            groups = ensure_linked_groups_container(group_type)
            if old_group_name in groups and new_name not in groups:
                groups[new_name] = groups.pop(old_group_name)
                if getattr(state, 'selected_linked_group_name', None) == old_group_name:
                    state.selected_linked_group_name = new_name
                save_favorites()

        show_fgeh_rename_dialog(self, old_group_name, do_rename_linked_group)
        return

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_PACK_PREFIX):
        group_type, pack_id = parse_linked_pack_tag(choice_tag)
        state.selected_linked_group_type = group_type or getattr(state, 'selected_linked_group_type', None)
        if getattr(state, 'linked_manage_mode', False):
            state.selected_linked_assign_pack_id = pack_id
            state.selected_linked_pack_id = None
            return self._show_picker_dialog(self.sim, target_sim=actual_target)
        state.selected_linked_pack_id = pack_id
        state.selected_linked_grouped_pose_group_name = None
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_TOGGLE_MANAGE":
        state.linked_manage_mode = not bool(getattr(state, 'linked_manage_mode', False))
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_CREATE_GROUP_FOR_ASSIGN":
        group_type = getattr(state, 'selected_linked_group_type', None) or "cas"
        group_name = create_default_linked_group(group_type)
        pack_id = getattr(state, 'selected_linked_assign_pack_id', None)
        source_group = getattr(state, 'selected_linked_group_name', None) or LINKED_UNGROUPED_GROUP_NAME
        assign_linked_pack_to_group(group_type, source_group, pack_id, group_name)
        state.selected_linked_assign_pack_id = None
        state.linked_manage_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_ASSIGN_GROUP_PREFIX):
        group_type = getattr(state, 'selected_linked_group_type', None) or "cas"
        group_name = parse_linked_assign_group_tag(choice_tag)
        pack_id = getattr(state, 'selected_linked_assign_pack_id', None)
        source_group = getattr(state, 'selected_linked_group_name', None) or LINKED_UNGROUPED_GROUP_NAME
        assign_linked_pack_to_group(group_type, source_group, pack_id, group_name)
        state.selected_linked_assign_pack_id = None
        state.linked_manage_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_TYPES":
        state.selected_linked_group_type = None
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        state.linked_group_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_GROUPS":
        state.selected_linked_group_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        state.linked_group_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_GROUPED_OUTERS":
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_grouped_pose_group_name = None
        state.selected_linked_style_pose_name = None
        state.linked_object_style_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_GROUPED_PACKS":
        state.selected_linked_pack_id = None
        state.selected_linked_grouped_pose_group_name = None
        state.selected_linked_style_pose_name = None
        state.linked_object_style_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_GROUPED_POSE_GROUPS":
        state.selected_linked_grouped_pose_group_name = None
        state.selected_linked_style_pose_name = None
        state.linked_object_style_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_PACKS":
        if getattr(state, 'selected_linked_style_pose_name', None):
            state.selected_linked_style_pose_name = None
            state.selected_linked_requirement_folder = None
            state.selected_linked_requirement_asset_key = None
            return self._show_picker_dialog(self.sim, target_sim=actual_target)
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_style_pose_name = None
        state.selected_linked_requirement_folder = None
        state.selected_linked_requirement_asset_key = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_object_style_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_REQUIREMENT_SETTINGS":
        state.selected_linked_requirement_folder = None
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_OBJECT_REQUIREMENTS":
        state.selected_linked_requirement_folder = "object"
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_BACK_TO_REQUIREMENT_ITEMS":
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_TOGGLE_OBJECT_STYLE":
        state.linked_object_style_mode = not bool(getattr(state, 'linked_object_style_mode', False))
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_SET_PLAY_MODE":
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_SET_SETTING_MODE":
        state.linked_object_style_mode = True
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_TOGGLE_AUTO_APPLY":
        state.auto_apply_linked_requirements = not bool(getattr(state, "auto_apply_linked_requirements", True))
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_OBJECT_STYLE_POSE_PREFIX):
        pack_id, pose_name = parse_linked_object_style_pose_tag(choice_tag)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        state.selected_linked_requirement_folder = None
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_FOLDER_PREFIX):
        state.selected_linked_requirement_folder = parse_linked_setting_folder_tag(choice_tag)
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_ASSET_FOLDER_PREFIX):
        link_type, asset_key = parse_linked_setting_asset_folder_tag(choice_tag)
        state.selected_linked_requirement_folder = link_type or getattr(state, 'selected_linked_requirement_folder', None)
        state.selected_linked_requirement_asset_key = asset_key
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_AUTO_TOGGLE_PREFIX):
        link_type, pack_id, pose_name = parse_linked_setting_auto_toggle_tag(choice_tag)
        if link_type == "cas":
            set_linked_cas_apply_enabled(pack_id, pose_name, not is_linked_cas_apply_enabled(pack_id, pose_name))
        elif link_type == "object":
            set_linked_object_spawn_enabled(pack_id, pose_name, not is_linked_object_spawn_enabled(pack_id, pose_name))
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_APPLY_PACK_PREFIX):
        pack_id, pose_name = parse_linked_setting_apply_pack_tag(choice_tag)
        if (
            getattr(state, 'selected_linked_group_name', None) == LINKED_GROUPED_ENTRY_NAME
            and getattr(state, 'selected_linked_grouped_pose_group_name', None)
        ):
            refs = get_linked_grouped_pose_refs(
                getattr(state, 'selected_linked_group_type', None),
                pack_id,
                getattr(state, 'selected_linked_grouped_pose_group_name', None)
            )
            apply_linked_selection_to_current_group(pack_id, pose_name, refs)
        else:
            apply_linked_cas_selection_to_pack(pack_id, pose_name)
            apply_linked_object_selection_to_pack(pack_id, pose_name)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_SET_POSE_ALL_PREFIX):
        pack_id, pose_name, enabled = parse_linked_setting_set_pose_all_tag(choice_tag)
        set_all_linked_requirements_for_pose(pack_id, pose_name, enabled)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_RESTORE_CAS_PREFIX):
        pack_id, pose_name = parse_linked_setting_restore_cas_tag(choice_tag)
        set_linked_cas_restore_before_apply_enabled(
            pack_id,
            pose_name,
            not is_linked_cas_restore_before_apply_enabled(pack_id, pose_name)
        )
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        state.selected_linked_requirement_folder = None
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_HIDE_OBJECT_PREFIX):
        pack_id, pose_name, definition_id = parse_linked_setting_hide_object_tag(choice_tag)
        hide_linked_object_definition_id(pack_id, pose_name, definition_id)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_CLEAR_HIDDEN_OBJECTS_PREFIX):
        pack_id, pose_name = parse_linked_setting_clear_hidden_objects_tag(choice_tag)
        clear_hidden_linked_object_definition_ids(pack_id, pose_name)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        state.selected_linked_requirement_folder = "object"
        state.selected_linked_requirement_asset_key = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_ENABLE_ALL_PREFIX):
        link_type, pack_id, pose_name = parse_linked_setting_enable_all_tag(choice_tag)
        if link_type == "cas":
            set_linked_cas_apply_enabled(pack_id, pose_name, True)
            available_ids = []
            for option in get_linked_cas_variant_options(pack_id, pose_name):
                try:
                    item_id = int(option.get("cas_part_id") or 0)
                except:
                    item_id = 0
                if item_id:
                    available_ids.append(item_id)
            current_ids = get_enabled_linked_cas_part_ids(pack_id, pose_name, available_ids)
            if available_ids and len(current_ids) >= len(available_ids):
                set_enabled_linked_cas_part_ids(pack_id, pose_name, [])
            else:
                if not isinstance(getattr(state, "linked_cas_enabled_choices", None), dict):
                    state.linked_cas_enabled_choices = {}
                state.linked_cas_enabled_choices.pop(linked_object_choice_key(pack_id, pose_name), None)
                save_favorites()
        elif link_type == "object":
            set_linked_object_spawn_enabled(pack_id, pose_name, True)
            available_ids = []
            for option in get_linked_object_variant_options(pack_id, pose_name):
                try:
                    item_id = int(option.get("definition_id") or 0)
                except:
                    item_id = 0
                if item_id:
                    available_ids.append(item_id)
            current_ids = get_enabled_linked_object_definition_ids(pack_id, pose_name, available_ids)
            if available_ids and len(current_ids) >= len(available_ids):
                set_enabled_linked_object_definition_ids(pack_id, pose_name, [])
            else:
                if not isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
                    state.linked_object_enabled_choices = {}
                state.linked_object_enabled_choices.pop(linked_object_choice_key(pack_id, pose_name), None)
                set_selected_linked_object_definition_id(pack_id, pose_name, 0)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_SETTING_ITEM_TOGGLE_PREFIX):
        link_type, pack_id, pose_name, item_id = parse_linked_setting_item_toggle_tag(choice_tag)
        if link_type == "cas":
            available_ids = [
                int(option.get("cas_part_id") or 0)
                for option in get_linked_cas_variant_options(pack_id, pose_name)
                if int(option.get("cas_part_id") or 0)
            ]
            toggle_linked_cas_part_id(pack_id, pose_name, item_id, available_ids)
        elif link_type == "object":
            available_ids = [
                int(option.get("definition_id") or 0)
                for option in get_linked_object_variant_options(pack_id, pose_name)
                if int(option.get("definition_id") or 0)
            ]
            toggle_linked_object_definition_id(pack_id, pose_name, item_id, available_ids)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_OBJECT_SPAWN_TOGGLE_PREFIX):
        pack_id, pose_name = parse_linked_object_spawn_toggle_tag(choice_tag)
        if getattr(state, 'selected_linked_group_type', None) == "cas":
            set_linked_cas_apply_enabled(pack_id, pose_name, not is_linked_cas_apply_enabled(pack_id, pose_name))
        else:
            set_linked_object_spawn_enabled(pack_id, pose_name, not is_linked_object_spawn_enabled(pack_id, pose_name))
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_OBJECT_APPLY_PACK_PREFIX):
        pack_id, pose_name = parse_linked_object_apply_pack_tag(choice_tag)
        if getattr(state, 'selected_linked_group_type', None) == "cas":
            apply_linked_cas_selection_to_pack(pack_id, pose_name)
        else:
            apply_linked_object_selection_to_pack(pack_id, pose_name)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_OBJECT_STYLE_VARIANT_PREFIX):
        pack_id, pose_name, definition_id = parse_linked_object_style_variant_tag(choice_tag)
        if getattr(state, 'selected_linked_group_type', None) == "cas":
            if definition_id:
                available_ids = [
                    int(option.get("cas_part_id") or 0)
                    for option in get_linked_cas_variant_options(pack_id, pose_name)
                    if int(option.get("cas_part_id") or 0)
                ]
                toggle_linked_cas_part_id(pack_id, pose_name, definition_id, available_ids)
            else:
                set_linked_cas_apply_enabled(pack_id, pose_name, True)
                if not isinstance(getattr(state, "linked_cas_enabled_choices", None), dict):
                    state.linked_cas_enabled_choices = {}
                state.linked_cas_enabled_choices.pop(linked_object_choice_key(pack_id, pose_name), None)
        else:
            if definition_id:
                available_ids = [
                    int(option.get("definition_id") or 0)
                    for option in get_linked_object_variant_options(pack_id, pose_name)
                    if int(option.get("definition_id") or 0)
                ]
                toggle_linked_object_definition_id(pack_id, pose_name, definition_id, available_ids)
            else:
                set_linked_object_spawn_enabled(pack_id, pose_name, True)
                if not isinstance(getattr(state, "linked_object_enabled_choices", None), dict):
                    state.linked_object_enabled_choices = {}
                state.linked_object_enabled_choices.pop(linked_object_choice_key(pack_id, pose_name), None)
                set_selected_linked_object_definition_id(pack_id, pose_name, 0)
        state.selected_linked_pack_id = pack_id or getattr(state, 'selected_linked_pack_id', None)
        state.selected_linked_style_pose_name = pose_name
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_IMPORT_GROUPED":
        state.selected_linked_group_name = LINKED_GROUPED_ENTRY_NAME
        state.selected_linked_grouped_outer_name = None
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.selected_linked_grouped_pose_group_name = None
        state.linked_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_CREATE_GROUP":
        state.selected_linked_group_name = create_default_linked_group(getattr(state, 'selected_linked_group_type', None) or "cas")
        state.selected_linked_pack_id = None
        state.selected_linked_assign_pack_id = None
        state.linked_manage_mode = False
        state.linked_object_style_mode = False
        state.selected_linked_style_pose_name = None
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "FGEH_LINKED_NOOP":
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == LINKED_PLAY_CURRENT_GROUP_TAG:
        group_type = getattr(state, 'selected_linked_group_type', None)
        pack_id = getattr(state, 'selected_linked_pack_id', None)
        pose_group_name = getattr(state, 'selected_linked_grouped_pose_group_name', None)
        refs = get_linked_grouped_pose_refs(group_type, pack_id, pose_group_name)
        return play_linked_pose_refs(self, actual_target, refs)

    if isinstance(choice_tag, str) and choice_tag.startswith(LINKED_ACTIONS_POSE_PREFIX):
        category, pack_id, p_name = parse_linked_action_tag(choice_tag)
        return play_linked_pose(self, actual_target, pack_id, p_name)

    if choice_tag == "BTN_SELECT_OTHER_SIM":
        cancel_positioning_session_for_interaction(self)
        show_fgeh_sim_picker(self)
        return

    # ✨ 核心：UI 收纳系统的路由切换
    if choice_tag == "BTN_ENTER_NORMAL_MANAGE":
        state.is_in_normal_pack_manage_mode = True
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag == "BTN_EXIT_NORMAL_MANAGE":
        state.is_in_normal_pack_manage_mode = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_GLOBAL_SETTINGS_BACK":
        resolved_snapshot = resolve_last_ui_snapshot()
        if resolved_snapshot is not None:
            snapshot, restored_pack = resolved_snapshot
            state.gs_view_mode = GlobalSettingsMode.MAIN
            state.global_settings_from_root = False
            self.selected_pose_pack = apply_last_ui_snapshot(snapshot) or restored_pack
            return self._show_picker_dialog(self.sim, target_sim=actual_target)
        return

    if choice_tag == "BTN_GLOBAL_SETTINGS_RETURN_ROOT":
        state.suppress_next_history_restore = True
        state.global_settings_from_root = False
        if self.cancel_continuation:
            self.push_tunable_continuation(
                self.cancel_continuation,
                insert_strategy=QueueInsertStrategy.FIRST,
                actor=self.target
            )
        return

    if choice_tag == "BTN_GLOBAL_SETTINGS_CLOSE":
        return

    if choice_tag == "GLOBAL_SETTINGS::TOGGLE_RESTORE_HISTORY":
        state.restore_last_view_on_open = not state.restore_last_view_on_open
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "GLOBAL_SETTINGS::TOGGLE_AUTO_APPLY_LINKED":
        state.auto_apply_linked_requirements = not bool(getattr(state, "auto_apply_linked_requirements", True))
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "GLOBAL_SETTINGS::TOGGLE_AUTO_DESTROY_OBJECTS":
        state.auto_destroy_linked_objects = not bool(getattr(state, "auto_destroy_linked_objects", True))
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "GLOBAL_SETTINGS::TOGGLE_REPLACE_OBJECTS_ON_REPLAY":
        state.replace_linked_objects_on_replay = not bool(getattr(state, "replace_linked_objects_on_replay", True))
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "GLOBAL_SETTINGS::TOGGLE_RESTORE_LINKED_ON_CHAIN_FINISHED":
        state.restore_linked_requirements_when_pose_chain_finished = not bool(getattr(state, "restore_linked_requirements_when_pose_chain_finished", False))
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "GLOBAL_SETTINGS::CACHE_INFO":
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag is None or not isinstance(choice_tag, str):
        if hasattr(choice_tag, 'pose_name'):
            p_name = choice_tag.pose_name
            if state.current_mode == ViewMode.FAV:
                if p_name in state.favorite_poses: state.favorite_poses.remove(p_name)
                else: state.favorite_poses.append(p_name)
                save_favorites()
                return self._show_picker_dialog(self.sim, target_sim=actual_target)

            if state.current_mode == ViewMode.TRACE:
                build_cache_safe()
                info = state.all_poses_cache.get(p_name)
                if info:
                    self.selected_pose_pack = info['pack_ref']
                    state.global_traced_pack_ref = info['pack_ref']
                    state.return_to_fav_on_close = True
                    state.came_from_l1_favs = False
                    state.came_from_creator = False
                    state.came_from_grouped = False
                    state.current_mode = ViewMode.NORMAL
                    return self._show_picker_dialog(self.sim, target_sim=actual_target)
                    
            if state.current_mode == ViewMode.NORMAL:
                from interactions.context import QueueInsertStrategy
                from interactions.priority import Priority
                if POSITIONING_SYSTEM_ACTIVE:
                    ensure_positioning_session(self, p_name, actual_target)
                self.interaction_parameters['pose_name'] = p_name
                self.push_tunable_continuation((self.continuation), pose_name=p_name, insert_strategy=(QueueInsertStrategy.LAST), priority=Priority.High, actor=(actual_target))
                return self._show_picker_dialog(self.sim, target_sim=actual_target)

        return original_pose_on_choice(self, choice_tag, **kwargs)

    # ==========================================
    # 单独动作收藏的分组路由拦截
    # ==========================================
    if choice_tag == "BTN_S_TOGGLE_VIEW":
        state.fav_poses_view_toggle = 1 if state.fav_poses_view_toggle == 0 else 0
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_S_RETURN_MAIN":
        state.s_view_mode = FavPoseMode.PLAY
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_S_GROUP_MANAGE":
        state.s_view_mode = FavPoseMode.GROUP_MANAGE
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_S_ADD_GROUP":
        n = len(state.user_fav_pose_groups) + 1
        new_grp = f"Group {n}"
        while new_grp in state.user_fav_pose_groups: n += 1; new_grp = f"Group {n}"
        state.user_fav_pose_groups[new_grp] = []
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("S_PLAY_GRP::"):
        state.selected_fav_pose_group = choice_tag.split("::")[1]
        state.s_view_mode = FavPoseMode.GROUP_PLAY
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("S_EDIT_GRP::"):
        state.selected_fav_pose_group = choice_tag.split("::")[1]
        state.s_view_mode = FavPoseMode.GROUP_EDIT
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("S_DEL_GRP::"):
        grp_to_del = choice_tag.split("::")[1]
        if grp_to_del in state.user_fav_pose_groups:
            del state.user_fav_pose_groups[grp_to_del]
            save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("S_TOGGLE_POSE::"):
        p_name = choice_tag.split("::")[1]
        target_list = state.user_fav_pose_groups.get(state.selected_fav_pose_group, [])
        if p_name in target_list: target_list.remove(p_name)
        else: target_list.append(p_name)
        state.user_fav_pose_groups[state.selected_fav_pose_group] = target_list
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("S_RENAME_GRP::"):
        old_grp_name = choice_tag.split("::")[1]
        def do_rename_pose_fav_group(new_name):
            if new_name not in state.user_fav_pose_groups:
                state.user_fav_pose_groups[new_name] = state.user_fav_pose_groups.pop(old_grp_name)
                state.selected_fav_pose_group = new_name
                save_favorites()
        show_fgeh_rename_dialog(self, old_grp_name, do_rename_pose_fav_group)
        return

    # ==========================================
    # 返回按钮拦截 (防闪退核心)
    # ==========================================
    if choice_tag == "RETURN_TO_FAV_PACKS_MENU_BTN":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "fgeh_fav_packs_folder"
        if state.fav_packs_view_toggle == 1 and state.selected_fav_creator:
            state.p_view_mode = FavPackMode.CREATOR_PACKS
        elif state.fav_packs_view_toggle == 2 and state.selected_fav_group:
            state.p_view_mode = FavPackMode.GROUP_PLAY
        else:
            state.p_view_mode = FavPackMode.FAVS
        state.came_from_l1_favs = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    # ==========================================
    # 收藏动作包：三态视图与自定义分组 路由拦截
    # ==========================================
    if choice_tag == "BTN_P_TOGGLE_VIEW":
        state.fav_packs_view_toggle = (state.fav_packs_view_toggle + 1) % 3
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_F_GROUP_MANAGE":
        state.p_view_mode = FavPackMode.GROUP_MANAGE
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("F_PLAY_GRP::"):
        state.selected_fav_group = choice_tag.split("::")[1]
        state.p_view_mode = FavPackMode.GROUP_PLAY
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("F_EDIT_GRP::"):
        state.selected_fav_group = choice_tag.split("::")[1]
        state.p_view_mode = FavPackMode.GROUP_EDIT
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag.startswith("F_DEL_GRP::"):
        grp_to_del = choice_tag.split("::")[1]
        if grp_to_del in state.user_fav_groups:
            del state.user_fav_groups[grp_to_del]
            save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_F_ADD_GROUP":
        n = len(state.user_fav_groups) + 1
        new_grp = f"Group {n}"
        while new_grp in state.user_fav_groups:
            n += 1
            new_grp = f"Group {n}"
        state.user_fav_groups[new_grp] = []
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("F_TOGGLE_PACK::"):
        pck_id = choice_tag.split("::")[1]
        target_list = state.user_fav_groups.get(state.selected_fav_group, [])
        if pck_id in target_list: target_list.remove(pck_id)
        else: target_list.append(pck_id)
        state.user_fav_groups[state.selected_fav_group] = target_list
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("F_RENAME_GRP::"):
        old_fav_grp_name = choice_tag.split("::")[1]
        def do_rename_fav_group(new_name):
            if new_name not in state.user_fav_groups:
                state.user_fav_groups[new_name] = state.user_fav_groups.pop(old_fav_grp_name)
                state.selected_fav_group = new_name 
                save_favorites()
        show_fgeh_rename_dialog(self, old_fav_grp_name, do_rename_fav_group)
        return

    pack_id = str(getattr(self.selected_pose_pack, '__name__', 'Unknown'))
    
    if choice_tag == "BTN_G_ASSIGN_MACRO_GROUPS": 
        state.g_view_mode = GroupMode.ASSIGN_MACRO_GROUPS
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_G_MACRO_ADD_GROUP":
        n = len(state.user_grouped_packs_groups) + 1
        new_grp = f"Group {n}"
        while new_grp in state.user_grouped_packs_groups: n += 1; new_grp = f"Group {n}"
        state.user_grouped_packs_groups[new_grp] = []
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag and isinstance(choice_tag, str) and choice_tag.startswith("G_ASSIGN_TOGGLE::"):
        grp_name = choice_tag.split("::")[1]
        target_list = state.user_grouped_packs_groups.get(grp_name, [])
        if pack_id in target_list: target_list.remove(pack_id)
        else: target_list.append(pack_id)
        state.user_grouped_packs_groups[grp_name] = target_list
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("P_CREATOR::"):
        state.selected_fav_creator = choice_tag.split("::")[1]
        state.p_view_mode = FavPackMode.CREATOR_PACKS
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_G_TOGGLE_VIEW":
        state.grouped_view_toggle = (state.grouped_view_toggle + 1) % 3
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag.startswith("G_CREATOR::"):
        state.selected_group_creator = choice_tag.split("::")[1]
        state.g_view_mode = GroupMode.CREATOR_PACKS
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_GROUPED_RETURN_LIST":
        state.g_view_mode = GroupMode.LIST
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag == "RETURN_TO_GROUPED_LIST":
        self.selected_pose_pack = "fgeh_grouped_folder"
        if state.grouped_view_toggle == 1 and state.selected_group_creator:
            state.g_view_mode = GroupMode.CREATOR_PACKS
        elif state.grouped_view_toggle == 2 and state.selected_fav_group:
            state.g_view_mode = GroupMode.FAV_GROUP_PLAY
        else:
            state.g_view_mode = GroupMode.LIST
        state.came_from_grouped = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_GROUPED_DELETE_MODE":
         state.g_view_mode = GroupMode.DELETE_PACK; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    
    if choice_tag.startswith("G_SELECT::"):
        cancel_positioning_session_for_interaction(self)
        pck_id = choice_tag.split("::")[1]
        pck = state.all_packs_cache.get(pck_id)
        if pck:
            self.selected_pose_pack = pck
            state.came_from_grouped = True
            state.came_from_l1_favs = False
            state.came_from_creator = False
            state.g_view_mode = GroupMode.PACK_HOME
            return self._show_picker_dialog(self.sim, target_sim=actual_target)
            
    if choice_tag.startswith("G_DEL_PACK::"):
        pck_id = choice_tag.split("::")[1]
        if pck_id in state.grouped_packs: del state.grouped_packs[pck_id]; save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_G_WORMHOLE_JUMP":
        state.came_from_grouped = True
        state.g_view_mode = GroupMode.PACK_HOME
        state.is_in_normal_pack_manage_mode = False  
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "G_PLAY_ALL_IN_GROUP":
        valid_poses = state.grouped_packs.get(pack_id, {}).get(state.selected_group, [])
        for pose_item in getattr(self.selected_pose_pack, 'pose_list', []):
            p_name = getattr(pose_item, 'pose_name', None)
            if p_name in valid_poses:
                self.interaction_parameters['pose_name'] = p_name
                from interactions.context import QueueInsertStrategy
                from interactions.priority import Priority
                self.push_tunable_continuation((self.continuation), pose_name=p_name, insert_strategy=(QueueInsertStrategy.LAST), priority=Priority.High, actor=(actual_target))
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag == "G_BTN_MANAGE_HOME": state.g_view_mode = GroupMode.PACK_MANAGE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "G_BTN_BACK_TO_HOME": state.g_view_mode = GroupMode.PACK_HOME; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "G_BTN_BACK_TO_MANAGE": state.g_view_mode = GroupMode.PACK_MANAGE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    
    if choice_tag.startswith("G_PLAY_GRP::"):
        state.selected_group = choice_tag.split("::")[1]
        state.g_view_mode = GroupMode.PLAY_GROUP
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag.startswith("G_EDIT_GRP::"):
        state.selected_group = choice_tag.split("::")[1]
        state.g_view_mode = GroupMode.EDIT_GROUP
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_G_F_GROUP_MANAGE": state.g_view_mode = GroupMode.FAV_GROUP_MANAGE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "BTN_G_F_ADD_GROUP":
        n = len(state.user_grouped_packs_groups) + 1
        new_grp = f"Group {n}"
        while new_grp in state.user_grouped_packs_groups: n += 1; new_grp = f"Group {n}"
        state.user_grouped_packs_groups[new_grp] = []
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("G_F_PLAY_GRP::"): state.selected_fav_group = choice_tag.split("::")[1]; state.g_view_mode = GroupMode.FAV_GROUP_PLAY; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("G_F_EDIT_GRP::"): state.selected_fav_group = choice_tag.split("::")[1]; state.g_view_mode = GroupMode.FAV_GROUP_EDIT; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("G_F_DEL_GRP::"):
        grp_to_del = choice_tag.split("::")[1]
        if grp_to_del in state.user_grouped_packs_groups: del state.user_grouped_packs_groups[grp_to_del]; save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("G_F_TOGGLE_PACK::"):
        pck_id = choice_tag.split("::")[1]
        target_list = state.user_grouped_packs_groups.get(state.selected_fav_group, [])
        if pck_id in target_list: target_list.remove(pck_id)
        else: target_list.append(pck_id)
        state.user_grouped_packs_groups[state.selected_fav_group] = target_list
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("G_F_RENAME_GRP::"):
        old_fav_grp_name = choice_tag.split("::")[1]
        def do_rename_g_fav_group(new_name):
            if new_name not in state.user_grouped_packs_groups:
                state.user_grouped_packs_groups[new_name] = state.user_grouped_packs_groups.pop(old_fav_grp_name)
                state.selected_fav_group = new_name 
                save_favorites()
        show_fgeh_rename_dialog(self, old_fav_grp_name, do_rename_g_fav_group)
        return

    if choice_tag.startswith("G_RENAME_GRP::"):
        old_grp_name = choice_tag.split("::")[1]
        current_pack = getattr(self, 'selected_pose_pack', None)
        current_pack_id = str(getattr(current_pack, '__name__', 'Unknown')) if current_pack else "Unknown"
        def do_rename_pose_group(new_name):
            if current_pack_id in state.grouped_packs:
                group_dict = state.grouped_packs[current_pack_id]
                if new_name not in group_dict:
                    group_dict[new_name] = group_dict.pop(old_grp_name)
                    state.selected_group = new_name 
                    save_favorites()
        show_fgeh_rename_dialog(self, old_grp_name, do_rename_pose_group)
        return
    
    if choice_tag == "G_BTN_AUTO_SORT":
        state.grouped_packs[pack_id] = auto_sort_couple_pack(self.selected_pose_pack)
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag == "G_BTN_ADD_GROUP":
        n = len(state.grouped_packs.get(pack_id, {})) + 1
        new_grp = f"Group {n}"
        while new_grp in state.grouped_packs.get(pack_id, {}):
            n += 1
            new_grp = f"Group {n}"
        if pack_id not in state.grouped_packs: state.grouped_packs[pack_id] = {}
        state.grouped_packs[pack_id][new_grp] = []
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "G_BTN_TOGGLE_ALL":
        pose_list = getattr(self.selected_pose_pack, 'pose_list', [])
        all_pose_names = [getattr(p, 'pose_name', None) for p in pose_list if getattr(p, 'pose_name', None)]
        current_grp = state.grouped_packs.get(pack_id, {}).get(state.selected_group, [])
        if len(current_grp) == len(all_pose_names):
            state.grouped_packs[pack_id][state.selected_group] = []
        else:
            state.grouped_packs[pack_id][state.selected_group] = all_pose_names
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "G_BTN_PATTERN_MATCH":
        pose_list = getattr(self.selected_pose_pack, 'pose_list', [])
        current_grp = state.grouped_packs.get(pack_id, {}).get(state.selected_group, [])
        selected_indices = []
        for i, p in enumerate(pose_list):
            if getattr(p, 'pose_name', None) in current_grp:
                selected_indices.append(i)
        if len(selected_indices) >= 2:
            start_idx = selected_indices[0]
            interval = selected_indices[1] - selected_indices[0]
            if interval > 0:
                new_grp = []
                for i in range(start_idx, len(pose_list), interval):
                    p_name = getattr(pose_list[i], 'pose_name', None)
                    if p_name: new_grp.append(p_name)
                state.grouped_packs[pack_id][state.selected_group] = new_grp
                save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("G_TOGGLE_POSE::"):
        p_name = choice_tag.split("::")[1]
        target_list = state.grouped_packs.get(pack_id, {}).get(state.selected_group, [])
        if p_name in target_list: target_list.remove(p_name)
        else: target_list.append(p_name)
        state.grouped_packs[pack_id][state.selected_group] = target_list
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "TOGGLE_GROUPED_PACK_ONLY_BTN":
        if pack_id in state.grouped_packs: del state.grouped_packs[pack_id]
        else: state.grouped_packs[pack_id] = {}
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)
        
    if choice_tag.startswith("G_DEL_GRP::"):
        grp_to_del = choice_tag.split("::")[1]
        current_pack = getattr(self, 'selected_pose_pack', None)
        current_pack_id = str(getattr(current_pack, '__name__', 'Unknown')) if current_pack else "Unknown"
        
        if current_pack_id in state.grouped_packs and grp_to_del in state.grouped_packs[current_pack_id]:
            del state.grouped_packs[current_pack_id][grp_to_del]
            save_favorites()
            
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_FAV_PACKS_DELETE_MODE": state.p_view_mode = FavPackMode.DELETE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("P_DELETE::"):
        pck_id = choice_tag.split("::")[1]
        if pck_id in state.favorite_packs:
            state.favorite_packs.remove(pck_id)
            save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_FAV_PACKS_RETURN_TO_MANAGE":
        state.p_view_mode = FavPackMode.MANAGE
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_FAV_PACKS_RETURN":
        self.selected_pose_pack = "fgeh_fav_packs_folder"
        state.p_view_mode = FavPackMode.FAVS
        state.came_from_l1_favs = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_FAV_PACKS_MANAGE": state.p_view_mode = FavPackMode.MANAGE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "BTN_FAV_PACKS_CLEAR": state.favorite_packs.clear(); save_favorites(); return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("P_TOGGLE::"):
        pck_id = choice_tag.split("::")[1]
        if pck_id in state.favorite_packs: state.favorite_packs.remove(pck_id)
        else: state.favorite_packs.append(pck_id)
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("P_SELECT::"):
        cancel_positioning_session_for_interaction(self)
        pck_id = choice_tag.split("::")[1]
        pck = state.all_packs_cache.get(pck_id)
        if pck:
            self.selected_pose_pack = pck
            state.current_mode = ViewMode.NORMAL
            state.came_from_l1_favs = True
            state.came_from_creator = False
            state.came_from_grouped = False
            state.return_to_fav_on_close = False
            return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_CREATORS_DELETE_MODE": state.c_view_mode = CreatorMode.DELETE; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "BTN_CREATORS_RETURN_FAVS": state.c_view_mode = CreatorMode.FAVS; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("C_DELETE::"):
        creator = choice_tag.split("::")[1]
        if creator in state.favorite_creators:
            state.favorite_creators.remove(creator)
            save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "RETURN_TO_CREATOR_PACKS_BTN":
        cancel_positioning_session_for_interaction(self)
        self.selected_pose_pack = "hegfcreator_folder"
        state.c_view_mode = CreatorMode.PACKS
        state.came_from_creator = False
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "BTN_ALL_CREATORS": state.c_view_mode = CreatorMode.ALL; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag == "BTN_RETURN_FAV_CREATORS": state.c_view_mode = CreatorMode.FAVS; state.selected_creator = None; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("C_VIEW::"): state.c_view_mode = CreatorMode.PACKS; state.selected_creator = choice_tag.split("::")[1]; return self._show_picker_dialog(self.sim, target_sim=actual_target)
    if choice_tag.startswith("BTN_RENAME_CREATOR::"):
        creator_id = choice_tag.split("::")[1]
        old_name = get_display_name(creator_id, "creator_")
        
        def do_rename_creator(new_name):
            custom_key = f"creator_{creator_id}"
            if new_name:
                state.custom_names[custom_key] = new_name
            else:
                state.custom_names.pop(custom_key, None)
            save_favorites()
            
        show_fgeh_rename_dialog(self, old_name, do_rename_creator, allow_empty_submit=True)
        return
    if choice_tag.startswith("C_TOGGLE::"):
        creator = choice_tag.split("::")[1]
        if creator in state.favorite_creators: state.favorite_creators.remove(creator)
        else: state.favorite_creators.append(creator)
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag.startswith("CREATOR_PACK::"):
        cancel_positioning_session_for_interaction(self)
        parts = choice_tag.split("::")
        if len(parts) >= 3:
            packs = state.all_creators_cache.get(parts[1], [])
            pack_idx = int(parts[2])
            if 0 <= pack_idx < len(packs):
                self.selected_pose_pack = packs[pack_idx]
                state.current_mode = ViewMode.NORMAL
                state.came_from_creator = True
                state.came_from_l1_favs = False
                state.came_from_grouped = False
                state.return_to_fav_on_close = False
                return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "TOGGLE_MODE_BTN":
        if pack_type == 'POSES': state.current_mode = (state.current_mode + 1) % 3
        else: state.current_mode = ViewMode.FAV if state.current_mode == ViewMode.NORMAL else ViewMode.NORMAL
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "RETURN_TO_FAV_BTN":
        cancel_positioning_session_for_interaction(self)
        if state.global_fav_pack_ref:
            self.selected_pose_pack = state.global_fav_pack_ref
            state.return_to_fav_on_close = False
            return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "TOGGLE_FAV_PACK_ONLY_BTN":
        pack = self.selected_pose_pack
        pack_id = str(getattr(pack, '__name__', 'Unknown'))
        if pack_id in state.favorite_packs: state.favorite_packs.remove(pack_id)
        else: state.favorite_packs.append(pack_id)
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "TOGGLE_FAV_ALL_POSES_ONLY_BTN":
        pack = self.selected_pose_pack
        names = [p.pose_name for p in getattr(pack, 'pose_list', []) if hasattr(p, 'pose_name')]
        is_fully_faved = bool(names) and all(n in state.favorite_poses for n in names)

        if is_fully_faved:
            for n in names:
                if n in state.favorite_poses: state.favorite_poses.remove(n)
        else:
            for n in names:
                if n not in state.favorite_poses: state.favorite_poses.append(n)
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

    if choice_tag == "CLEAR_ALL_FAV_BTN":
        state.favorite_poses.clear()
        save_favorites()
        return self._show_picker_dialog(self.sim, target_sim=actual_target)

# === 挂载点 ===
@injector2.inject(poseplayer.PoseByPackNameInteraction, 'on_reset', safe=True)
def _fgeh_positioning_cleanup_on_reset(original, self, *args, **kwargs):
    cancel_positioning_session_for_interaction(self)
    return original(self, *args, **kwargs)


@injector2.inject(poseplayer.PoseByPackNameInteraction, 'on_interaction_reset', safe=True)
def _fgeh_positioning_cleanup_on_interaction_reset(original, self, *args, **kwargs):
    cancel_positioning_session_for_interaction(self)
    return original(self, *args, **kwargs)


@injector2.inject(poseplayer.PoseByPackNameInteraction, 'on_interaction_cancel', safe=True)
def _fgeh_positioning_cleanup_on_interaction_cancel(original, self, *args, **kwargs):
    cancel_positioning_session_for_interaction(self)
    return original(self, *args, **kwargs)


def _cleanup_after_pose_interaction(original, self, *args, **kwargs):
    target_sim = _get_pose_cleanup_sim(self)
    result = original(self, *args, **kwargs)
    cleanup_positioning_if_pose_chain_finished(target_sim, exclude_interaction=self, reason="pose_lifecycle")
    positioning_log(
        "pose interaction lifecycle checked for positioning cleanup sim={} interaction={} pose_name={}",
        getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
        self,
        getattr(self, "pose_name", None),
    )
    return result


@injector2.inject(poseplayer.PoseInteraction, 'on_reset', safe=True)
def _fgeh_pose_cleanup_on_reset(original, self, *args, **kwargs):
    return _cleanup_after_pose_interaction(original, self, *args, **kwargs)


@injector2.inject(poseplayer.PoseInteraction, 'on_interaction_reset', safe=True)
def _fgeh_pose_cleanup_on_interaction_reset(original, self, *args, **kwargs):
    return _cleanup_after_pose_interaction(original, self, *args, **kwargs)


@injector2.inject(poseplayer.PoseInteraction, 'on_interaction_cancel', safe=True)
def _fgeh_pose_cleanup_on_interaction_cancel(original, self, *args, **kwargs):
    return _cleanup_after_pose_interaction(original, self, *args, **kwargs)


@injector2.inject(poseplayer.PoseInteraction, '_run_interaction_gen', safe=True)
def _fgeh_pose_cleanup_after_run(original, self, timeline, *args, **kwargs):
    target_sim = _get_pose_cleanup_sim(self)
    try:
        run_result = original(self, timeline, *args, **kwargs)
        if hasattr(run_result, 'send') and hasattr(run_result, '__iter__'):
            return (yield from run_result)
        return run_result
    finally:
        try:
            from fgeh_cas_accessory_outfit_utils import debug_log
            debug_log(
                "PoseInteraction run finished; scheduling cleanup sim_id={} pose_name={}",
                getattr(target_sim, "sim_id", getattr(target_sim, "id", None)),
                getattr(self, "pose_name", None),
            )
        except Exception:
            pass
        if not schedule_pose_chain_cleanup_check(target_sim, reason="pose_run_finished"):
            cleanup_positioning_if_pose_chain_finished(target_sim, exclude_interaction=self, reason="pose_run_finished")


@injector2.inject(poseplayer.PoseInteraction, 'setup_asm_default', safe=True)
def _fgeh_apply_linked_requirements_on_pose_setup(original, self, asm, *args, **kwargs):
    result = original(self, asm, *args, **kwargs)
    schedule_linked_requirements_when_pose_runs(self)
    return result


@injector2.inject(poseplayer.PoseInteraction, '__init__', safe=True)
def _fgeh_pose_register_cleanup_callback(original, self, *args, **kwargs):
    result = original(self, *args, **kwargs)
    register_positioning_cleanup_callback_for_pose_interaction(self)
    return result


@injector2.inject(poseplayer.StopPoseInteraction, '_run_interaction_gen', safe=True)
def _fgeh_stop_pose_cleanup(original, self, timeline, *args, **kwargs):
    target_sim = _get_pose_cleanup_sim(self)
    result = original(self, timeline, *args, **kwargs)
    cleanup_positioning_if_pose_chain_finished(target_sim, reason="stop_posing")
    return result


try:
    load_favorites()
    poseplayer.PoseByPackNameInteraction.picker_rows_gen = custom_pose_rows_gen
    poseplayer.PoseByPackNameInteraction.on_choice_selected = custom_pose_on_choice
except:
    pass

import os
import time
import traceback


def _loader_log(message):
    filename = "fgeh_cas_accessory_debug.log"
    roots = (
        "E:\\文档\\Electronic Arts\\The Sims 4",
        os.path.join(os.path.expanduser("~/Documents"), "Electronic Arts", "The Sims 4"),
    )
    line = "[{}] [FGEH_CAS_Accessory] {}".format(
        time.strftime("%Y-%m-%d %H:%M:%S"),
        message,
    )
    for root in roots:
        try:
            if root and os.path.isdir(root):
                with open(os.path.join(root, filename), "a", encoding="utf-8") as log_file:
                    log_file.write(line + "\n")
                return
        except Exception:
            pass


_loader_log("accessory loader import start")
try:
    import fgeh_cas_accessory_injector
    _loader_log("accessory injector imported")
except Exception:
    _loader_log("accessory injector import failed\n{}".format(traceback.format_exc()))
